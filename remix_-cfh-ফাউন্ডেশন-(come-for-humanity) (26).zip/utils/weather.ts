
export interface WeatherData {
    temperature: number;
    condition: string;
    icon: string;
    location: string;
}

/**
 * Simulates fetching weather data for a given location.
 * In a real app, this would make an API call to a weather service.
 * @param latitude The latitude of the location.
 * @param longitude The longitude of the location.
 * @returns A promise that resolves with mock weather data.
 */
export const getMockWeather = (latitude: number, longitude: number): Promise<WeatherData> => {
    return new Promise((resolve) => {
        // Simulate network delay
        setTimeout(() => {
            // For this mock, we'll always return weather for Meherpur regardless of actual coords.
            const mockWeather: WeatherData = {
                temperature: 32,
                condition: 'মেঘলা আকাশ',
                icon: 'cloud',
                location: 'মেহেরপুর',
            };
            resolve(mockWeather);
        }, 800);
    });
};
