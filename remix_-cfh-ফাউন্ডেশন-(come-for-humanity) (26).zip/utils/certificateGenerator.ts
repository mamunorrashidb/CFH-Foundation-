
import jsPDF from 'jspdf';
import QRCode from 'qrcode';

interface CertificateData {
    name: string;
    course: string;
    completionDate: string;
    certificateId: string;
}

// Placeholder images - in a real app, these would be hosted assets
const LOGO_URL = 'https://picsum.photos/seed/cfhlogo/100/100';
const SIGNATURE_URL = 'https://i.ibb.co/7jW7kF5/signature-placeholder.png';

export const generateCertificate = async (data: CertificateData): Promise<void> => {
    const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'mm',
        format: 'a4'
    });

    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    
    // As jsPDF doesn't support Bangla fonts by default, we'll proceed with English text for the PDF.
    // A full implementation would require a custom font to be embedded.

    // 1. Add Border
    pdf.setDrawColor('#002366'); // CFH Royal Blue
    pdf.setLineWidth(1.5);
    pdf.rect(5, 5, pageWidth - 10, pageHeight - 10);

    // 2. Add Logo
    const logoImg = await fetch(LOGO_URL).then(res => res.blob());
    const logoReader = new FileReader();
    logoReader.readAsDataURL(logoImg);
    await new Promise<void>(resolve => logoReader.onloadend = () => resolve());
    pdf.addImage(logoReader.result as string, 'PNG', pageWidth / 2 - 15, 15, 30, 30);
    
    // 3. Add Titles (Using English as fallback for PDF rendering)
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(28);
    pdf.setTextColor('#002366');
    pdf.text('Certificate of Completion', pageWidth / 2, 60, { align: 'center' });

    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(16);
    pdf.setTextColor('#333333');
    pdf.text('This is to certify that', pageWidth / 2, 80, { align: 'center' });

    // 4. Student Name
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(36);
    pdf.setTextColor('#50C878'); // CFH Emerald Green
    pdf.text(data.name, pageWidth / 2, 100, { align: 'center' });

    // 5. Course Details
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(16);
    pdf.setTextColor('#333333');
    pdf.text(`has successfully completed the course`, pageWidth / 2, 115, { align: 'center' });

    pdf.setFont('helvetica', 'italic');
    pdf.setFontSize(20);
    pdf.text(data.course, pageWidth / 2, 125, { align: 'center' });

    // 6. Date
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(14);
    pdf.text(`on this day, ${data.completionDate}`, pageWidth / 2, 135, { align: 'center' });

    // 7. Signature & QR Code
    const signatureY = 160;
    const qrCodeSize = 30;

    // QR Code
    const qrCodeDataUrl = await QRCode.toDataURL(`https://cfh.org.bd/verify?cert=${data.certificateId}`);
    pdf.addImage(qrCodeDataUrl, 'PNG', 40, signatureY - 5, qrCodeSize, qrCodeSize);
    pdf.setFontSize(8);
    pdf.text('Scan to Verify', 40 + qrCodeSize/2, signatureY + qrCodeSize - 2, { align: 'center' });

    // Signature
    const signatureImg = await fetch(SIGNATURE_URL).then(res => res.blob());
    const signatureReader = new FileReader();
    signatureReader.readAsDataURL(signatureImg);
    await new Promise<void>(resolve => signatureReader.onloadend = () => resolve());
    pdf.addImage(signatureReader.result as string, 'PNG', pageWidth - 100, signatureY - 15, 60, 20);

    pdf.setDrawColor('#002366');
    pdf.setLineWidth(0.5);
    pdf.line(pageWidth - 110, signatureY + 10, pageWidth - 40, signatureY + 10);
    
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(12);
    pdf.text('Mamun Or Rashid Bijon', pageWidth - 75, signatureY + 18, { align: 'center' });
    pdf.setFont('helvetica', 'normal');
    pdf.text('Founder Chairman, CFH', pageWidth - 75, signatureY + 23, { align: 'center' });
    
    // 8. Save the PDF
    pdf.save(`${data.name}_${data.course}_Certificate.pdf`);
};
