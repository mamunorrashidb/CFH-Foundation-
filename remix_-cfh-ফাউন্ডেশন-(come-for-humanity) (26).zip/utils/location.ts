
/**
 * A Promise-based wrapper for the browser's Geolocation API.
 * @returns A promise that resolves with the user's coordinates or rejects with an error.
 */
export const getCurrentLocation = (): Promise<{ latitude: number; longitude: number }> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      return reject(new Error('আপনার ব্রাউজারে জিওলোকেশন সমর্থিত নয়।'));
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      },
      (error) => {
        switch (error.code) {
          case error.PERMISSION_DENIED:
            return reject(new Error('অবস্থানের অনুমতি দেওয়া হয়নি। অনুগ্রহ করে আপনার ব্রাউজার সেটিংসে এটি সক্ষম করুন।'));
          case error.POSITION_UNAVAILABLE:
            return reject(new Error('অবস্থানের তথ্য अनुपलब्ध।'));
          case error.TIMEOUT:
            return reject(new Error('ব্যবহারকারীর অবস্থান পাওয়ার অনুরোধ সময়সীমা অতিক্রম করেছে।'));
          default:
            return reject(new Error('অবস্থান আনার সময় একটি অজানা ত্রুটি ঘটেছে।'));
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000, // 10 seconds
        maximumAge: 0, // Force a fresh location
      }
    );
  });
};
