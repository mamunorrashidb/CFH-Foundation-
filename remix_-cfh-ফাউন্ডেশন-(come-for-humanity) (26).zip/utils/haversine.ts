interface Coordinates {
    lat: number;
    lon: number;
}

/**
 * Calculates the distance between two geographical points using the Haversine formula.
 * @param point1 The first coordinate object { lat, lon }.
 * @param point2 The second coordinate object { lat, lon }.
 * @returns The distance in kilometers.
 */
export const calculateDistance = (point1: Coordinates, point2: Coordinates): number => {
    const R = 6371; // Radius of the Earth in kilometers
    const dLat = deg2rad(point2.lat - point1.lat);
    const dLon = deg2rad(point2.lon - point1.lon);

    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(deg2rad(point1.lat)) * Math.cos(deg2rad(point2.lat)) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;
    return distance;
};

function deg2rad(deg: number): number {
    return deg * (Math.PI / 180);
}
