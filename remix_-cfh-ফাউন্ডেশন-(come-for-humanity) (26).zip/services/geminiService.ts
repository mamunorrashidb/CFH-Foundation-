

import { GoogleGenAI } from "@google/genai";

// IMPORTANT: Do NOT commit your API key to a public repository.
// The key is accessed via environment variables for security.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real app, you might want to show a more user-friendly error
  // or disable AI features if the key is not available.
  console.warn("Gemini API key not found. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const askHumanityBot = async (prompt: string): Promise<string> => {
  if (!API_KEY) {
    return "দুঃখিত, এআই পরিষেবা বর্তমানে अनुपलब्ध। অনুগ্রহ করে কনফিগারেশন পরীক্ষা করুন।";
  }

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          systemInstruction: "আপনি 'মানবতা বট', 'CFH Come For Humanity' সুপার-অ্যাপের বন্ধুত্বপূর্ণ এবং সহায়ক AI সহকারী। আপনার উদ্দেশ্য হলো বাংলাদেশ এবং বিশ্বজুড়ে ব্যবহারকারীদের সহায়তা করা। CFH-এর পরিষেবা (ব্লাড ব্যাংক, অক্সিজেন, সামাজিক ব্যবসা, আইটি স্কুল ইত্যাদি), কীভাবে সাহায্য পাবেন, কীভাবে স্বেচ্ছাসেবক হবেন এবং আমাদের লক্ষ্য সম্পর্কে প্রশ্নের উত্তর দিন। পেশাদার, সহানুভূতিশীল এবং অনুপ্রেরণামূলক হন। আপনার প্রাথমিক ভাষা বাংলা হওয়া উচিত।",
        },
    });
    
    // FIX: Access the .text property directly instead of calling it as a function.
    const text = response.text;
    if (text) {
        return text;
    } else {
        return "দুঃখিত, আমি একটি প্রতিক্রিয়া তৈরি করতে পারিনি। অনুগ্রহ করে আবার চেষ্টা করুন।";
    }
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "এআই পরিষেবার সাথে সংযোগ করার সময় একটি ত্রুটি ঘটেছে। বিস্তারিত জানার জন্য অনুগ্রহ করে কনসোল দেখুন।";
  }
};


/**
 * Placeholder for Gemini API NID/ID card validation.
 * In a real implementation, this would send the image to Gemini Vision Pro
 * to extract text and check for authenticity markers.
 * @param file The image file of the NID/ID card.
 * @returns A promise that resolves to true (for mock success) or rejects.
 */
export const validateNidWithGemini = async (file: File): Promise<boolean> => {
    console.log(`[AI Placeholder] Validating ${file.name} with Gemini...`);

    // 1. Convert file to base64 for API payload
    const base64Data = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = error => reject(error);
        reader.readAsDataURL(file);
    });
    
    // 2. Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500)); // Fake network latency

    console.log("[AI Placeholder] Mock validation successful.");
    // In a real scenario, you'd make the actual API call here:
    /*
    const response = await ai.models.generateContent({
        model: 'gemini-pro-vision',
        contents: {
            parts: [
                { inlineData: { mimeType: file.type, data: base64Data } },
                { text: 'Is this a valid NID card? Extract the name and NID number.' }
            ]
        },
    });
    // ... process response.text to validate
    */
    
    // For now, we'll just return true
    return true;
};