// This service handles API calls to the protected /admin/api.php endpoints.
// In a real application, this service would also handle sending authentication tokens (e.g., JWT in headers).

const ADMIN_API_BASE_URL = '/admin/api.php';

async function postToAdminApi(action: string, body: object): Promise<any> {
    try {
        const response = await fetch(`${ADMIN_API_BASE_URL}?action=${action}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'একটি অজানা অ্যাডমিন এপিআই ত্রুটি ঘটেছে।');
        }

        return await response.json();
    } catch (error) {
        console.error(`Admin API call failed for action "${action}":`, error);
        throw error;
    }
}

async function getFromAdminApi(action: string, params: Record<string, any> = {}): Promise<any> {
    const url = new URL(ADMIN_API_BASE_URL, window.location.origin);
    url.searchParams.append('action', action);
    for (const key in params) {
        url.searchParams.append(key, params[key]);
    }

     try {
        const response = await fetch(url.toString());
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'একটি অজানা অ্যাডমিন এপিআই ত্রুটি ঘটেছে।');
        }
        return await response.json();
    } catch (error) {
        console.error(`Admin API call failed for action "${action}":`, error);
        throw error;
    }
}


// --- Specific Admin API Functions ---

export const fetchAdminMembers = () => {
    return getFromAdminApi('get_members');
};

export const fetchAdminEvents = () => {
    return getFromAdminApi('get_events');
};

export const sendEventReminder = (eventName: string) => {
    return postToAdminApi('send_reminder', { eventName });
};
