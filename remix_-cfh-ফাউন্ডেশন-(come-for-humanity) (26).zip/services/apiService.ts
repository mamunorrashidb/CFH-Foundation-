
import { Donor, NewsArticle } from '../types';
import { newsPortals } from '../data/newsPortals';

// NOTE: In a real production app, this URL should be in an environment variable.
const API_BASE_URL = '/api.php'; // Assuming api.php is in the root directory.

/**
 * A generic function to handle POST requests with JSON data to the central API.
 * @param action The specific API action to perform.
 * @param body The data payload to send with the request.
 * @returns The JSON response from the server.
 */
async function postToApi(action: string, body: object): Promise<any> {
    try {
        const response = await fetch(`${API_BASE_URL}?action=${action}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'একটি অজানা এপিআই ত্রুটি ঘটেছে।');
        }

        return await response.json();
    } catch (error) {
        console.error(`API call failed for action "${action}":`, error);
        throw error; // Re-throw the error to be handled by the calling component
    }
}

/**
 * A generic function to handle GET requests to the central API.
 * @param action The specific API action to perform (e.g., 'get_live_stats').
 * @param params Optional query parameters.
 * @returns The JSON response from the server.
 */
async function getFromApi(action: string, params: Record<string, any> = {}): Promise<any> {
    const url = new URL(API_BASE_URL, window.location.origin);
    url.searchParams.append('action', action);
    for (const key in params) {
        url.searchParams.append(key, params[key]);
    }

     try {
        const response = await fetch(url.toString());

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'একটি অজানা এপিআই ত্রুটি ঘটেছে।');
        }

        return await response.json();
    } catch (error) {
        console.error(`API call failed for action "${action}":`, error);
        throw error;
    }
}

// --- Specific API Functions ---

export const logCall = (callerId: string, calleeId: string, calleeNumber: string, context: string) => {
    return postToApi('log_call', { callerId, calleeId, calleeNumber, context });
};

export const submitBloodRequest = (requestData: object) => {
    return postToApi('submit_blood_request', requestData);
};

export const triggerEmergencyAlert = (requestData: object) => {
    return postToApi('trigger_emergency_alert', requestData);
};

export const submitOxygenRequest = (requestData: object) => {
    return postToApi('request_oxygen', requestData);
};

export const fetchLiveStats = () => {
    return getFromApi('get_live_stats');
};

export const fetchBloodRequests = () => {
    return getFromApi('get_blood_requests');
};

export const registerDonor = (donorData: object) => {
    return postToApi('register_donor', donorData);
};


// --- Blood Bank Functions (LIVE DATABASE) ---
// FIX: Corrected the return type to include the error case, which allows type-safe access to the 'message' property on failure.
export const fetchDonors = async (userLocation: { lat: number, lon: number } | null): Promise<{ status: 'success', data: Donor[] } | { status: 'error', message: string }> => {
    console.log("Fetching live donors from the backend.");
    const params: Record<string, any> = {};
    if (userLocation) {
        params.lat = userLocation.lat;
        params.lon = userLocation.lon;
    }
    // The getFromApi function already handles success/error status wrapping.
    return getFromApi('get_donors', params);
};


/**
 * Updates a donor's profile, including their profile picture, using FormData.
 * @param formData The FormData object containing all profile fields and the optional photo.
 * @returns The JSON response from the server.
 */
export const updateDonorProfile = async (formData: FormData): Promise<any> => {
    try {
        const response = await fetch(`${API_BASE_URL}?action=update_donor_profile`, {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'প্রোফাইল আপডেট করতে একটি ত্রুটি ঘটেছে।');
        }

        return await response.json();
    } catch (error) {
        console.error(`API call failed for action "update_donor_profile":`, error);
        throw error;
    }
};


// --- SDG Projects API Functions ---
export const fetchSdgProjects = () => {
    return getFromApi('get_sdg_projects');
};

export const saveSdgProject = (projectData: object) => {
    return postToApi('add_or_update_sdg_project', projectData);
};

// --- E-commerce API Functions ---
export const placeOrder = (orderData: { customerId: number; totalAmount: number; shippingAddress: string; cart: any[]; referralCode?: string }) => {
    return postToApi('place_order', orderData);
};

export const fetchVendorData = (slug: string): Promise<any> => {
    return getFromApi('get_vendor_data', { slug });
};


// --- LMS API Functions ---
export const enrollStudent = (enrollmentData: { fullName: string; phone: string; email: string; courseId: number }) => {
    return postToApi('enroll_student', enrollmentData);
};

export const getStudentDashboard = (userId: number) => {
    return getFromApi('get_student_dashboard', { userId });
};

export const issueCertificate = (enrollmentId: number) => {
    return postToApi('issue_certificate', { enrollmentId });
};

// --- Affiliate & Partner API Functions ---
export const getAffiliateDashboard = (userId: number) => {
    return getFromApi('get_affiliate_dashboard', { userId });
};

export const getMicroPartnerDashboard = (userId: number) => {
    return getFromApi('get_micro_partner_dashboard', { userId });
};

// --- News Fetching Service ---
function timeAgo(dateString: string): string {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    const replacements: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
    const toBengali = (num: number) => String(num).replace(/[0-9]/g, (match) => replacements[match]);

    let interval = seconds / 31536000;
    if (interval > 1) return `${toBengali(Math.floor(interval))} বছর আগে`;
    
    interval = seconds / 2592000;
    if (interval > 1) return `${toBengali(Math.floor(interval))} মাস আগে`;

    interval = seconds / 86400;
    if (interval > 1) return `${toBengali(Math.floor(interval))} দিন আগে`;

    interval = seconds / 3600;
    if (interval > 1) return `${toBengali(Math.floor(interval))} ঘন্টা আগে`;

    interval = seconds / 60;
    if (interval > 1) return `${toBengali(Math.floor(interval))} মিনিট আগে`;

    return `এই মুহূর্তে`;
}

const extractImage = (description: string): string | undefined => {
    const imgMatch = description.match(/<img[^>]+src="([^">]+)"/);
    return imgMatch ? imgMatch[1] : undefined;
}

export const fetchLiveNews = async (): Promise<NewsArticle[]> => {
    const RSS2JSON_API_URL = 'https://api.rss2json.com/v1/api.json?rss_url=';

    try {
        const promises = newsPortals.map(async (portal) => {
            const res = await fetch(`${RSS2JSON_API_URL}${encodeURIComponent(portal.rssUrl)}`);
            if (!res.ok) {
                console.warn(`Failed to fetch news from ${portal.name}`);
                return [];
            }
            const data = await res.json();
            if (data.status !== 'ok') {
                 console.warn(`RSS2JSON API error for ${portal.name}: ${data.message}`);
                 return [];
            }
            
            return data.items.map((item: any): NewsArticle => ({
                id: item.guid,
                title: item.title,
                link: item.link,
                image: item.thumbnail || extractImage(item.description),
                source: portal.name,
                logo: portal.logo,
                timestamp: timeAgo(item.pubDate),
                pubDate: item.pubDate,
            }));
        });

        const allArticlesNested = await Promise.all(promises);
        const allArticles = allArticlesNested.flat();

        allArticles.sort((a, b) => new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime());
        
        return allArticles;

    } catch (error) {
        console.error("Error fetching live news:", error);
        return [];
    }
};