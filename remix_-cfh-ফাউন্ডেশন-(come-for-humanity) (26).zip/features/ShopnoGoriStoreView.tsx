
import React from 'react';
import { View } from '../types';

interface ShopnoGoriStoreViewProps {
  setActiveView: (view: View) => void;
}

const ShopnoGoriStoreView: React.FC<ShopnoGoriStoreViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-[#121715] dark:text-gray-100 antialiased overflow-x-hidden">
      <nav className="sticky top-0 z-50 flex items-center bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-4 border-b border-border-subtle dark:border-gray-800">
        <button onClick={() => setActiveView('ecommerce')} className="flex size-10 shrink-0 items-center justify-start cursor-pointer">
          <span className="material-symbols-outlined text-2xl">arrow_back_ios</span>
        </button>
        <h2 className="flex-1 text-center text-lg font-bold tracking-tight pr-10">Shopno Gori</h2>
      </nav>
      <main className="pb-32">
        <div className="px-4 pt-6 pb-2">
          <h1 className="text-3xl font-bold tracking-[-0.03em] leading-none mb-1">Artisan Crafts</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">Curated by local women entrepreneurs</p>
        </div>
        <div className="grid grid-cols-2 gap-4 p-4">
          <div onClick={() => setActiveView('shopno-gori-product-detail')} className="flex flex-col group cursor-pointer">
            <div className="relative w-full aspect-[4/5] bg-center bg-no-repeat bg-cover rounded-xl overflow-hidden mb-3" data-alt="Handcrafted silk scarf with floral patterns" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuBuFij_YWOTsY4TCGPzzWpo6rSwm4xKGZjwDZmFp9-gV7hO6MJcvQOzlAyDx0zEJaXSvI9FnmYaNU8zYdEhzjBGCti4toXG-i5LeAno5iU4s0dMwUAAj9ojL0MBfsogkXLeAAQs5or05OsencU224UO7OqPkh203aRLGTUTTgom0vjuOfwFQhoo_e1Khd6ioDYPbNSk_cerQc0aKdi_lCGcL4wW85yH3gMBPfZ8A--1e9oYguMdHPL48G7MbzWLj_DM68QNQM6wD8Xb')"}}>
            </div>
            <h3 className="text-base font-semibold leading-tight">Hand-woven Silk Scarf</h3>
          </div>
          <div onClick={() => setActiveView('shopno-gori-product-detail')} className="flex flex-col group cursor-pointer">
            <div className="relative w-full aspect-[4/5] bg-center bg-no-repeat bg-cover rounded-xl overflow-hidden mb-3" data-alt="Modern terracotta vase set" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuBNuPieKvVALM0LccG1uY4QDuuozjGRstgFsdjy5EvrQ0KAiLigPHhlL9HoHeXO9LEyJuJVJhqWdOEnQ0GMxbGiR7QwTr7nxJhmw64T4VaVj07Jrjkfok0cPainEdyK0ELGowFVU-2f7bNHisQpOgubjwG8HjrUTHF0m_1OSNzkLy1LS-tj7CwrvIC3w7BQP7SscrQX_GII5VKfnwNd-v9L8SD0rbQQpi3JTW9QQ7e1lV-x7JrGSJUWV4zOx0KOlT6n8kLzKBYn9fAk')"}}>
            </div>
            <h3 className="text-base font-semibold leading-tight">Terracotta Vase Set</h3>
          </div>
        </div>
        <section className="mt-8">
          <div className="flex justify-between items-end px-4 mb-4">
            <div>
              <h2 className="text-2xl font-bold tracking-tight leading-none">Digital Library</h2>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 uppercase tracking-wider">Expand your knowledge</p>
            </div>
          </div>
          <div className="flex overflow-x-auto no-scrollbar gap-4 px-4 pb-4">
            <div onClick={() => setActiveView('shopno-gori-reader')} className="publication-card flex flex-col min-w-[160px] gap-3 cursor-pointer">
              <div className="w-full aspect-[3/4] bg-center bg-cover rounded-lg shadow-sm border border-border-subtle dark:border-gray-800" data-alt="Empower Monthly magazine cover with woman portrait" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDeU1qmf3tcYT68CiYKcQSck_LAjvGtaEh7QGR-_TMe-bwVxakWyC5eaNZJ6zaH6bfAZi2_S7Dc32wo3Efn5cjnmIOEdw-TfqlKMu54sT_oPRf_rh9-XwF8_LwGkXoVSVj2eTIS9gFLArlYXDa0N_SZMwzFttotYh8xCrs0z_WmAsNlhfSi9xgqBLIo4b2XMpViwiPDywJcWJZyd_sYmIEgAi5L7a06OMDjc6eSG8eiDM05w3w0C7QFePVvZEGYO998-C3m0qrT6nC0')"}}>
              </div>
            </div>
          </div>
        </section>
        <section className="mt-8 px-4 pb-12">
          <div className="bg-primary/5 dark:bg-primary/10 rounded-2xl p-6 border border-primary/20 flex flex-col items-center text-center">
            <span className="material-symbols-outlined text-4xl text-primary mb-2">groups</span>
            <h3 className="text-xl font-bold mb-2">Grow with our community</h3>
            <button onClick={() => setActiveView('shopno-gori-enrollment')} className="w-full bg-primary hover:bg-emerald-600 text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/20 transition-all active:scale-95">
              Enroll as Member
            </button>
          </div>
        </section>
      </main>
    </div>
  );
};

export default ShopnoGoriStoreView;
