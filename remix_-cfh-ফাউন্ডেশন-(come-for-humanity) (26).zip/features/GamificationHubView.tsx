
import React from 'react';
import { View } from '../types';

interface GamificationHubViewProps {
  setActiveView: (view: View) => void;
}

const CourseCard: React.FC<{ title: string; icon: string; }> = ({ title, icon }) => (
    <div className="bg-white dark:bg-card-dark p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 flex items-center gap-4">
        <div className="size-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-primary text-2xl">{icon}</span>
        </div>
        <h4 className="text-gray-900 dark:text-white font-bold text-sm leading-snug">{title}</h4>
    </div>
);


const GamificationHubView: React.FC<GamificationHubViewProps> = ({ setActiveView }) => {
    return (
        <div className="relative flex min-h-screen w-full flex-col max-w-[430px] mx-auto bg-background-light dark:bg-background-dark shadow-2xl font-display text-[#111718] dark:text-white">
            <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
                <div className="flex items-center p-4 justify-between">
                    <div className="flex items-center gap-3">
                        <button onClick={() => setActiveView('dashboard')} className="p-2 -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
                            <span className="material-symbols-outlined">arrow_back_ios_new</span>
                        </button>
                        <div>
                            <h1 className="text-lg font-bold leading-tight tracking-tight">RawNest IT Institute</h1>
                            <p className="text-[10px] uppercase tracking-widest text-primary font-bold">A CFH Social Business</p>
                        </div>
                    </div>
                </div>
            </header>

            <main className="flex-1 overflow-y-auto no-scrollbar pb-24">
                 <section className="p-4 mt-4">
                    <div onClick={() => setActiveView('course-detail')} className="bg-gradient-to-br from-primary to-blue-800 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden cursor-pointer group">
                        <div className="absolute -right-8 -bottom-8 size-32 bg-white/10 rounded-full transition-transform group-hover:scale-110"></div>
                        <div className="relative z-10">
                            <span className="bg-white/20 text-white text-[10px] font-bold px-2 py-1 rounded uppercase mb-3 inline-block">Featured Course</span>
                            <h3 className="text-2xl font-bold leading-tight">Advanced Cyber Security & Safe Internet</h3>
                            <p className="text-sm font-medium opacity-90 mt-2">Protect yourself and others from digital threats.</p>
                        </div>
                    </div>
                </section>

                 <section className="p-4 pt-4">
                     <h3 className="text-xl font-bold tracking-tight mb-4 px-1">Our Programs</h3>
                      <div className="space-y-3">
                         <CourseCard title="Web Development" icon="code" />
                         <CourseCard title="Mobile App Development" icon="phone_iphone" />
                         <CourseCard title="Cyber Security" icon="security" />
                         <CourseCard title="Digital Marketing" icon="campaign" />
                      </div>
                 </section>
                
                 <section className="p-4 pt-6">
                     <h3 className="text-xl font-bold tracking-tight mb-4 px-1">Student Hub</h3>
                      <div className="grid grid-cols-2 gap-3">
                        <button onClick={() => setActiveView('graduate-success-stories')} className="flex flex-col items-center justify-center gap-2 p-4 bg-amber-50 dark:bg-amber-900/20 rounded-xl border border-amber-100 dark:border-amber-900/30">
                            <span className="material-symbols-outlined text-amber-500 text-3xl">workspace_premium</span>
                            <span className="text-sm font-bold text-amber-700 dark:text-amber-300">Success Stories</span>
                        </button>
                        <button onClick={() => setActiveView('raw-nest-internship-form')} className="flex flex-col items-center justify-center gap-2 p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl border border-emerald-100 dark:border-emerald-900/30">
                            <span className="material-symbols-outlined text-emerald-500 text-3xl">work</span>
                            <span className="text-sm font-bold text-emerald-700 dark:text-emerald-300">Internship</span>
                        </button>
                         <button onClick={() => setActiveView('humanity-quiz')} className="col-span-2 flex items-center justify-center gap-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-900/30">
                            <span className="material-symbols-outlined text-blue-500 text-3xl">quiz</span>
                            <span className="text-sm font-bold text-blue-700 dark:text-blue-300">Take a Quiz</span>
                        </button>
                      </div>
                 </section>

            </main>
        </div>
    );
};

export default GamificationHubView;
