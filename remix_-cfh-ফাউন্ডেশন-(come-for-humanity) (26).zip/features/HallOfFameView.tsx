
import React from 'react';
import { View } from '../types';

interface HallOfFameViewProps {
    setActiveView: (view: View) => void;
}

const HallOfFameView: React.FC<HallOfFameViewProps> = ({ setActiveView }) => {
    const timelineEvents = [
        { year: '২০১৮', event: '১২ই সেপ্টেম্বর মানবতার সেবার লক্ষ্যে সিএফএইচ প্রতিষ্ঠিত হয় ও বিবিএস ব্লাড ব্যাংক চালু হয়।' },
        { year: '২০১৯', event: 'নারীদের ক্ষমতায়নের জন্য স্বপ্নগড়ি হস্তশিল্প উদ্যোগ শুরু হয়।' },
        { year: '২০২০', event: 'কোভিড-১৯ মহামারীর সময় বিনামূল্যে অক্সিজেন সেবা চালু হয়।' },
        { year: '২০২২', event: 'ডিজিটাল সাক্ষরতার জন্য সিএফএইচ আইটি স্কুলের উদ্বোধন।' },
        { year: '২০২৪', event: 'সমস্ত পরিষেবা একত্রিত করার জন্য সমন্বিত সুপার-অ্যাপ চালু হয়।' },
    ];

    return (
        <div className="bg-background-light dark:bg-background-dark min-h-screen text-gray-800 dark:text-white">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
                <button onClick={() => setActiveView('dashboard')} className="size-10 flex items-center justify-center">
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>
                <h1 className="text-lg font-bold font-bengali">আমাদের সম্পর্কে</h1>
                <div className="w-10"></div>
            </header>

            <main className="p-4 space-y-6 pb-24">
                {/* Founder's Section */}
                <section className="bg-white dark:bg-card-dark rounded-2xl shadow-sm p-6 border border-gray-100 dark:border-gray-800">
                    <div className="flex flex-col sm:flex-row items-center gap-6 text-center sm:text-left">
                        <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuDKyNi_qmDZt1B4lgJPERorTKYBgTnVBgQeo_LeQxm6pAeoO2g292c7QSRiTLiw23OWFYlOXgUTUv96CHPUXW3BWABsU37SrwT9_2j-Rcc7S7400uhRJkw8JbxD29KlNKht3xZjDPQmGq4sqefAqnRaieg-NFsJKraoKgOfwROdbxP1Fgmlt63CiHKqJKl0kA1OWIeOQ0RpVv24QUR8JG8x4GAqU_TyPxmvvG658V1gksnSEFRywK2qAxtPpxwoChAM79pi_m5NC6Oz" alt="Founder Portrait" className="w-32 h-32 rounded-full border-4 border-primary/20 object-cover flex-shrink-0" />
                        <div>
                            <h2 className="text-2xl font-bold text-primary font-bengali">মামুন অর রশিদ বিজন</h2>
                            <p className="text-md text-gray-600 dark:text-gray-300 font-medium font-bengali">প্রতিষ্ঠাতা চেয়ারম্যান, মানবতার জন্য আসুন (CFH)</p>
                            <p className="mt-3 text-gray-700 dark:text-gray-400 text-sm italic border-l-2 border-primary/30 pl-3 font-bengali">
                                "আমাদের লক্ষ্য এমন একটি বাংলাদেশ দেখা যেখানে কেউ ক্ষুধার্ত থাকবে না এবং প্রতিটি শিশুর হাতে কলম থাকবে। প্রযুক্তি এবং সহানুভূতির মাধ্যমে আমরা এই স্বপ্নকে বাস্তবে রূপ দিচ্ছি।"
                            </p>
                        </div>
                    </div>
                </section>
                
                {/* About Us Description */}
                <section className="bg-white dark:bg-card-dark rounded-2xl shadow-sm p-6 border border-gray-100 dark:border-gray-800">
                    <h3 className="text-xl font-bold text-gray-800 dark:text-white font-bengali mb-3">আমাদের লক্ষ্য</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed font-bengali">
                        'মানবতার জন্য আসুন' (CFH) একটি অলাভজনক সংস্থা যা রক্তদান, জরুরি অক্সিজেন সরবরাহ, স্বাস্থ্যসেবা, সামাজিক ব্যবসা, এবং শিক্ষাসহ বিভিন্ন উদ্যোগের মাধ্যমে মানবতার সেবায় নিবেদিত। আমরা একটি সহানুভূতিশীল এবং প্রযুক্তি-চালিত পদ্ধতির মাধ্যমে বাংলাদেশের প্রতিটি কোণায় ইতিবাচক পরিবর্তন আনতে এবং টেকসই উন্নয়ন নিশ্চিত করতে প্রতিশ্রুতিবদ্ধ।
                    </p>
                </section>
                
                {/* Managing Committee Link */}
                <section>
                    <button onClick={() => setActiveView('committee-directory')} className="w-full bg-white dark:bg-card-dark rounded-2xl shadow-sm p-6 border border-gray-100 dark:border-gray-800 flex items-center justify-between hover:border-primary transition-colors">
                        <div className="flex items-center gap-4">
                            <div className="size-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                                <span className="material-symbols-outlined text-3xl">groups</span>
                            </div>
                            <div>
                                <h3 className="text-lg font-bold text-gray-800 dark:text-white font-bengali text-left">পরিচালনা কমিটি</h3>
                                <p className="text-sm text-gray-500 dark:text-gray-400 font-bengali text-left">আমাদের নেতৃত্ব দেখুন</p>
                            </div>
                        </div>
                        <span className="material-symbols-outlined text-gray-400">chevron_right</span>
                    </button>
                </section>

                {/* Timeline */}
                <section>
                    <h3 className="text-xl font-bold text-gray-800 dark:text-white font-bengali text-center mb-6">আমাদের যাত্রা (২০১৮ - বর্তমান)</h3>
                    <div className="relative">
                        <div className="absolute left-4 sm:left-1/2 -translate-x-1/2 h-full w-0.5 bg-primary/20"></div>

                        {timelineEvents.map((item, index) => (
                            <div key={index} className="relative mb-6 flex items-start w-full">
                                <div className="z-10 absolute left-4 sm:left-1/2 -translate-x-1/2 bg-white dark:bg-background-dark border-4 border-primary rounded-full w-8 h-8 flex items-center justify-center">
                                    <p className="font-bold text-xs text-primary">{item.year}</p>
                                </div>
                                <div className="order-2 w-full ml-10 sm:ml-0 sm:w-5/12 sm:text-left pl-4 sm:pl-0">
                                    {index % 2 !== 0 && (
                                    <div className="p-4 bg-white dark:bg-card-dark border border-gray-100 dark:border-gray-800 rounded-lg shadow-sm sm:ml-12">
                                        <p className="font-semibold text-sm text-gray-700 dark:text-gray-300 font-bengali">{item.event}</p>
                                    </div>
                                    )}
                                </div>
                                <div className="hidden sm:block order-1 w-5/12 text-right">
                                     {index % 2 === 0 && (
                                    <div className="p-4 bg-white dark:bg-card-dark border border-gray-100 dark:border-gray-800 rounded-lg shadow-sm sm:mr-12">
                                        <p className="font-semibold text-sm text-gray-700 dark:text-gray-300 font-bengali">{item.event}</p>
                                    </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </section>
            </main>
        </div>
    );
};

export default HallOfFameView;
