import React from 'react';
import { View } from '../types';

interface ArchiveViewProps {
  setActiveView: (view: View) => void;
}

const ArchiveView: React.FC<ArchiveViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display pb-12">
      <header className="sticky top-0 z-50 bg-primary text-white px-5 pt-12 pb-6 rounded-b-xl shadow-lg">
        <div className="flex items-center justify-between">
          <button onClick={() => setActiveView('dashboard')} className="flex items-center gap-3">
            <div className="size-10 bg-white rounded-lg flex items-center justify-center">
              <span className="material-symbols-outlined text-primary text-2xl font-bold">volunteer_activism</span>
            </div>
            <div><h1 className="text-xl font-bold leading-none tracking-tight">CFH Archive</h1></div>
          </button>
        </div>
      </header>
      <main>
        <div className="px-5 pt-8 pb-2">
          <h2 className="text-2xl font-bold text-[#101815] dark:text-white">Newsletter & Impact</h2>
        </div>
        <div className="flex flex-col gap-5 px-5 mt-2">
            <div className="group flex flex-col gap-0 rounded-xl bg-white dark:bg-zinc-900 overflow-hidden shadow-sm border border-gray-100 dark:border-zinc-800">
                <div className="relative w-full aspect-[16/9] bg-center bg-cover" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAgieJVoKIf0mQCM9s1LX1kvwINEADmo0aQgV50-V7SySo7AxM5-ry-ZMH4w72i4fXFpfh9sHjDEHf7sQcEujb22oB9-j8c_F9FYR78p1kqtoZ3N3HWzrGyMiyiE0HeknnTmj7ikEc0yz_UW5ULFrdid4ItNNSXUvCBJdg-1QLBBSQc-qSkJ2HQvfD53mnIpFTS6iqbWkOInDJ1PTdh5Vbyy-wv0X3zSiZEBeVwLlez6GPdyZ0UpRRbQKJcbk6lUbHdl0iiELBsOlCW')"}}></div>
                <div className="p-5 flex flex-col gap-3">
                    <h3 className="text-lg font-bold leading-snug text-[#101815] dark:text-white">Impact Story: Meherpur Clinic</h3>
                </div>
            </div>
        </div>
      </main>
    </div>
  );
};

export default ArchiveView;