import React from 'react';
import { View } from '../types';

interface SeniorCouncilViewProps {
  setActiveView: (view: View) => void;
}

const SeniorCouncilView: React.FC<SeniorCouncilViewProps> = ({ setActiveView }) => {
  const members = [
    { name: 'Dr. Rahman', bengaliName: 'ডঃ রহমান', title: 'Founder Chairman', bengaliTitle: 'প্রতিষ্ঠাতা চেয়ারম্যান', imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBwiS1yPC8-vFpGibwasePSNAFDpZUOCpojrTilTJpLwbH1WhMWVbjQp0CpyilUGnlxZcBp_r1Eb_npINPaq--fYJHcAKSrTI2t6MT0q_MZOAB69OE7RBP1YSJCTzfndvne0vUL5vCaLJJRO3EnRixe5Cm3t09mD6SiX8R30en19t5Yz14-vAvYHYLZRiKPitHQL-p9EffKQETrzFSzd8Lisq029aM669_8h0h1CTQQpbAGotpXfwmz3gosSYCducqQVfnRKxlO4L4o" },
    { name: 'Sarah Ahmed', bengaliName: 'সারা আহমেদ', title: 'Executive Director', bengaliTitle: 'নির্বাহী পরিচালক', imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBqFqsEHfbF_A9SGKW_QLh6SC7aRjL5TU8k6E7LcVjJwyrP4LuJqeQbWGqEOiYOkW7t6TgLdlf-xo65Q1nVUHdhnaxNHnH5qytwrYlwXlOz7YNEW8wFRsghpAAXs2BvJOw-5mbBEzjtACRJJdTcaNh7jR3EN4o7Ibf_DqL3QlxiSiNlG5ZBPRbwzscPkTVmOTWWa3AYjO3JsSnxC78-3-SIUcye2XXwbn9r-yTd2X5Z8Ut8ik_rT35aAdJt6F_fbtyEBvIU0lB9eroF" },
    { name: 'Prof. Kabir', bengaliName: 'অধ্যাপক কবির', title: 'Senior Advisor', bengaliTitle: 'সিনিয়র উপদেষ্টা', imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuD2POIfzuFVS6yWNGDocN6VR2OrpuIivLhuh20-oAxJHKxrjagLuw49M1fSAm19ZW6dPNc92vd3Exj0yZUa_eAEzMr6SB0EWv2yhPhNC-gHEREjr0YNfm14eEg-GnqORJVREhy4ozxyNFXOA8IIA4zIa920aqWfwRhm1ltDDmBnx3nk83zQntaY2JPPjid0DLbYxfUKyldDs2CgeWj9bv_BYnPp2K__ImHz3eqGEwXPBq2LAMDXCkJQBc_IzI432ajQZ8Q0xnQp4YyI" },
    { name: 'Anisul Huq', bengaliName: 'আনিসুল হক', title: 'Chief Consultant', bengaliTitle: 'প্রধান পরামর্শক', imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDJew6UKIZwVzxm9t9-lfpz6KpAcBDsgpuiTuyF9I1BqDNSJNSBuENdMhITbCieB8wTtyj-Re-KjTBRewR36jr7a-bysdvtxl70rL-piCsQOcV0gLfarrKCNbbUW2O3ZZTd4NGqhfs79Eb4p2yGlAmcRwR1ISleK-lbn4ExtUu8CUVJYlhITOPPLgLhQwo_3Il1y_VCwWB4LLAXucDA_2F2iKV35OXYecp0RSue1SVubp10OjY8lZynzh-e2-OUG8AiU8onxwywU2ka" },
  ];
  return (
    <div className="bg-background-light dark:bg-background-dark min-h-screen text-slate-900 dark:text-slate-100 pb-12">
      <header className="sticky top-0 z-50 bg-primary shadow-lg px-4 py-3 flex items-center justify-between border-b border-accent-gold/30">
        <button onClick={() => setActiveView('hall-of-fame')} className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center p-1 overflow-hidden">
             <div className="w-full h-full bg-primary rounded-full flex items-center justify-center text-white"><span className="material-symbols-outlined text-sm">arrow_back</span></div>
          </div>
          <div>
            <h1 className="text-white text-sm font-bold leading-tight tracking-tight">Come For Humanity</h1>
            <p className="text-accent-gold text-[10px] uppercase tracking-widest font-bold">Senior Council</p>
          </div>
        </button>
      </header>
      <main>
        <div className="relative w-full h-48 bg-primary overflow-hidden flex flex-col justify-center items-center text-center px-6">
          <h2 className="text-white text-2xl font-bold relative z-10 mb-1 font-bengali">আমাদের সিনিয়র সদস্যবৃন্দ</h2>
          <h3 className="text-accent-gold text-lg italic font-display relative z-10">Council of Senior Members</h3>
        </div>
        <div className="grid grid-cols-2 gap-4 p-4">
          {members.map(member => (
            <div key={member.name} className="bg-white dark:bg-slate-800 rounded-lg p-4 shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col items-center text-center">
              <div className="relative mb-4">
                <div className="w-24 h-24 rounded-full border-[3px] border-accent-gold p-1 overflow-hidden">
                  <div className="w-full h-full rounded-full bg-center bg-cover" style={{backgroundImage: `url("${member.imageUrl}")`}}></div>
                </div>
              </div>
              <h4 className="text-primary dark:text-accent-gold text-sm font-bold">{member.name}</h4>
              <p className="bengali-text text-slate-800 dark:text-slate-200 text-xs font-medium mb-2">{member.bengaliName}</p>
              <div className="w-full h-px bg-slate-100 dark:bg-slate-700 my-2"></div>
              <p className="text-[10px] text-slate-500 uppercase tracking-tighter">{member.title}</p>
              <p className="bengali-text text-[10px] text-slate-400">{member.bengaliTitle}</p>
            </div>
          ))}
        </div>
        <div className="p-6 text-center">
          <button onClick={() => setActiveView('committee-application')} className="bg-primary text-white px-8 py-3 rounded-lg font-bold shadow-md hover:bg-primary/90 transition-colors flex items-center justify-center gap-2 mx-auto">
            <span className="material-symbols-outlined">group_add</span>
            Join the Council
          </button>
        </div>
      </main>
      <style>{`.bengali-text { font-family: 'Noto Sans Bengali', sans-serif; }`}</style>
    </div>
  );
};

export default SeniorCouncilView;