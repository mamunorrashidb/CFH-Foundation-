
import React from 'react';
import { View } from '../types';

interface ProbashiHubViewProps {
  setActiveView: (view: View) => void;
}

const ProbashiHubView: React.FC<ProbashiHubViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-[#121317] dark:text-white min-h-screen pb-24">
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-[#dcdee5] dark:border-white/10">
        <div className="flex items-center p-4 justify-between max-w-lg mx-auto">
          <button onClick={() => setActiveView('dashboard')} className="flex size-10 shrink-0 items-center">
            <div className="bg-primary rounded-lg flex items-center justify-center size-9 text-white shadow-sm">
              <span className="material-symbols-outlined">diversity_3</span>
            </div>
          </button>
          <div className="flex-1 px-3">
            <h1 className="text-primary dark:text-blue-400 text-lg font-bold leading-none tracking-tight">Probashi Hub</h1>
            <p className="text-[10px] text-[#656d86] dark:text-gray-400 font-medium uppercase tracking-wider font-bengali">প্রবাসী হাব • The Light of Humanity</p>
          </div>
        </div>
      </header>
      <main className="max-w-lg mx-auto">
        <div className="px-4 pt-6 pb-2">
          <h2 className="text-2xl font-bold leading-tight">Find your way home</h2>
          <p className="text-[#656d86] dark:text-gray-400 text-sm font-bengali">সহজে এবং নিরাপদে দেশে ফিরুন</p>
        </div>
        <div className="p-4">
          <button className="w-full bg-primary text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/20">
            Search Flights / ফ্লাইট খুঁজুন
          </button>
        </div>
        <div className="p-4">
            <div onClick={() => setActiveView('family-security-request')} className="bg-primary/5 rounded-xl border border-primary/20 p-4 flex items-start gap-4 cursor-pointer">
                <div className="bg-primary text-white p-2 rounded-lg"><span className="material-symbols-outlined">shield_person</span></div>
                <div>
                    <h4 className="text-sm font-bold text-primary">Family Security Included</h4>
                    <p className="text-xs text-[#656d86] mt-1">All Probashi Hub bookings include 24/7 family protection & medical emergency support in Bangladesh.</p>
                </div>
            </div>
        </div>
      </main>
      <nav className="fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-background-dark/95 backdrop-blur-lg border-t border-[#dcdee5] dark:border-white/10 pb-6">
        <div className="max-w-lg mx-auto flex justify-around p-2">
          <a className="flex flex-col items-center gap-1 text-primary" href="#"><span className="material-symbols-outlined text-[26px]">home</span><span className="text-[10px] font-bold uppercase tracking-tight">Home</span></a>
          <a className="flex flex-col items-center gap-1 text-[#656d86] dark:text-gray-400" href="#"><span className="material-symbols-outlined text-[26px]">airplane_ticket</span><span className="text-[10px] font-bold uppercase tracking-tight">Bookings</span></a>
          <a className="flex flex-col items-center gap-1 text-[#656d86] dark:text-gray-400" href="#"><span className="material-symbols-outlined text-[26px]">health_and_safety</span><span className="text-[10px] font-bold uppercase tracking-tight">Security</span></a>
          <a className="flex flex-col items-center gap-1 text-[#656d86] dark:text-gray-400" href="#"><span className="material-symbols-outlined text-[26px]">account_circle</span><span className="text-[10px] font-bold uppercase tracking-tight">Profile</span></a>
        </div>
      </nav>
    </div>
  );
};

export default ProbashiHubView;
