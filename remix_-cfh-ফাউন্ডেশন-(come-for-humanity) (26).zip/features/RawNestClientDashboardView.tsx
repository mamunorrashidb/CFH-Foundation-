import React from 'react';
import { View } from '../types';

interface RawNestClientDashboardViewProps {
  setActiveView: (view: View) => void;
}

const RawNestClientDashboardView: React.FC<RawNestClientDashboardViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-[430px] mx-auto bg-white dark:bg-background-dark shadow-2xl overflow-x-hidden">
        <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-[#dddfe3] dark:border-white/10 px-4 py-3">
            <div className="flex items-center justify-between">
                <button onClick={() => setActiveView('ecommerce')} className="p-2 -ml-2"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-primary dark:text-white text-sm font-bold leading-tight">RawNest Client</h1>
                <div className="w-8"></div>
            </div>
        </header>
        <main className="flex-1 pb-8">
            <div className="grid grid-cols-2 gap-3 p-4">
                <div className="col-span-2 flex flex-col gap-1 bg-white dark:bg-white/5 rounded-xl p-4 border border-[#dddfe3] dark:border-white/10 shadow-sm">
                    <p className="text-3xl font-bold">3 Active Projects</p>
                </div>
            </div>
            <section className="px-4 py-2">
                <h2 className="text-primary dark:text-white text-lg font-bold leading-tight mb-3">Project Timeline</h2>
                <div className="bg-white dark:bg-white/5 rounded-xl border border-[#dddfe3] dark:border-white/10 p-4">
                     <div className="h-6 w-full bg-gray-100 dark:bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[75%] rounded-full"></div>
                    </div>
                </div>
            </section>
        </main>
    </div>
  );
};

export default RawNestClientDashboardView;