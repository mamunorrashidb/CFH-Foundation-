
import React from 'react';
import { View } from '../types';

interface LiveStreamViewProps {
  setActiveView: (view: View) => void;
}

const LiveStreamView: React.FC<LiveStreamViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-[480px] mx-auto border-x border-gray-100 dark:border-gray-800 shadow-2xl bg-background-light dark:bg-background-dark">
        <header className="sticky top-0 z-50 flex items-center bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md p-4 pb-2 justify-between border-b border-gray-100 dark:border-gray-800">
            <button onClick={() => setActiveView('dashboard')} className="text-[#111317] dark:text-white flex size-12 shrink-0 items-center justify-start">
                <span className="material-symbols-outlined text-2xl">arrow_back_ios</span>
            </button>
            <h2 className="text-[#111317] dark:text-white text-lg font-bold leading-tight tracking-tight flex-1 text-center">Meherpur Live Media</h2>
            <div className="w-12"></div>
        </header>
        <div className="relative w-full aspect-video bg-black overflow-hidden shadow-lg">
            <div className="absolute inset-0 bg-cover bg-center" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAdU427F4Hux1jmZEG4YGKbH2aoPVzY1dH0bbZXTLnQ-H0WM9vKPByzDDwLJ3qkxYKu1MLhRlfCJO1FrieYLw0iJRYUdAmmySIcXqbrjXDUdxp7Zp5EZ5BUN42MnPja7iDp_mJ7nSLmbXrkpP-AsB5PPeL8sgG9QQ8-2vs2uz8tLyZDCrX-mBAmhCBtipdoTNABgjHlmQNxFJ9fNvrpAJ_uTL0eGbnpJfvVf5eoUC7iQrAkyRD-ovQeBfzwA1RZC0MFwjG8WTj0DgtV')"}}></div>
            <div className="absolute top-4 left-4 z-10 flex items-center gap-1.5 bg-[#E50000] text-white px-2.5 py-1 rounded-md text-[10px] font-extrabold tracking-widest animate-pulse">LIVE</div>
        </div>
        <div className="bg-background-light dark:bg-background-dark pt-5">
            <h3 className="text-2xl font-extrabold leading-tight px-4 text-left">Meherpur District Development: Exclusive Update</h3>
        </div>
        <div className="px-4 py-6">
            <h2 className="text-lg font-extrabold leading-tight tracking-tight mb-4">Recent Video Updates</h2>
            <div className="flex flex-col gap-5">
                 <div className="flex gap-4 group cursor-pointer">
                    <div className="relative w-32 h-20 shrink-0 rounded-lg overflow-hidden bg-gray-100 shadow-sm">
                        <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDlq3_BRff8NL7887tKGSbXtr6mmBuf-_EwavCYlpDG9iqHx7aSsXLlV3toEOM7GJOleCnorN4ZvBH7LFEDrjrR8lCvwBay8sY2Onbjrql9HvPWTQMKiLIJ9pFcG9vGwG2Dk6TTGiL0RXWe6QBrNw0NVqwd1SmgtzDisE12Wtjg12Wx9yBdbBXBX_MTmg4mSD1wB5xzrEj-EH2knu-C73NfzJKNrxsNY2HnfLKzDK_xUtv1RaEenDWvJSB1ZKUjafEXOo8f6lrIkysT"/>
                    </div>
                    <h4 className="text-sm font-bold leading-snug line-clamp-2">Weekly Market Trends: Price stability reported</h4>
                 </div>
            </div>
        </div>
    </div>
  );
};

export default LiveStreamView;
