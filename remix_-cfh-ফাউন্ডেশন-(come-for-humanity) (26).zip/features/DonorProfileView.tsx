
import React from 'react';
import { View } from '../types';

interface DonorProfileViewProps {
  setActiveView: (view: View) => void;
}

const DonorProfileView: React.FC<DonorProfileViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark min-h-screen flex flex-col font-display max-w-md mx-auto">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
        <button onClick={() => setActiveView('blood-bank')} className="flex items-center text-primary">
          <span className="material-symbols-outlined text-[28px]">chevron_left</span>
          <span className="text-lg font-medium">Back</span>
        </button>
        <h1 className="text-[#121417] dark:text-white text-lg font-bold tracking-tight">Donor Profile</h1>
        <div className="w-12 flex justify-end">
          <button className="text-[#121417] dark:text-white">
            <span className="material-symbols-outlined">more_horiz</span>
          </button>
        </div>
      </header>
      <main className="flex-1 pb-40">
        <div className="p-6 flex flex-col items-center">
          <div className="relative">
            <div className="size-32 rounded-full overflow-hidden border-4 border-white dark:border-gray-800 ios-shadow bg-gray-100" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCHEVQixGlCgQPRVNDkNaB68kiMOKgG_MnjHsDkuVC17ooDUQqkFgj61MCiwhwOHqDGx6m_qQ9h9PexViEpoZ0osTNyPkveadz_45RyzK73YvpiNl0GBex0r6jpzT2xh2-DrR7WNG1r8S2h4ycRmoK_btL74gsMus6hvkeDI67QmKWAZdyxblS3QgUl_2noeCFcgl00khPs1iJ5xFtlNhzDr_AbAu6QkCF30pqwXpeAoLyD4DM-QIl1hJJ1Eyo-rn4bWk8qqf9CYBCD')", backgroundSize: 'cover', backgroundPosition: 'center'}}></div>
            <div className="absolute bottom-1 right-1 bg-primary text-white size-8 rounded-full flex items-center justify-center border-2 border-white dark:border-gray-800">
              <span className="material-symbols-outlined text-sm">verified</span>
            </div>
          </div>
          <div className="mt-4 text-center">
            <h2 className="text-2xl font-extrabold text-[#121417] dark:text-white">Marcus Sterling</h2>
            <div className="mt-1 flex items-center justify-center gap-2">
              <span className="px-3 py-1 bg-red-50 text-red-600 dark:bg-red-900/30 dark:text-red-400 text-sm font-bold rounded-full">O Negative</span>
              <span className="text-gray-400 text-sm">•</span>
              <span className="text-gray-500 dark:text-gray-400 text-sm font-medium">Verified Donor</span>
            </div>
          </div>
        </div>
        <div className="px-4 grid grid-cols-3 gap-3">
            <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-xl flex flex-col items-center justify-center border border-gray-100 dark:border-gray-700">
                <span className="text-gray-500 dark:text-gray-400 text-[10px] uppercase font-bold tracking-wider mb-1">Distance</span>
                <span className="text-primary text-lg font-extrabold">2.4 km</span>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-xl flex flex-col items-center justify-center border border-gray-100 dark:border-gray-700">
                <span className="text-gray-500 dark:text-gray-400 text-[10px] uppercase font-bold tracking-wider mb-1">Match</span>
                <span className="text-primary text-lg font-extrabold">100%</span>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-xl flex flex-col items-center justify-center border border-gray-100 dark:border-gray-700">
                <span className="text-gray-500 dark:text-gray-400 text-[10px] uppercase font-bold tracking-wider mb-1">Recent</span>
                <span className="text-primary text-lg font-extrabold">3mo ago</span>
            </div>
        </div>
        <div className="mt-6 px-4 space-y-3">
          <div className="flex items-center gap-4 bg-white dark:bg-gray-800/30 p-4 rounded-xl border border-gray-100 dark:border-gray-700">
            <div className="size-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary shrink-0">
              <span className="material-symbols-outlined">schedule</span>
            </div>
            <div className="flex-1">
              <p className="text-[#121417] dark:text-white text-base font-bold">Availability Status</p>
              <p className="text-gray-500 dark:text-gray-400 text-sm">On-call for emergencies</p>
            </div>
            <div className="size-3 rounded-full bg-emerald-500 animate-pulse"></div>
          </div>
        </div>
      </main>
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md p-6 pb-10 bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl border-t border-gray-100 dark:border-gray-800 flex flex-col gap-4">
        <div className="grid grid-cols-1 gap-3">
          <button className="w-full h-14 bg-primary text-white rounded-xl font-bold text-lg flex items-center justify-center gap-2 active:scale-95 transition-transform ios-shadow">
            <span className="material-symbols-outlined">call</span> Direct Call
          </button>
          <button className="w-full h-14 bg-emerald-alert text-white rounded-xl font-bold text-lg flex items-center justify-center gap-2 active:scale-95 transition-transform ios-shadow">
            <span className="material-symbols-outlined">notification_important</span> Send Emergency Alert
          </button>
        </div>
      </div>
      <style>{`
        :root {
          --primary: #2b60a1;
          --emerald-alert: #00B894;
        }
        .ios-shadow { box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
      `}</style>
    </div>
  );
};

export default DonorProfileView;
