
import React, { useState, useEffect } from 'react';
import { View } from '../types';
import { db } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';

interface NewsAndRemindersViewProps {
  setActiveView: (view: View) => void;
}

interface NewsItem {
    id: string;
    title: string;
    content: string;
    publishedAt: string;
}

const NewsAndRemindersView: React.FC<NewsAndRemindersViewProps> = ({ setActiveView }) => {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'news'), orderBy('publishedAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
        const newsData = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        })) as NewsItem[];
        setNews(newsData);
        setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return (
    <div className="relative mx-auto min-h-screen max-w-[480px] flex flex-col bg-white dark:bg-background-dark shadow-xl overflow-x-hidden">
      <header className="sticky top-0 z-20 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center px-4 py-4 justify-between">
          <button onClick={() => setActiveView('dashboard')} className="flex items-center justify-center size-10 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer transition-colors">
            <span className="material-symbols-outlined text-2xl">arrow_back_ios_new</span>
          </button>
          <h1 className="text-lg font-bold tracking-tight font-bengali">খবর ও আপডেট</h1>
          <div className="w-10"></div>
        </div>
      </header>
      <main className="flex-1 overflow-y-auto pb-24">
        <section className="mt-6 px-4">
          <h2 className="text-[20px] font-extrabold leading-tight tracking-tight mb-4 font-bengali">পরবর্তী রক্তদান ক্যাম্পেইন</h2>
          <div className="group relative overflow-hidden rounded-2xl bg-primary/10 dark:bg-primary/5 p-5 border border-primary/20">
            <div className="flex items-start justify-between gap-4">
              <div className="flex flex-col">
                <span className="text-primary text-5xl font-extrabold tracking-tighter">১২</span>
                <span className="text-primary/70 text-sm font-semibold uppercase tracking-wider mt-1 font-bengali">দিন বাকি</span>
              </div>
              <div className="size-16 rounded-2xl bg-primary text-white flex items-center justify-center shadow-lg">
                <span className="material-symbols-outlined text-3xl">calendar_today</span>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-10">
          <div className="px-4 mb-6">
            <h2 className="text-[20px] font-extrabold leading-tight tracking-tight font-bengali">প্রেস রিলিজ ও সংবাদ</h2>
          </div>
          
          <div className="px-4 space-y-4">
            {loading ? (
                <div className="text-center py-10 text-gray-500 font-bengali">খবর লোড হচ্ছে...</div>
            ) : news.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border-2 border-dashed border-gray-200 dark:border-gray-700">
                    <span className="material-symbols-outlined text-4xl text-gray-300 mb-2">newspaper</span>
                    <p className="text-gray-400 font-bengali">বর্তমানে কোনো খবর নেই</p>
                </div>
            ) : (
                news.map(item => (
                    <div key={item.id} className="group p-5 bg-white dark:bg-card-dark rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-md transition-all">
                        <div className="flex items-center gap-2 mb-2">
                            <span className="bg-primary/10 text-primary text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">News</span>
                            <span className="text-[10px] text-gray-400 font-medium">{new Date(item.publishedAt).toLocaleDateString('bn-BD')}</span>
                        </div>
                        <h3 className="text-md font-bold text-gray-800 dark:text-white leading-snug font-bengali mb-2">{item.title}</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-3 font-bengali leading-relaxed">
                            {item.content}
                        </p>
                        <button className="mt-4 text-xs font-bold text-primary flex items-center gap-1 font-bengali">
                            বিস্তারিত পড়ুন
                            <span className="material-symbols-outlined text-sm">arrow_forward</span>
                        </button>
                    </div>
                ))
            )}
          </div>
        </section>
      </main>
    </div>
  );
};

export default NewsAndRemindersView;
