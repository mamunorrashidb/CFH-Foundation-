
import React from 'react';
import { View } from '../types';

interface VideoCallViewProps {
  setActiveView: (view: View) => void;
}

const VideoCallView: React.FC<VideoCallViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative h-screen w-full flex flex-col overflow-hidden max-w-[430px] mx-auto shadow-2xl border-x border-white/5 bg-background-dark font-display text-white">
        <div className="absolute inset-0 z-0">
            <div className="w-full h-full bg-cover bg-center" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDFRTkkXql_D_StbXYJnvrNVXbD5WLvyG5yW9aXZZqALiK1G0unXK7rxhQ8F2d89r51CdhjTgEc006TtnPiYhXz9K1YkaCBAtP8k8J3KyKEXJVHR0EPCm2aC3L6YWzDY3E3ovyNBpCr9BD3gCEnm4c0S9SWBVB6RB5I7y2C81VxmFXxJGTka-p0Pb2wQ4WENecklhkE6cwjNvoTftr34eJLlF6CNRzQ3SGKbVCYE-u2KsZ-ev0buy36xQuoQFVYZXL4k9Ruix-Aq6if')"}}></div>
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60"></div>
        </div>
        <div className="relative z-20 flex items-center justify-between p-6 pt-12">
            <div className="flex items-center gap-3 glass p-2 px-4 rounded-full">
                <div className="flex items-center gap-2">
                    <span className="size-2 rounded-full bg-red-500 animate-pulse"></span>
                    <span className="text-sm font-semibold tracking-wider">24:12</span>
                </div>
            </div>
             <button onClick={() => setActiveView('digital-prescription')} className="glass size-12 flex items-center justify-center rounded-xl text-white hover:bg-white/10 transition-colors">
                <span className="material-symbols-outlined text-2xl">description</span>
            </button>
        </div>
        <div className="relative z-20 mt-auto px-6 mb-4">
            <div className="flex flex-col">
                <h1 className="text-xl font-bold text-white drop-shadow-md">Dr. Aris Thorne</h1>
                <p className="text-white/80 text-sm font-medium drop-shadow-sm">Senior Cardiologist • CFH Medical</p>
            </div>
        </div>
        <div className="absolute top-32 right-6 z-30 w-28 aspect-[3/4] rounded-xl overflow-hidden shadow-2xl border border-white/20 ring-4 ring-black/20">
            <div className="w-full h-full bg-cover bg-center" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuC4Am7u2ZLDQkUdKyUEqFy1iM8AkcEMzUqqUa1DZyRDaCEpSgDNov_sxiiLjLRRPCvXvGJ7G8PXYzDYgAqAvDFmAriLc0RmgGNHSCz1QAlQGXaSIdaHwXRQHl5IvNpm3GP2nvwc4w7r4_X4TZdNfEb8T8f0KVV7pULW7jdljSd4iJOo7EmM_3D-uNyA2ZCKIoKFXFU1MR4bJcT_-SUiZdjdGxpfxY3cVPIwXmRYOBkt9KI6rVlI1H3pfJlUe6eStDSKTSNApbrwu8Dm')"}}></div>
        </div>
        <div className="relative z-30 px-6 pb-12">
            <div className="glass p-4 rounded-3xl flex items-center justify-between gap-2">
                <button className="flex flex-col items-center gap-1 group">
                    <div className="size-12 rounded-full bg-white/10 flex items-center justify-center"><span className="material-symbols-outlined text-white">mic</span></div>
                </button>
                <button onClick={() => setActiveView('telemedicine')} className="flex flex-col items-center gap-1 group">
                    <div className="size-14 rounded-2xl bg-red-600 flex items-center justify-center">
                        <span className="material-symbols-outlined text-white text-3xl rotate-[135deg]">call</span>
                    </div>
                </button>
            </div>
        </div>
        <style>{`
            .glass { background: rgba(28, 30, 34, 0.6); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.1); }
            .fill-icon { font-variation-settings: 'FILL' 1; }
        `}</style>
    </div>
  );
};

export default VideoCallView;
