
import React from 'react';
import { View } from '../types';

interface ProjectFundingTrackerViewProps {
  setActiveView: (view: View) => void;
}

const ProjectFundingTrackerView: React.FC<ProjectFundingTrackerViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-[#111317] dark:text-white transition-colors duration-200">
      <header className="sticky top-0 z-50 bg-primary px-4 py-4 flex items-center justify-between shadow-md">
        <button onClick={() => setActiveView('sdg-projects')} className="flex items-center gap-3">
          <span className="material-symbols-outlined text-white text-2xl">account_balance_wallet</span>
          <h1 className="text-white text-lg font-bold tracking-tight">CFH Invest</h1>
        </button>
      </header>
      <main className="pb-24">
        <div className="grid grid-cols-2 gap-3 p-4">
          <div className="bg-white dark:bg-background-dark/50 border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-sm">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Total Raised</p>
            <p className="text-2xl font-bold mt-1">$2.15M</p>
          </div>
          <div className="bg-white dark:bg-background-dark/50 border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-sm">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Active Projects</p>
            <p className="text-2xl font-bold mt-1">12</p>
          </div>
        </div>
        <div className="px-4 pt-2">
          <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4">Active Humanitarian Projects</h3>
          <div className="space-y-4">
            <div onClick={() => setActiveView('investment-project-detail')} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm border-l-4 border-l-emerald cursor-pointer">
              <h4 className="text-lg font-bold mt-1">Raw Food Bd Organic Farm Expansion</h4>
              <p className="text-sm text-gray-500 mt-1">Gazipur, Bangladesh</p>
              <div className="w-full h-3 bg-emerald/10 dark:bg-emerald/20 rounded-full overflow-hidden mt-4">
                <div className="h-full bg-emerald rounded-full" style={{ width: '85%' }}></div>
              </div>
               <div className="flex justify-between mt-2 text-[11px] font-medium text-gray-400">
                    <span>Target: ৳ 5,00,000</span>
                    <span>85% funded</span>
                </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProjectFundingTrackerView;
