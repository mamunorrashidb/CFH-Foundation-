
import React from 'react';
import { View } from '../types';

interface GraduateSuccessStoriesViewProps {
  setActiveView: (view: View) => void;
}

const GraduateSuccessStoriesView: React.FC<GraduateSuccessStoriesViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-[#111317] dark:text-white min-h-screen">
        <nav className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800 px-4 py-3">
            <div className="flex items-center justify-between max-w-md mx-auto">
                 <button onClick={() => setActiveView('gamification-hub')} className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-tech font-bold text-lg">R</div>
                    <span className="text-xs font-bold tracking-tighter text-primary uppercase leading-none">RawNest</span>
                </button>
            </div>
        </nav>
        <header className="px-5 pt-8 pb-4 max-w-md mx-auto">
            <h2 className="text-3xl font-tech font-bold leading-none tracking-tight">Our Alumni <span className="text-primary">Impact Stories</span></h2>
        </header>
        <main className="flex flex-col gap-6 p-5 pb-32 max-w-md mx-auto">
            <div className="bg-white dark:bg-gray-900 rounded-3xl overflow-hidden shadow-md border border-gray-50 dark:border-gray-800">
                <div className="relative group">
                    <div className="aspect-[4/3] bg-center bg-cover" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDABH7E_xRFderFfgcSYzXhcyII4CSKf-M6fH59C7uj6UkG-QxPOfQYAgIBwf6h3T8tw9PFRsfmFjYlgkqJYELZY3uoTDxOzSuVTRlEyioUp8OIjPDkVRm1P0wo3G2RhzdbExLInnbv1jrdbZiCWrTJS90PP2VHVDCnJbzPqRv5lhJVpBsEeKEXE3XXdgKHGx8n6onH3GlFb0Bg-J6zoytjWe3xvVm37sS3joNyYJomSpgv4PJZgs-jdsBtH24wwhSv-riIZORmpxJy')"}}></div>
                </div>
                <div className="px-6 pb-6 pt-4 relative z-10">
                    <h3 className="text-2xl font-tech font-bold text-[#111317] dark:text-white">Ariful Islam</h3>
                    <p className="text-primary font-medium text-sm mb-4">Junior Web Developer @ RawNest Digital</p>
                </div>
            </div>
            <div onClick={() => setActiveView('raw-nest-internship-form')} className="bg-primary rounded-3xl p-6 text-white shadow-xl shadow-primary/30 relative overflow-hidden cursor-pointer">
                <div className="relative z-10">
                    <h3 className="text-xl font-tech font-bold mb-4">Join the Next Batch?</h3>
                    <p className="text-white/80 text-sm mb-6 leading-relaxed">
                        Start your journey today and be the next success story we feature here.
                    </p>
                    <div className="bg-white text-primary px-6 py-3 rounded-xl font-bold text-sm inline-block">Apply Now</div>
                </div>
            </div>
        </main>
    </div>
  );
};

export default GraduateSuccessStoriesView;
