import React, { useState, useEffect } from 'react';
import { View, NewsArticle } from '../types';
import { newsPortals } from '../data/newsPortals';
import { fetchLiveNews } from '../services/apiService';

interface LiveNewsViewProps {
    setActiveView: (view: View) => void;
}

const LoadingSkeleton: React.FC = () => (
    <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
            <div key={i} className="bg-white dark:bg-card-dark rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden animate-pulse">
                <div className="aspect-video bg-gray-200 dark:bg-gray-700"></div>
                <div className="p-4">
                    <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-3"></div>
                    <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                </div>
            </div>
        ))}
    </div>
);


const LiveNewsView: React.FC<LiveNewsViewProps> = ({ setActiveView }) => {
    const [articles, setArticles] = useState<NewsArticle[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const loadNews = async () => {
            setError(null);
            try {
                const fetchedArticles = await fetchLiveNews();
                if (fetchedArticles.length > 0) {
                    setArticles(fetchedArticles);
                } else {
                     // Only set error if it's the initial load and no articles are found
                    if(articles.length === 0) {
                        setError('কোনো সংবাদ পাওয়া যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।');
                    }
                }
            } catch (err) {
                setError('সংবাদ লোড করতে ব্যর্থ হয়েছে।');
                console.error(err);
            } finally {
                setIsLoading(false);
            }
        };

        loadNews(); // Initial load

        const intervalId = setInterval(loadNews, 10 * 60 * 1000); // 10 minutes

        return () => clearInterval(intervalId); // Cleanup on component unmount
    }, []);


    return (
        <div className="bg-background-light dark:bg-background-dark min-h-screen pb-24">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
                <button onClick={() => setActiveView('dashboard')} className="size-10 flex items-center justify-center -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>
                <h1 className="text-lg font-bold font-bengali">লাইভ সংবাদ</h1>
                <div className="w-10"></div>
            </header>

            <main className="p-4">
                <section className="mb-6">
                    <h2 className="text-sm font-bold text-gray-500 dark:text-gray-400 font-bengali mb-3">সোর্সসমূহ</h2>
                    <div className="flex items-center gap-4 overflow-x-auto no-scrollbar">
                        {newsPortals.map(portal => (
                            <div key={portal.name} className="flex-shrink-0 h-10 px-4 bg-white dark:bg-card-dark border border-gray-100 dark:border-gray-700 rounded-lg flex items-center justify-center">
                                <img src={portal.logo} alt={portal.name} className="h-5 object-contain dark:brightness-0 dark:invert-[1]" />
                            </div>
                        ))}
                    </div>
                </section>

                <section className="space-y-4">
                     {isLoading ? (
                        <LoadingSkeleton />
                     ) : error ? (
                        <div className="text-center py-10 text-red-500 font-bengali">{error}</div>
                     ) : (
                         articles.map(article => (
                            <a href={article.link} target="_blank" rel="noopener noreferrer" key={article.id} className="block bg-white dark:bg-card-dark rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden group">
                                {article.image && (
                                    <div className="relative aspect-video">
                                        <img src={article.image} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"/>
                                        <div className="absolute top-2 left-2 bg-white/80 dark:bg-black/50 backdrop-blur-sm p-1 rounded-full">
                                            <img src={article.logo} alt={article.source} className="h-4 object-contain dark:brightness-0 dark:invert-[1]" />
                                        </div>
                                    </div>
                                )}
                                <div className="p-4">
                                    <h3 className="font-bold text-gray-800 dark:text-white leading-tight font-bengali">{article.title}</h3>
                                    <p className="text-xs text-gray-500 dark:text-gray-400 font-bengali mt-2">{article.source} • {article.timestamp}</p>
                                </div>
                            </a>
                        ))
                     )}
                </section>
            </main>
        </div>
    );
};

export default LiveNewsView;