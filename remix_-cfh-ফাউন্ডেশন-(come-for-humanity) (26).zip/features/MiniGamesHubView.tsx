
import React from 'react';
import { View } from '../types';

interface MiniGamesHubViewProps {
  setActiveView: (view: View) => void;
}

const MiniGamesHubView: React.FC<MiniGamesHubViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-[#0c1d18] dark:text-white min-h-screen pb-24 max-w-md mx-auto">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
        <button onClick={() => setActiveView('gamification-hub')} className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center text-white font-bold text-xl">C</div>
          <div><h1 className="text-sm font-bold leading-none">CFH Learning Hub</h1></div>
        </button>
      </header>
      <main className="p-4">
        <div className="flex items-center justify-between mb-4 mt-2">
          <h2 className="text-xl font-extrabold tracking-tight">Mini-Games Hub</h2>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2 relative group overflow-hidden rounded-xl bg-white dark:bg-gray-800 shadow-sm">
            <h3 className="font-bold text-lg leading-tight p-4">Emergency Response</h3>
          </div>
          <div className="flex flex-col rounded-xl bg-white dark:bg-gray-800 shadow-sm overflow-hidden">
            <div className="h-32 bg-cover bg-center" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuA5Onz0CCVveZIbh7P8sm1S_nKJ0LUzBVPvKCWrDFtiHFGuLmevWODYEGkIy4UexPYPRCGS0ptd6u0s4MBSrr1wR8N9H85LYS-4WRMxJNLH4QRRtRujBmfdM3qvhpAgSUoRoCThuUnaSufHeGHw6w4WJrAN_K7WTF3EkL3he7xLA8Rv_cbkNF5jTYCkbTpeAYMBgbk0RnqKxQv_SQ0T-wNhCiK__zcIKJx70rpV9WdfsIlO6WPeUKIYwvpsl6JhA37rW8pbrDYYWnJW')"}}></div>
            <h4 className="font-bold text-sm leading-tight p-3">Blood Runner</h4>
          </div>
        </div>
      </main>
    </div>
  );
};

export default MiniGamesHubView;
