import React from 'react';
import { View } from '../types';

interface ConfirmationProps {
  setActiveView: (view: View) => void;
  name: string;
  bloodGroup: string;
}

const DonorRegistrationConfirmationView: React.FC<ConfirmationProps> = ({ setActiveView, name, bloodGroup }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-gray-800 dark:text-white min-h-screen flex flex-col items-center justify-center p-4 text-center">
      <main className="max-w-md w-full">
        <div className="mb-6">
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
            <span className="material-symbols-outlined text-primary text-6xl">person_add</span>
          </div>
        </div>
        
        <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white mb-2 font-bengali">নিবন্ধন সফল হয়েছে!</h1>
        <p className="text-gray-600 dark:text-gray-400 max-w-xs mx-auto font-bengali leading-relaxed">
          ধন্যবাদ, <span className="font-bold text-primary">{name}</span>, জীবন বাঁচানোর এই যাত্রায় যোগ দেওয়ার জন্য।
        </p>

        <div className="bg-white dark:bg-card-dark rounded-2xl p-6 border border-gray-100 dark:border-gray-800 shadow-sm mt-8 text-left space-y-3">
            <h2 className="text-lg font-bold font-bengali mb-2">আপনার প্রোফাইল সারসংক্ষেপ</h2>
             <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600 dark:text-gray-400 font-bengali">নাম</span>
                <span className="font-bold font-bengali">{name}</span>
            </div>
             <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600 dark:text-gray-400 font-bengali">রক্তের গ্রুপ</span>
                <span className="font-bold text-red-500 text-base">{bloodGroup}</span>
            </div>
             <p className="text-xs text-center text-gray-500 bg-gray-50 dark:bg-gray-800/50 py-2 rounded-lg mt-4 font-bengali">
                আমাদের একজন প্রতিনিধি আপনার তথ্য যাচাই করার জন্য শীঘ্রই যোগাযোগ করবে।
            </p>
        </div>
        
        <div className="mt-8">
            <button 
              onClick={() => setActiveView('blood-bank')} 
              className="w-full bg-primary text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/20 active:scale-95 transition-transform font-bengali"
            >
                ব্লাড ব্যাংকে ফিরে যান
            </button>
        </div>
      </main>
    </div>
  );
};

export default DonorRegistrationConfirmationView;