
import React from 'react';
import { View } from '../types';

interface DigitalIdCardViewProps {
  setActiveView: (view: View) => void;
}

const DigitalIdCardView: React.FC<DigitalIdCardViewProps> = ({ setActiveView }) => {
  const memberName = "Anisur Rahman";
  const memberBengaliName = "আনিসুর রহমান";
  const profileImageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuAzmZHfqZ711g9klhv47F_upcFOest66cKendgnNSUsrTAUr_1_kDwvTKe4_tfhyDTAh_xvt4QtcFEFAa8wjStxys-FYjn814AS_oW-0tWOyTvTYYGgRpWYc-S4Ovws3o2Ly5Z5XEXYirhvkN4bFPwcaZQT53y7zdzdtOkdjtuDuF2-9M8dNc3lq2KvONF75K2pWMF_1ez3DmWn9F2vXki_pK-QEJ36MF5V0Be-hRpueBQ8bSXbQDAl18P1sZe_frkE9j9wOxIPl-5W";

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden pb-12 bg-background-light dark:bg-background-dark">
        <header className="flex items-center bg-white dark:bg-background-dark p-4 pb-4 justify-between sticky top-0 z-50 border-b border-gray-100 dark:border-gray-800">
            <button 
              onClick={() => setActiveView('dashboard')} 
              className="text-gray-800 dark:text-white flex size-12 shrink-0 items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              aria-label="Back to dashboard"
            >
                <span className="material-symbols-outlined text-2xl">arrow_back_ios</span>
            </button>
            <h1 className="text-gray-800 dark:text-white text-lg font-bold leading-tight flex-1 text-center font-bengali">সদস্য কার্ড</h1>
            <div className="flex w-12 items-center justify-end"></div>
        </header>

        <main className="p-6">
            <div 
              className="flex flex-col items-stretch justify-start rounded-2xl shadow-lg bg-white dark:bg-card-dark overflow-hidden relative border border-gray-100 dark:border-gray-800"
              role="region"
              aria-labelledby="card-heading"
            >
                <div className="bg-primary p-6 flex justify-between items-start">
                    <div>
                        <div className="text-white text-xl font-extrabold leading-tight">CFH</div>
                        <p className="text-white text-xs font-medium uppercase tracking-wider">Come For Humanity</p>
                    </div>
                </div>
                
                <div className="p-6 relative">
                    <div className="flex gap-6 mb-8">
                        <img 
                            src={profileImageUrl}
                            alt={`Profile picture of ${memberName}`}
                            className="size-24 rounded-2xl object-cover border-4 border-white dark:border-card-dark shadow-md flex-shrink-0"
                        />
                        <div className="flex flex-col justify-center">
                            <h2 id="card-heading" className="text-gray-900 dark:text-white text-xl font-bold leading-tight">{memberName}</h2>
                            <p className="text-gray-500 dark:text-gray-400 text-lg font-semibold leading-tight mb-2 font-bengali">{memberBengaliName}</p>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-8">
                        <div>
                            <p className="text-gray-500 dark:text-gray-400 text-[10px] font-bold uppercase tracking-widest mb-1">Volunteer ID</p>
                            <p className="text-gray-900 dark:text-white text-sm font-bold">CFH-2023-8842</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        
        <div className="px-6 py-8 flex flex-col gap-3">
            <button className="flex w-full items-center justify-center gap-2 rounded-xl h-14 bg-primary text-white text-base font-bold active:scale-95 transition-transform">
                <span className="material-symbols-outlined">wallet</span>
                <span>Add to Apple Wallet</span>
            </button>
        </div>
    </div>
  );
};

export default DigitalIdCardView;
