
import React from 'react';
import { View } from '../types';

interface FamilySecurityRequestViewProps {
  setActiveView: (view: View) => void;
}

const FamilySecurityRequestView: React.FC<FamilySecurityRequestViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 min-h-screen pb-24">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <button onClick={() => setActiveView('probashi-hub')} className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center text-white"><span className="material-symbols-outlined">diversity_3</span></div>
            <div><h1 className="text-lg font-bold leading-tight tracking-tight">CFH Hub</h1></div>
          </button>
        </div>
      </header>
      <main className="max-w-md mx-auto px-4 pt-6 space-y-6">
        <div className="text-center space-y-1">
          <h2 className="text-xl font-bold text-slate-800 dark:text-white">Family Security Request</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-medium font-bengali">পারিবারিক সুরক্ষা অনুরোধ</p>
        </div>
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-primary">Expatriate Contact Info</h3>
          <input className="w-full rounded-lg border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-sm" placeholder="Full Name / আপনার পূর্ণ নাম" type="text"/>
        </section>
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-custom">Family in Bangladesh</h3>
            <textarea className="w-full bg-slate-50 dark:bg-slate-800/50 rounded-lg p-3 border border-dashed border-slate-200 dark:border-slate-700" placeholder="Address Details / ঠিকানার বিস্তারিত বিবরণ" rows={2}></textarea>
        </section>
        <div className="space-y-4 pt-2">
            <button className="w-full bg-primary py-4 rounded-xl text-white font-bold shadow-md">SUBMIT GENERAL REQUEST</button>
        </div>
      </main>
    </div>
  );
};

export default FamilySecurityRequestView;
