
import React from 'react';
import { View } from '../types';

interface SocialForestryViewProps {
  setActiveView: (view: View) => void;
}

const SocialForestryView: React.FC<SocialForestryViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 min-h-screen pb-24">
      <div className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-4">
        <div className="flex items-center justify-between max-w-lg mx-auto">
          <button onClick={() => setActiveView('ecommerce')} className="flex items-center gap-3">
            <div className="bg-primary/10 p-2 rounded-lg">
              <span className="material-symbols-outlined text-primary">eco</span>
            </div>
            <h1 className="text-lg font-extrabold leading-none tracking-tight">Social Forestry</h1>
          </button>
        </div>
      </div>
      <main className="max-w-lg mx-auto px-4 space-y-6">
        <div className="relative overflow-hidden bg-white dark:bg-slate-800 rounded-xl p-6 shadow-sm border border-slate-100 dark:border-slate-700">
          <h2 className="text-3xl font-extrabold tracking-tight">12,540</h2>
          <p className="text-primary text-xs font-bold flex items-center gap-1 mt-1">Trees Planted</p>
        </div>
        <div className="grid grid-cols-1 gap-5">
          <div className="bg-white dark:bg-slate-800 rounded-xl overflow-hidden shadow-sm border border-slate-100 dark:border-slate-700 group">
            <div className="relative h-48 w-full">
              <img alt="Mango Sapling" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuC_9exric_QmZZe8JstSdzKecD5Ea-Rw_wif-TRr9v9nWTeGsdboUBs2M_gu-xYEoQFo6xBbZSp4EC6lNouyPm1TsB7DiwO2uGC95EboUyBxNPBdmQxBMl93U9q-LhSx-yKc16htTTt84JV3pd5mefJXU6H-CbOqWbj6k-IxDUiLozVvYdMK5P6PD5UPWNM0_rLx3JmWeTXsMwVhOGDL4sxm6wa8jrqrSavLNN1IbJu-eY7F9LRFmbaGyUTJ2qyxFGebhQPmrI3Bnhe"/>
            </div>
            <div className="p-5">
              <h4 className="text-lg font-bold">Mango / আম</h4>
              <button className="w-full bg-primary hover:bg-emerald-700 text-white font-bold py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2 mt-4">
                Order Sapling
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default SocialForestryView;
