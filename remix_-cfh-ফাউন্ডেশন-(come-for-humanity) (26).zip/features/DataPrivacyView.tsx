
import React from 'react';
import { View } from '../types';

interface DataPrivacyViewProps {
  setActiveView: (view: View) => void;
}

const DataPrivacyView: React.FC<DataPrivacyViewProps> = ({ setActiveView }) => {
  // This component now implements the "Legal & Compliance" design
  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-[430px] mx-auto shadow-2xl bg-background-light dark:bg-background-dark">
      <header className="sticky top-0 z-30 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center p-4 justify-between">
          <button onClick={() => setActiveView('profile')} className="flex items-center justify-center size-10 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer">
            <span className="material-symbols-outlined text-slate-900 dark:text-white">arrow_back</span>
          </button>
          <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-tight flex-1 text-center pr-10">Legal & Compliance</h2>
        </div>
        <div className="px-4 pb-2">
            <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
                <button className="flex-1 py-2 text-sm font-semibold rounded-md bg-white dark:bg-slate-700 text-primary shadow-sm">Terms of Service</button>
                <button className="flex-1 py-2 text-sm font-semibold text-slate-500 dark:text-slate-400">Privacy Policy</button>
            </div>
        </div>
      </header>
      <main className="flex-1 overflow-y-auto px-6 py-4 pb-40">
        <section className="mb-8">
            <h3 className="text-primary dark:text-blue-400 text-xl font-bold leading-tight mb-4">1. Introduction</h3>
            <p className="text-slate-700 dark:text-slate-300 text-base leading-relaxed">
                Welcome to the CFH Super App. These Terms of Service ("Terms") govern your access to and use of our platform, services, and applications.
            </p>
        </section>
      </main>
      <footer className="fixed bottom-0 left-0 right-0 max-w-[430px] mx-auto bg-background-light/90 dark:bg-background-dark/90 backdrop-blur-xl border-t border-slate-100 dark:border-slate-800 p-6">
        <button onClick={() => setActiveView('profile')} className="w-full bg-[#10b981] hover:bg-emerald-600 text-white font-bold py-4 rounded-xl shadow-lg active:scale-[0.98] transition-all">
            Accept and Continue
        </button>
      </footer>
    </div>
  );
};

export default DataPrivacyView;
