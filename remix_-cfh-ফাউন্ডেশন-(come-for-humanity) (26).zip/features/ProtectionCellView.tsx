
import React from 'react';
import { View } from '../types';

interface ProtectionCellViewProps {
  setActiveView: (view: View) => void;
}

const ProtectionCellView: React.FC<ProtectionCellViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-[#121416] dark:text-white transition-colors duration-200">
      <header className="sticky top-0 z-50 bg-white dark:bg-background-dark border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center p-4 justify-between max-w-[480px] mx-auto">
            <button onClick={() => setActiveView('dashboard')} className="flex items-center gap-3">
                <div className="size-10 shrink-0 bg-primary rounded-lg flex items-center justify-center text-white">
                    <span className="material-symbols-outlined">shield_person</span>
                </div>
                <div>
                    <h1 className="text-[#121416] dark:text-white text-lg font-bold leading-tight">Protection Cell</h1>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Come For Humanity (CFH)</p>
                </div>
            </button>
        </div>
      </header>
      <main className="max-w-[480px] mx-auto pb-32">
        <div className="px-4 pt-6">
            <div className="bg-primary/5 dark:bg-primary/10 border border-primary/20 rounded-xl p-4 flex flex-col gap-3">
                <div className="flex items-start gap-3">
                    <span className="material-symbols-outlined text-primary" style={{fontSize: '28px'}}>contact_emergency</span>
                    <div>
                        <h2 className="text-primary font-bold text-base leading-tight">Need Immediate Help?</h2>
                        <p className="text-gray-600 dark:text-gray-400 text-sm mt-1">Directly connect with our emergency response team.</p>
                    </div>
                </div>
                <button className="w-full flex items-center justify-center gap-2 bg-primary text-white h-12 rounded-lg font-bold transition-transform active:scale-95">
                    <span className="material-symbols-outlined">call</span>
                    Direct Call for Help
                </button>
            </div>
        </div>
        <div className="px-4 pt-8 pb-2">
          <h2 className="text-[22px] font-bold tracking-tight">File a Secure Complaint</h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm">Your safety is our priority. Information is securely forwarded to government authorities.</p>
        </div>
        <form className="space-y-6 px-4 pt-4">
            <div className="space-y-3">
                <label className="block">
                    <span className="text-sm font-semibold mb-2 block">Nature of Incident</span>
                    <div className="relative">
                        <select className="w-full h-14 pl-4 pr-10 bg-surface-light dark:bg-surface-dark border-none rounded-lg appearance-none focus:ring-2 focus:ring-primary text-base">
                            <option value="">Select Incident Category</option>
                            <option value="harassment">Harassment</option>
                            <option value="violence">Domestic Violence</option>
                        </select>
                        <span className="material-symbols-outlined absolute right-3 top-4 pointer-events-none text-gray-400">expand_more</span>
                    </div>
                </label>
            </div>
            <div className="flex items-center justify-between p-4 bg-primary/5 dark:bg-primary/10 rounded-xl">
                <label className="relative inline-flex items-center cursor-pointer">
                    <input className="sr-only peer" type="checkbox" value=""/>
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                </label>
            </div>
            <button className="w-full bg-primary text-white h-14 rounded-lg font-bold text-lg" type="submit">
                File a Complaint
            </button>
        </form>
      </main>
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-background-dark border-t border-gray-100 dark:border-gray-800 p-4 z-[100]">
        <div className="max-w-[480px] mx-auto">
            <button className="w-full bg-emergency text-white h-14 rounded-full font-bold text-lg flex items-center justify-center gap-3 shadow-xl shadow-emergency/40 active:scale-95 transition-transform uppercase tracking-wider">
                <span className="material-symbols-outlined animate-pulse font-variation-fill">sos</span>
                Emergency SOS
            </button>
        </div>
      </div>
    </div>
  );
};

export default ProtectionCellView;
