
import React from 'react';
import { View } from '../types';

interface ProviderProfileViewProps {
  setActiveView: (view: View) => void;
}

const ProviderProfileView: React.FC<ProviderProfileViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden max-w-[430px] mx-auto bg-background-light dark:bg-background-dark shadow-2xl">
      <div className="sticky top-0 z-50 flex items-center bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md p-4 pb-2 justify-between border-b border-gray-100 dark:border-gray-800">
        <button onClick={() => setActiveView('home-care')} className="text-[#121715] dark:text-white flex size-10 items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer">
          <span className="material-symbols-outlined">arrow_back_ios_new</span>
        </button>
        <h2 className="text-[#121715] dark:text-white text-lg font-bold leading-tight tracking-tight flex-1 text-center">Provider Profile</h2>
        <div className="w-10"></div>
      </div>
      <div className="flex p-4 flex-col gap-6">
        <div className="flex w-full flex-col gap-4 items-center bg-white dark:bg-gray-900 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
          <div className="relative">
            <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-32 w-32 border-4 border-white dark:border-gray-800 shadow-md" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAUIuEHEB0R_fihzuquLCLNLtCABL71H-lLWm9A7uMP4HTQiuMjZNtwdVweUee5tW2fSedcGrDOXoAVPijpQ-U8-1DC_t0_v1GkxRBEJW86mSpZr05j7lXIIw0k5YEBrU7I2azjaHTs9NSGWBzUu9r8lsITQITqKGe2GFtNOuqWaiQID94ZLkX0F1XJ_NPcuqlrp885JBEfAEiLpUCmzoTn850uU6wTOvDg8gpLbFNgN2sjVrshpUChfPhq5KI3NfEMsR8tY5mDqtMc')"}}></div>
          </div>
          <p className="text-[#121715] dark:text-white text-2xl font-extrabold leading-tight tracking-tight">Anika Rahman</p>
        </div>
      </div>
       <div className="px-4 pb-4">
        <div className="bg-white dark:bg-gray-900 p-5 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
          <h3 className="text-[#121715] dark:text-white text-md font-bold mb-4">Humanity Rating</h3>
        </div>
      </div>
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] bg-white dark:bg-gray-900 p-4 pb-8 border-t border-gray-100 dark:border-gray-800 shadow-lg z-50">
        <button className="w-full bg-primary text-white font-extrabold py-4 rounded-2xl shadow-xl shadow-primary/20 transition-transform active:scale-95 text-lg">
            Book Now
        </button>
      </div>
    </div>
  );
};

export default ProviderProfileView;
