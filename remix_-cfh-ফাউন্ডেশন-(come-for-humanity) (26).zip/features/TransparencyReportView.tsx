
import React from 'react';
import { View } from '../types';

interface TransparencyReportViewProps {
  setActiveView: (view: View) => void;
}

const TransparencyReportView: React.FC<TransparencyReportViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-[#111318] dark:text-[#f4f3f0] min-h-screen">
        <div className="max-w-[480px] mx-auto bg-white dark:bg-[#1a1c22] min-h-screen flex flex-col shadow-xl">
            <header className="sticky top-0 z-50 flex items-center bg-white/80 dark:bg-[#1a1c22]/80 backdrop-blur-md p-4 pb-2 justify-between border-b border-[#e5e7eb] dark:border-[#374151]">
                <button onClick={() => setActiveView('farmer-portal')} className="text-primary flex size-12 shrink-0 items-center justify-center cursor-pointer">
                    <span className="material-symbols-outlined">arrow_back_ios</span>
                </button>
                <div className="flex flex-col items-center">
                    <h2 className="text-[#111318] dark:text-white text-base font-bold leading-tight">Transparency Report</h2>
                    <span className="text-xs text-[#636f88] font-medium font-bengali">স্বচ্ছতা প্রতিবেদন</span>
                </div>
                <div className="w-12"></div>
            </header>
            <div className="px-4 py-4">
                <div className="relative overflow-hidden rounded-xl bg-trust-green/10 p-6 flex items-center border border-trust-green/20">
                    <h1 className="text-[#111318] dark:text-white text-2xl font-extrabold leading-tight">Fair Trade Verified</h1>
                </div>
            </div>
            <div className="px-6 py-8">
                <div className="grid grid-cols-[48px_1fr] gap-x-4">
                    <div className="flex flex-col items-center">
                        <div className="flex size-10 items-center justify-center rounded-full bg-trust-green text-white"><span className="material-symbols-outlined">agriculture</span></div>
                        <div className="w-[2px] bg-trust-green/30 h-16"></div>
                    </div>
                    <div className="flex flex-col pb-8">
                        <p className="text-[#111318] dark:text-white text-lg font-bold leading-none">Farmer's Price</p>
                        <p className="text-xl font-extrabold text-trust-green">৳45.00</p>
                    </div>
                    <div className="flex flex-col items-center">
                        <div className="flex size-10 items-center justify-center rounded-full bg-primary text-white"><span className="material-symbols-outlined">local_shipping</span></div>
                        <div className="w-[2px] bg-primary/30 h-16"></div>
                    </div>
                     <div className="flex flex-col pb-8">
                        <p className="text-lg font-bold leading-none">Logistics</p>
                        <p className="text-xl font-extrabold text-primary">৳12.00</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default TransparencyReportView;
