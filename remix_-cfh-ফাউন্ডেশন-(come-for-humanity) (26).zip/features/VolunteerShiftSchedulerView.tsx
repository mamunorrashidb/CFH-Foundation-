
import React from 'react';
import { View } from '../types';

interface VolunteerShiftSchedulerViewProps {
  setActiveView: (view: View) => void;
}

const VolunteerShiftSchedulerView: React.FC<VolunteerShiftSchedulerViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-[#111317] dark:text-white min-h-screen flex flex-col max-w-md mx-auto">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center p-4 justify-between">
          <button onClick={() => setActiveView('volunteer-training')} className="text-primary flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-primary/10 cursor-pointer">
            <span className="material-symbols-outlined">arrow_back_ios_new</span>
          </button>
          <h2 className="text-lg font-bold leading-tight flex-1 text-center pr-10">Volunteer Shifts</h2>
        </div>
      </header>
      <main className="flex-1 overflow-y-auto pb-24">
        <div className="bg-background-light dark:bg-background-dark border-b border-gray-100 dark:border-gray-800 sticky top-[68px] z-40">
            <div className="flex overflow-x-auto gap-4 py-3 px-4">
                <div className="flex flex-col items-center justify-center min-w-[56px] h-20 rounded-2xl bg-primary text-white shadow-lg">
                    <p className="text-[10px] uppercase font-bold">Mon</p>
                    <p className="text-xl font-bold">12</p>
                </div>
            </div>
        </div>
        <div className="flex items-center justify-between px-4 pt-6 pb-2">
          <h3 className="text-lg font-bold tracking-tight">Available Shifts</h3>
        </div>
        <div className="flex flex-col gap-4 p-4">
          <div className="group relative flex flex-col bg-white dark:bg-gray-900 rounded-2xl overflow-hidden shadow-sm border border-gray-50 dark:border-gray-800">
            <div className="h-40 w-full bg-cover bg-center" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAheOeajOZEjFjFAUXgYLbv4UEvf4PXlShemeN8mC73hoedeOrN3Dgl6AmyjqEiStneKEY4FXbJdFX-70gtLgeIc4Tm9kvT6OzRypx9qXhT2cXyr3iwqj_yYZ4xUfgKvT3ltNFcCs5Sy7Td3MwaHU08t9Py6xKyBdtOEN_GFP5H3l5xpa-PKWLVhMe0sNNToIx0FUvkvgfMm6mAyjNViYBWlMngJog6cBPnuTpS-MpMKx-qZeoywXvc-QrCSnHcUgSh2xcVAdhUIyPL')"}}></div>
            <div className="p-5 flex flex-col gap-3">
                <h4 className="text-lg font-bold text-gray-900 dark:text-white leading-tight">Blood Drive - Chitla</h4>
                <button className="bg-success text-white px-8 py-2.5 rounded-xl font-bold text-sm shadow-lg">Sign Up</button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default VolunteerShiftSchedulerView;
