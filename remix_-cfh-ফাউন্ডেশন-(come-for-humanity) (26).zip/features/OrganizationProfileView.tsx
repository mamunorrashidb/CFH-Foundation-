
import React from 'react';
import { View } from '../types';

interface OrganizationProfileViewProps {
  setActiveView: (view: View) => void;
}

const OrganizationProfileView: React.FC<OrganizationProfileViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark min-h-screen text-[#111317] dark:text-white">
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md">
        <div className="flex items-center p-4 pb-2 justify-between">
            <button onClick={() => setActiveView('blood-bank')} className="text-primary flex size-10 shrink-0 items-center justify-center cursor-pointer">
                <span className="material-symbols-outlined">arrow_back</span>
            </button>
            <h2 className="text-[#111317] dark:text-white text-lg font-bold leading-tight flex-1 text-center">Organization Profile</h2>
            <div className="w-10"></div>
        </div>
      </header>
      <div className="relative w-full h-48 bg-cover bg-center" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuBy_zRRFQCdO8XfClAqBFvQy2q6y9CcDhd66QB7W5WNjv_bdFmjHg1pBnnI0tHEvGRG2_MR5ZC3jDtZyQ8klXd8knfrUUcRfSgAKvtv5dfrwMrQ7S5rYkZRyPDEOhzOvESaWMSQmJjMwehOlTosM_MStKJedZBiNlW4jxL_esv0GHcvAWsHSgA5TZXyn7gD8Nyk1KqjdqsWUtiTpbufBrK9p647JzRX4b3e4R5LUysPaZkZoQo5HwO_IbSlO6Db5h_hkjejLswrslYN')"}}></div>
      <div className="px-4 -mt-16 relative z-10">
        <div className="flex flex-col items-center">
            <div className="bg-white dark:bg-background-dark p-1 rounded-full shadow-md">
                <div className="bg-center bg-cover rounded-full h-32 w-32 border-4 border-white dark:border-background-dark" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCQq7_yNYrfkBOYycobTXY3TtBafhm02P4XwZJAhR67CJ8SHSn8yXs3LCYaGmq3zKDsKR_foim-0-SEIdimT52gTizirNJwK9YOqW2BUDTV4UQR94ZLqgIbMqOSNGKLwV6dM0fb4VhFcksfzlPBh_MxOZFnwE0oaEgShHEBsr6V2vO-PBvHuBi1jA9s-_DvJlvmpqevnUhS-YVubFdQavkl-qKa-keDdDuZ1Xgdakjr2AHDsVVHfhVj3lkr90ABXv5KowrMYWkWcJ5P')"}}></div>
            </div>
            <div className="mt-4 text-center">
                <h1 className="text-2xl font-bold tracking-tight">BBS Blood Bank</h1>
            </div>
        </div>
      </div>
      <div className="px-4 mt-4 pb-32">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm border border-gray-100 dark:border-gray-700">
            <h3 className="text-lg font-bold mb-3 flex items-center gap-2"><span className="material-symbols-outlined text-primary">info</span>About Us</h3>
            <p className="text-base font-normal leading-relaxed">BBS Blood Bank is dedicated to providing high-quality blood products and services to patients in need.</p>
        </div>
      </div>
    </div>
  );
};

export default OrganizationProfileView;
