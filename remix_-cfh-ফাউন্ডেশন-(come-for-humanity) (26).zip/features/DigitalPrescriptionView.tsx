
import React from 'react';
import { View } from '../types';

interface DigitalPrescriptionViewProps {
  setActiveView: (view: View) => void;
}

const DigitalPrescriptionView: React.FC<DigitalPrescriptionViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-slate-50 dark:bg-background-dark font-display text-[#333333] dark:text-gray-200 max-w-md mx-auto">
      <nav className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 ios-blur border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center justify-between px-4 h-16">
          <button onClick={() => setActiveView('telemedicine')} className="flex items-center justify-center size-10 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
            <span className="material-symbols-outlined text-gray-900 dark:text-white">arrow_back_ios_new</span>
          </button>
          <h1 className="text-lg font-bold tracking-tight text-gray-900 dark:text-white">Digital Prescription</h1>
          <div className="size-10 flex items-center justify-end"><span className="material-symbols-outlined text-brand-blue">verified_user</span></div>
        </div>
      </nav>
      <main className="p-4 pb-32 space-y-4">
        <div className="bg-white dark:bg-gray-900 rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden">
          <div className="bg-brand-blue/5 p-4 flex items-start justify-between">
            <div className="flex flex-col gap-1"><div className="flex items-center gap-2"><div className="size-8 bg-brand-blue rounded-lg flex items-center justify-center text-white"><span className="material-symbols-outlined text-lg">medical_services</span></div><span className="font-bold text-brand-blue text-sm uppercase tracking-wider">Online Our Doctor</span></div><p className="text-xs text-brand-blue/70 font-medium">CFH Super App Telemedicine</p></div>
            <div className="text-right"><p className="text-[10px] uppercase font-bold text-gray-400">ID: Rx-99284-K</p></div>
          </div>
          <div className="p-5 flex gap-4">
            <div className="size-20 rounded-full bg-gray-100 dark:bg-gray-800 bg-cover bg-center shrink-0 border-2 border-white dark:border-gray-700" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAu_aGVY5mBJTYv-EThUk44JoovSwQWFuGvCKiw9rZEE9miyGpadAeyoMGnlRjuaFsbS1tOCVr5DJBIdQPpgXYnS7bECPg8EJL2SMdZjDo689I7FEWuVpqbDEcqfwImsJbTiF-aca9_-DP_M6v-KRWtCkP1mxZyFFuKG06efj1xeXK_fI2te3qwOGKUQ0oWARz_C7k-jzlUxjy8EHq5dT2P2gX-W6-Ot0CRA60c_kZipuQKF2P8dpAC_gYKG8A_A5WCQXc-_LJ53VmL')"}}></div>
            <div className="flex flex-col justify-center"><h2 className="text-xl font-bold text-gray-900 dark:text-white">Dr. Sarah Mitchell</h2><p className="text-sm text-gray-500 dark:text-gray-400">Medical License: #123456789</p><div className="flex items-center gap-1 mt-1"><span className="material-symbols-outlined text-[14px] text-primary">location_on</span><span className="text-xs font-medium text-gray-500">General Physician • Online Clinic</span></div></div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-900 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-800">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Patient Information</h3>
            <div className="grid grid-cols-2 gap-y-3">
                <div><p className="text-[11px] text-gray-500 uppercase">Name</p><p className="text-sm font-semibold">Johnathan Doe</p></div>
                <div className="text-right"><p className="text-[11px] text-gray-500 uppercase">Date Issued</p><p className="text-sm font-semibold">Oct 24, 2023</p></div>
                <div><p className="text-[11px] text-gray-500 uppercase">Age / Sex</p><p className="text-sm font-semibold">32 Years / Male</p></div>
                <div className="text-right"><p className="text-[11px] text-gray-500 uppercase">Weight</p><p className="text-sm font-semibold">78 kg</p></div>
            </div>
        </div>
        <div className="bg-white dark:bg-gray-900 rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden">
            <div className="px-5 pt-5 flex items-baseline gap-2"><span className="text-4xl font-bold text-brand-blue leading-none">℞</span><h3 className="text-lg font-bold">Prescribed Medications</h3></div>
            <div className="p-5 space-y-6">
                <div className="relative pl-4 border-l-2 border-brand-blue/30"><h4 className="text-base font-bold text-gray-900 dark:text-white">Amoxicillin 500mg</h4><div className="mt-2 space-y-1"><div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300"><span className="material-symbols-outlined text-sm text-brand-blue">pill</span><span>1 tablet • Twice daily (After meals)</span></div><div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300"><span className="material-symbols-outlined text-sm text-brand-blue">calendar_today</span><span>Duration: 7 Days</span></div></div></div>
                <div className="relative pl-4 border-l-2 border-brand-blue/30"><h4 className="text-base font-bold text-gray-900 dark:text-white">Paracetamol 650mg</h4><div className="mt-2 space-y-1"><div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300"><span className="material-symbols-outlined text-sm text-brand-blue">pill</span><span>1 tablet • Every 6 hours (For fever)</span></div><div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300"><span className="material-symbols-outlined text-sm text-brand-blue">calendar_today</span><span>Duration: 3 Days</span></div></div></div>
            </div>
            <div className="bg-[#F9F9FB] dark:bg-gray-800/50 p-4 border-t border-gray-100 dark:border-gray-800"><div className="flex gap-3"><span className="material-symbols-outlined text-brand-blue">lightbulb</span><div><p className="text-xs font-bold text-gray-500 uppercase">Doctor's Advice</p><p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed mt-1">Drink plenty of water and rest. Avoid dairy for 2 hours after taking antibiotics. If symptoms persist, book a follow-up.</p></div></div></div>
        </div>
      </main>
      <footer className="fixed bottom-0 left-0 right-0 p-4 bg-white/90 dark:bg-background-dark/90 ios-blur border-t border-gray-100 dark:border-gray-800">
        <div className="max-w-md mx-auto flex gap-3">
          <button className="flex-1 bg-emerald-500 text-white font-bold py-4 rounded-xl shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2"><span className="material-symbols-outlined">download</span>Download PDF</button>
          <button className="aspect-square bg-brand-blue/10 text-brand-blue size-14 rounded-xl flex items-center justify-center"><span className="material-symbols-outlined">share</span></button>
        </div>
      </footer>
    </div>
  );
};

export default DigitalPrescriptionView;
