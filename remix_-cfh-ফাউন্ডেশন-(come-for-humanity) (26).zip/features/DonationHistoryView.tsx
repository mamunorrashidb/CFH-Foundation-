import React from 'react';
import { View } from '../types';

interface DonationHistoryViewProps {
  setActiveView: (view: View) => void;
}

const DonationHistoryView: React.FC<DonationHistoryViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex h-screen w-full flex-col overflow-hidden max-w-[430px] mx-auto border-x border-gray-100 dark:border-gray-800 shadow-2xl bg-background-light dark:bg-background-dark">
      <header className="sticky top-0 z-10 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 pt-6 pb-2">
        <div className="flex items-center justify-between">
          <button onClick={() => setActiveView('profile')} className="flex items-center gap-3">
            <span className="material-symbols-outlined text-primary cursor-pointer">arrow_back_ios</span>
            <h1 className="text-2xl font-extrabold text-primary tracking-tight">Donation History</h1>
          </button>
        </div>
      </header>
      <div className="px-4 py-4">
        <div className="bg-primary/5 dark:bg-primary/10 rounded-xl p-4 flex items-center justify-between border border-primary/10">
          <div><p className="text-xs font-semibold uppercase tracking-wider text-primary/70">Total Contributions</p><p className="text-2xl font-bold text-primary mt-1">$2,450.00</p></div>
          <div className="size-12 bg-primary rounded-xl flex items-center justify-center text-white"><span className="material-symbols-outlined">receipt_long</span></div>
        </div>
      </div>
      <main className="flex-1 overflow-y-auto px-4 pb-8">
        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4 mt-2">Recent Transactions</h3>
        <div className="space-y-3">
          <div className="group bg-white dark:bg-[#1c1f24] p-4 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center text-emerald-600">
                <span className="material-symbols-outlined">volunteer_activism</span>
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start"><h4 className="font-bold text-base">Shopno Gori</h4><span className="font-bold text-base text-primary">$50.00</span></div>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Oct 24, 2023 • 10:45 AM</p>
              </div>
            </div>
            <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-50 dark:border-gray-800/50">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-success/10 text-success uppercase">Successful</span>
                <button className="flex items-center gap-1 text-primary text-xs font-bold"><span className="material-symbols-outlined text-[16px]">download</span>Receipt PDF</button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default DonationHistoryView;