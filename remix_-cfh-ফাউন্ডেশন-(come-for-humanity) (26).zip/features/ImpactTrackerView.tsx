
import React, { useState, useEffect } from 'react';
import { View } from '../types';

interface ImpactTrackerViewProps {
  setActiveView: (view: View) => void;
}

const AnimatedStatCard: React.FC<{ value: number; label: string; icon: React.ReactNode; color: string; suffix: string; prefix?: string; }> = ({ value, label, icon, color, suffix, prefix }) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
        const duration = 1500; // Animate over 1.5 seconds
        const steps = 50;
        const stepDuration = duration / steps;
        const increment = value / steps;
        let current = 0;

        const timer = setInterval(() => {
            current += increment;
            if (current >= value) {
                setCount(value);
                clearInterval(timer);
            } else {
                setCount(Math.ceil(current));
            }
        }, stepDuration);

        return () => clearInterval(timer);
    }, [value]);

    return (
        <div className="bg-white dark:bg-card-dark p-6 rounded-2xl shadow-lg flex items-center space-x-4">
            <div className={`p-4 rounded-full ${color}`}>
                {icon}
            </div>
            <div>
                <p className="text-3xl font-extrabold text-cfh-royal-blue dark:text-white">
                    {prefix}{count.toLocaleString('bn-BD')}{suffix}
                </p>
                <p className="text-gray-500 dark:text-gray-400 font-medium font-bengali">{label}</p>
            </div>
        </div>
    );
};

const ImpactTrackerView: React.FC<ImpactTrackerViewProps> = ({ setActiveView }) => {
    const stats = [
        { value: 10500, label: 'জীবন বাঁচানো হয়েছে', icon: <span className="material-symbols-outlined text-white text-3xl">favorite</span>, color: 'bg-red-500', suffix: '+' },
        { value: 25000, label: 'বৃক্ষ রোপণ করা হয়েছে', icon: <span className="material-symbols-outlined text-white text-3xl">park</span>, color: 'bg-cfh-emerald-green', suffix: '+' },
        { value: 1200, label: 'উদ্যোক্তা ক্ষমতায়ন', icon: <span className="material-symbols-outlined text-white text-3xl">groups</span>, color: 'bg-blue-500', suffix: '+' },
        { value: 5000000, label: 'অনুদান সংগৃহীত', icon: <span className="material-symbols-outlined text-white text-3xl">volunteer_activism</span>, color: 'bg-purple-500', suffix: '+', prefix: '৳' },
    ];
    
    return (
        <div className="bg-background-light dark:bg-background-dark min-h-screen">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
                <button onClick={() => setActiveView('dashboard')} className="size-10 flex items-center justify-center -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>
                <h1 className="text-lg font-bold font-bengali">ইমপ্যাক্ট ট্র্যাকার</h1>
                <div className="w-10"></div>
            </header>
            
            <main className="container mx-auto px-4 animate-fade-in pb-24 font-bengali">
                <div className="text-center my-8">
                    <h2 className="text-2xl font-bold text-cfh-royal-blue dark:text-white">লাইভ ফান্ড ও ইমপ্যাক্ট</h2>
                    <p className="text-gray-600 dark:text-gray-300 mt-2">প্রতিটি কাজে স্বচ্ছতা। আমাদের সম্মিলিত প্রভাব রিয়েল-টাইমে দেখুন।</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                    {stats.map((stat, index) => <AnimatedStatCard key={index} {...stat} />)}
                </div>

                <div className="bg-white dark:bg-card-dark p-8 rounded-2xl shadow-xl text-center mb-12">
                     <h3 className="text-xl font-bold text-cfh-royal-blue dark:text-white mb-4">দাতার সম্মাননা</h3>
                     <p className="text-gray-600 dark:text-gray-300 mb-6">আপনার অবদান একটি উন্নত বিশ্ব গড়তে সাহায্য করে। আপনার আনুষ্ঠানিক সম্মাননা সনদ দেখুন ও শেয়ার করুন।</p>
                     <button onClick={() => setActiveView('donor-certificate')} className="py-3 px-8 bg-amber-500 text-white font-bold rounded-lg shadow-md hover:bg-amber-600 transition-transform transform hover:scale-105">
                        সনদ দেখুন
                     </button>
                </div>

                <div className="bg-white dark:bg-card-dark p-8 rounded-2xl shadow-xl text-center mb-12">
                     <h3 className="text-xl font-bold text-cfh-royal-blue dark:text-white mb-4">আপনার প্রভাব শেয়ার করুন</h3>
                     <p className="text-gray-600 dark:text-gray-300 mb-6">আপনার অবদান বিশ্বের সাথে শেয়ার করার জন্য একটি ব্যক্তিগত সামাজিক মিডিয়া কার্ড তৈরি করুন।</p>
                     <button onClick={() => setActiveView('social-media-impact-kit')} className="py-3 px-8 bg-blue-600 text-white font-bold rounded-lg shadow-md hover:bg-blue-700 transition-transform transform hover:scale-105">
                        ইমপ্যাক্ট কার্ড তৈরি করুন
                     </button>
                </div>

                <div className="bg-white dark:bg-card-dark p-8 rounded-2xl shadow-xl text-center">
                     <h3 className="text-xl font-bold text-cfh-royal-blue dark:text-white mb-4">গ্লোবাল পার্টনারশিপ ও অনুদান গেটওয়ে</h3>
                     <p className="text-gray-600 dark:text-gray-300 mb-6">বিশ্বের যেকোনো প্রান্ত থেকে আমাদের মিশনে যোগ দিন। আপনার অবদান একটি পরিবর্তন আনে।</p>
                     <button onClick={() => setActiveView('donation')} className="py-3 px-8 bg-cfh-emerald-green text-white font-bold rounded-lg shadow-md hover:bg-green-600 transition-transform transform hover:scale-105">
                        এখনই অনুদান দিন
                     </button>
                </div>
            </main>
        </div>
    );
};

export default ImpactTrackerView;
