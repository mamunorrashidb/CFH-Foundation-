
import React from 'react';
import { View } from '../types';

interface HomeCareViewProps {
    setActiveView: (view: View) => void;
}

const HomeCareView: React.FC<HomeCareViewProps> = ({ setActiveView }) => {
    return (
        <div className="relative flex h-screen w-full flex-col overflow-hidden max-w-md mx-auto bg-background-light dark:bg-background-dark font-display text-[#121417] dark:text-white">
            <header className="flex items-center p-4 pb-2 justify-between z-10">
                 <button onClick={() => setActiveView('dashboard')} className="p-2 -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"><span className="material-symbols-outlined text-3xl">arrow_back_ios_new</span></button>
                <h2 className="text-xl font-extrabold leading-tight tracking-[-0.015em] flex-1 text-center">CFH Home Care</h2>
                <div className="w-12"><button onClick={() => setActiveView('profile')} className="flex size-10 cursor-pointer items-center justify-center overflow-hidden rounded-full bg-primary/10 text-primary"><span className="material-symbols-outlined">person</span></button></div>
            </header>
            <main className="flex-1 overflow-y-auto pb-40">
                <div className="px-5 pt-6">
                    <p className="text-primary font-bold text-sm uppercase tracking-widest mb-1">Our Expertise</p>
                    <h3 className="tracking-tight text-3xl font-extrabold leading-tight">Select a Service</h3>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mt-2">Professional assistance tailored to your needs.</p>
                </div>
                <div className="grid grid-cols-2 gap-4 p-5">
                    <div onClick={() => setActiveView('provider-profile')} className="flex flex-col gap-3 p-4 bg-card-light dark:bg-card-dark rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 group active:scale-95 transition-transform cursor-pointer">
                        <div className="size-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary"><span className="material-symbols-outlined text-3xl">medical_services</span></div>
                        <div><p className="text-base font-bold leading-normal">Home Doctor</p></div>
                    </div>
                     <div onClick={() => setActiveView('provider-profile')} className="flex flex-col gap-3 p-4 bg-card-light dark:bg-card-dark rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 active:scale-95 transition-transform cursor-pointer">
                        <div className="size-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary"><span className="material-symbols-outlined text-3xl">vaccines</span></div>
                        <div><p className="text-base font-bold leading-normal">Nursing Care</p></div>
                    </div>
                </div>
            </main>
            <div className="fixed bottom-0 left-0 right-0 z-20 bg-gradient-to-t from-white via-white to-transparent dark:from-background-dark dark:via-background-dark max-w-md mx-auto">
                <div className="flex px-5 py-4 pb-8">
                    <button className="flex min-w-[84px] w-full cursor-pointer items-center justify-center overflow-hidden rounded-xl h-14 px-5 bg-emergency text-white gap-3 shadow-lg shadow-emergency/30 hover:bg-red-700 active:scale-[0.98] transition-all">
                        <span className="material-symbols-outlined text-2xl font-bold">emergency_share</span>
                        <span className="truncate text-lg font-extrabold tracking-wide uppercase">Emergency Call</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default HomeCareView;
