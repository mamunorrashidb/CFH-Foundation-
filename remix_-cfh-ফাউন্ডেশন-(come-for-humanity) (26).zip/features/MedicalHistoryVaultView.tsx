
import React from 'react';
import { View } from '../types';

interface MedicalHistoryVaultViewProps {
  setActiveView: (view: View) => void;
}

const MedicalHistoryVaultView: React.FC<MedicalHistoryVaultViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex min-h-screen w-full flex-col overflow-x-hidden pb-24 bg-background-light dark:bg-background-dark text-[#111318] dark:text-white">
      <header className="sticky top-0 z-50 bg-primary px-4 pt-8 pb-6 text-white rounded-b-xl">
        <div className="flex items-center justify-between mb-4">
            <button onClick={() => setActiveView('telemedicine')} className="flex items-center gap-3">
                <div className="bg-white/20 p-2 rounded-lg backdrop-blur-md">
                    <span className="material-symbols-outlined text-white text-2xl">health_and_safety</span>
                </div>
                <div><h1 className="text-xl font-extrabold leading-tight">CFH</h1></div>
            </button>
        </div>
        <h2 className="text-lg font-bold tracking-tight">Medical History Vault</h2>
      </header>
       <div className="p-4">
        <div className="flex items-start gap-4 rounded-xl border border-primary/20 bg-primary/5 p-4 dark:bg-primary/10">
            <p className="text-primary text-sm font-bold leading-tight">Secure Data Encryption</p>
        </div>
      </div>
      <div className="px-4 pb-2">
        <div className="flex items-center justify-between mb-3">
            <h3 className="text-slate-900 dark:text-white text-md font-bold leading-tight">Uploaded Documents</h3>
        </div>
        <div className="space-y-3">
            <div className="flex items-center gap-4 bg-white dark:bg-gray-800 p-4 rounded-xl">
                <div className="flex size-12 shrink-0 items-center justify-center rounded-lg bg-blue-50 dark:bg-blue-900/30">
                    <span className="material-symbols-outlined text-primary">description</span>
                </div>
                <p className="text-sm font-bold truncate">Blood Test Report</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default MedicalHistoryVaultView;
