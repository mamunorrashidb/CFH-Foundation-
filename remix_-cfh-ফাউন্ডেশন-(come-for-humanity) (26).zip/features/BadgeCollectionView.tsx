
import React from 'react';
import { View } from '../types';

interface BadgeCollectionViewProps {
  setActiveView: (view: View) => void;
}

const BadgeCollectionView: React.FC<BadgeCollectionViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-[#111317] dark:text-white min-h-screen">
      <nav className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center p-4 justify-between max-w-md mx-auto">
          <div className="flex items-center">
            <button onClick={() => setActiveView('profile')} className="material-symbols-outlined text-primary cursor-pointer">arrow_back_ios</button>
          </div>
          <h2 className="text-primary text-lg font-bold leading-tight tracking-tight flex-1 text-center font-display">My Badge Collection</h2>
          <div className="w-10"></div>
        </div>
      </nav>
      <main className="max-w-md mx-auto pb-24">
        <section className="p-4 mt-2">
            <div className="bg-primary/5 dark:bg-primary/10 rounded-xl p-5 border border-primary/10">
                <p className="text-primary text-2xl font-black">12/25</p>
                <p className="text-[10px] font-medium text-primary/60 uppercase">Badges Earned</p>
                <div className="relative h-3 w-full bg-primary/20 rounded-full overflow-hidden mt-4">
                    <div className="absolute top-0 left-0 h-full bg-primary rounded-full" style={{ width: '48%' }}></div>
                </div>
            </div>
        </section>
        <section className="px-4 pt-6">
          <div className="grid grid-cols-3 gap-6">
            <div className="flex flex-col items-center gap-2">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 p-1 shadow-md">
                    <div className="w-full h-full rounded-full border-2 border-white/30 flex items-center justify-center overflow-hidden bg-emerald-500">
                        <img className="w-12 h-12 invert brightness-0" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBto2Kf8B0pJz2DufSwhASXI67_hl7zDgfSzlXZ1veW1g6XAQuQINrs72hm8cXUAyaz-3zKdnBovcXSi3jQIeD9PzlOCT5xAoj5qPRtovVrB0dijhwEm1LKvDofutokRBNI8JATWFo4og6R9KDAGJ_JcZKkFRTAMiflDy2VGsj1VteybI0G18KuUfr8zWoHcJ7QCrVAartes-ydINYSAJ6Ib1kT_DH9ZhXZ_ygn8hIlpCu5GAxwn43Sudu8BzDfucd93Cr8MmZEa_Mn"/>
                    </div>
                </div>
                <p className="text-primary text-[11px] font-bold text-center leading-tight">Life Saver</p>
            </div>
             <div className="flex flex-col items-center gap-2">
                <div className="relative locked-badge w-20 h-20 rounded-full bg-gray-200 dark:bg-gray-700 p-1">
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"><span className="material-symbols-outlined text-gray-500">lock</span></div>
                </div>
                <p className="text-gray-400 text-[11px] font-medium text-center leading-tight">Local Hero</p>
            </div>
          </div>
        </section>
      </main>
      <style>{`.locked-badge { filter: grayscale(1) opacity(0.4); }`}</style>
    </div>
  );
};

export default BadgeCollectionView;
