
import React, { useState } from 'react';

// --- Component-Specific Types ---
type VerificationStatus = 'verified' | 'invalid' | 'idle';
type VerificationType = 'Employee ID' | 'Entrepreneur ID' | 'Certificate' | 'N/A';

interface VerificationResult {
  status: VerificationStatus;
  type: VerificationType;
  details: { [key: string]: string };
}

// --- Mock Database for Simulation ---
// In a real application, this would be a secure API call.
const MOCK_DB: { [id: string]: Omit<VerificationResult, 'status'> } = {
  'CFH-ENT-002': {
    type: 'Entrepreneur ID',
    details: { নাম: 'ফাতেমা বেগম', 'স্টোরের নাম': 'স্বপ্নগড়ি হস্তশিল্প', স্ট্যাটাস: 'সক্রিয়' }
  },
  'CFH-EMP-451': {
    type: 'Employee ID',
    details: { নাম: 'ফাতেমা বেগম', পদবি: 'প্রধান কারিগর', স্ট্যাটাস: 'সক্রিয়' }
  },
  'CFH-IT-1721052000': { // Mock certificate ID
    type: 'Certificate',
    details: { নাম: 'জামিল আহমেদ', কোর্স: 'রিঅ্যাক্ট.জেএস ফান্ডামেন্টালস', 'সম্পন্ন করার তারিখ': '১৫-জুলাই-২০২৪' }
  }
};

const VerificationView: React.FC = () => {
    const [idInput, setIdInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<VerificationResult | null>(null);

    const handleVerify = async (idToVerify: string) => {
        if (!idToVerify) return;
        setIsLoading(true);
        setResult(null);

        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 1200));

        const record = MOCK_DB[idToVerify.trim().toUpperCase()];
        if (record) {
            setResult({ status: 'verified', ...record });
        } else {
            setResult({
                status: 'invalid',
                type: 'N/A',
                details: { ত্রুটি: 'এই আইডির জন্য কোনো বৈধ রেকর্ড পাওয়া যায়নি।' }
            });
        }
        setIsLoading(false);
    };

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        handleVerify(idInput);
    };
    
    const handleQrScan = () => {
        // Simulate scanning a valid QR code
        setIdInput('CFH-ENT-002');
        handleVerify('CFH-ENT-002');
    };
    
    const handleReset = () => {
        setIdInput('');
        setResult(null);
    };

    const ResultDisplay: React.FC<{ result: VerificationResult }> = ({ result }) => {
        const isVerified = result.status === 'verified';
        const colorClass = isVerified ? 'green' : 'red';

        return (
            <div className={`mt-8 border-l-4 border-${colorClass}-500 bg-${colorClass}-50 p-6 rounded-r-lg animate-fade-in`}>
                <div className="flex items-center space-x-3">
                    {isVerified ? (
                         <svg xmlns="http://www.w3.org/2000/svg" className={`h-8 w-8 text-${colorClass}-500`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    ) : (
                         <svg xmlns="http://www.w3.org/2000/svg" className={`h-8 w-8 text-${colorClass}-500`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    )}
                    <div>
                        <h3 className={`text-2xl font-bold text-${colorClass}-700`}>{isVerified ? 'সফলভাবে যাচাই করা হয়েছে' : 'যাচাইকরণ ব্যর্থ হয়েছে'}</h3>
                        {isVerified && <p className="text-gray-600 font-medium">ধরন: {result.type}</p>}
                    </div>
                </div>
                <div className="mt-4 pl-11 space-y-1">
                    {Object.entries(result.details).map(([key, value]) => (
                        <div key={key} className="text-md">
                            <span className="font-semibold text-gray-700">{key}:</span>
                            <span className="ml-2 text-gray-600">{value}</span>
                        </div>
                    ))}
                </div>
                <div className="text-right mt-4">
                     <button onClick={handleReset} className="text-sm font-semibold text-cfh-royal-blue hover:underline">আরেকটি আইডি যাচাই করুন</button>
                </div>
            </div>
        );
    };

    return (
        <div className="container mx-auto px-4">
            <div className="text-center my-8">
                <h2 className="text-3xl font-bold text-cfh-royal-blue">সিএফএইচ যাচাইকরণ পোর্টাল</h2>
                <p className="text-gray-600 mt-2">ডিজিটাল আইডি এবং সনদের সত্যতা যাচাই করুন।</p>
            </div>

            <div className="max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-xl">
                <form onSubmit={handleFormSubmit}>
                    <label htmlFor="verificationId" className="block text-lg font-medium text-gray-800 mb-2">আইডি নম্বর লিখুন</label>
                    <div className="flex flex-col sm:flex-row gap-4">
                        <input
                            id="verificationId"
                            type="text"
                            value={idInput}
                            onChange={(e) => setIdInput(e.target.value)}
                            placeholder="যেমন, CFH-ENT-002"
                            className="flex-grow px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-cfh-emerald-green"
                            disabled={isLoading}
                        />
                        <button type="submit" disabled={isLoading || !idInput} className="px-6 py-3 bg-cfh-royal-blue text-white font-semibold rounded-lg shadow-md hover:bg-cfh-royal-blue/90 transition-colors disabled:bg-gray-400">
                            {isLoading ? 'যাচাই করা হচ্ছে...' : 'যাচাই করুন'}
                        </button>
                    </div>
                </form>

                <div className="relative flex py-5 items-center">
                    <div className="flex-grow border-t border-gray-300"></div>
                    <span className="flex-shrink mx-4 text-gray-400 font-semibold">অথবা</span>
                    <div className="flex-grow border-t border-gray-300"></div>
                </div>

                <button onClick={handleQrScan} disabled={isLoading} className="w-full py-3 px-4 bg-gray-100 text-cfh-royal-blue font-bold rounded-lg border border-gray-300 flex items-center justify-center gap-3 hover:bg-gray-200 transition-colors disabled:opacity-50">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 0h-4m4 0l-5-5" /></svg>
                    কিউআর কোড স্ক্যান সিমুলেট করুন
                </button>
                
                {result && <ResultDisplay result={result} />}

            </div>
        </div>
    );
};

export default VerificationView;
