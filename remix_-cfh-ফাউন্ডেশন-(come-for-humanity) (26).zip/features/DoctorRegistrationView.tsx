
import React from 'react';
import { View } from '../types';

interface DoctorRegistrationViewProps {
  setActiveView: (view: View) => void;
}

const DoctorRegistrationView: React.FC<DoctorRegistrationViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-[#fafafa] dark:bg-[#181e2b] font-display text-[#131416] dark:text-white max-w-md mx-auto">
      <header className="sticky top-0 z-50 bg-white dark:bg-[#1f2937] border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center p-4 justify-between">
          <button onClick={() => setActiveView('telemedicine')} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"><span className="material-symbols-outlined text-[#2e4676] dark:text-blue-400">arrow_back</span></button>
          <span className="text-xs font-bold bg-[#2e4676]/10 text-[#2e4676] px-2 py-1 rounded">STEP 1/3</span>
        </div>
      </header>
      <main className="pb-32">
        <div className="px-4 py-6 text-center"><h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">Doctor Registration</h2><p className="text-lg font-medium text-gray-600 dark:text-gray-400 font-bengali">ডাক্তার নিবন্ধন</p></div>
        <section className="mt-6"><div className="px-4 mb-4"><h3 className="text-lg font-bold text-primary dark:text-blue-400">Personal Information / ব্যক্তিগত তথ্য</h3></div>
          <div className="space-y-4 px-4">
            <input className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 p-4 text-base" placeholder="Full Name"/>
            <input className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 p-4 text-base" placeholder="Email Address" type="email"/>
          </div>
        </section>
      </main>
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-white/90 dark:bg-[#1f2937]/90 backdrop-blur-md border-t border-gray-100 dark:border-gray-800 max-w-md mx-auto">
        <div className="p-4"><button className="w-full bg-primary hover:bg-[#1a2d52] text-white font-bold py-4 rounded-xl shadow-lg flex items-center justify-center gap-2"><span>Register as Volunteer Doctor</span><span className="material-symbols-outlined">arrow_forward</span></button></div>
      </div>
    </div>
  );
};

export default DoctorRegistrationView;
