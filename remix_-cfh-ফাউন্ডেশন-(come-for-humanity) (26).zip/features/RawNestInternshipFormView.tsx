
import React from 'react';
import { View } from '../types';

interface RawNestInternshipFormViewProps {
  setActiveView: (view: View) => void;
}

const RawNestInternshipFormView: React.FC<RawNestInternshipFormViewProps> = ({ setActiveView }) => {
  return (
    <div className="max-w-[480px] mx-auto bg-background-light dark:bg-background-dark min-h-screen flex flex-col relative pb-20">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800 px-4 py-3">
        <div className="flex items-center justify-between">
          <button onClick={() => setActiveView('graduate-success-stories')} className="flex items-center gap-3">
            <div className="size-10 rounded-lg bg-primary flex items-center justify-center overflow-hidden">
               <span className="material-symbols-outlined text-white">arrow_back</span>
            </div>
          </button>
        </div>
      </header>
      <div className="px-4 pt-6 pb-2">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">IT Internship Application</h2>
        <div className="h-1.5 w-full bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden mt-4">
          <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: '25%' }}></div>
        </div>
      </div>
      <main className="flex-1 px-4 space-y-6 pt-4">
        <section className="space-y-4">
          <h3 className="text-lg font-bold text-gray-800 dark:text-white">Internship Track / ইন্টার্নশিপ ট্র্যাক</h3>
          <div className="grid grid-cols-1 gap-3">
            <label className="relative flex items-center p-4 rounded-xl border-2 border-primary bg-primary/5 cursor-pointer">
              <div className="flex-1"><p className="font-bold text-primary">Web Development</p></div>
              <span className="material-symbols-outlined text-primary">check_circle</span>
            </label>
          </div>
        </section>
      </main>
      <footer className="fixed bottom-0 left-0 right-0 p-4 max-w-[480px] mx-auto">
        <button className="w-full bg-emerald-success text-white font-bold py-4 rounded-xl">
          Submit Application
        </button>
      </footer>
    </div>
  );
};

export default RawNestInternshipFormView;
