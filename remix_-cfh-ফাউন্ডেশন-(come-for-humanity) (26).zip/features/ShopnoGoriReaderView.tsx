
import React from 'react';
import { View } from '../types';

interface ShopnoGoriReaderViewProps {
  setActiveView: (view: View, props?: any) => void;
  studentName?: string;
  courseName?: string;
}

const ShopnoGoriReaderView: React.FC<ShopnoGoriReaderViewProps> = ({ setActiveView, studentName = "শিক্ষার্থী", courseName = "বেসিক কেক বেকিং কোর্স" }) => {
  const progress = 35; // Example progress

  const handleCompleteCourse = () => {
      setActiveView('shopno-gori-certificate', { studentName, courseName });
  };

  return (
    <div className="bg-background-light dark:bg-background-dark text-[#121317] dark:text-gray-100 font-display transition-colors duration-300 min-h-screen">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center px-4 h-16 justify-between max-w-2xl mx-auto">
          <button onClick={() => setActiveView('ecommerce')} className="flex items-center justify-center size-10 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-primary">
            <span className="material-symbols-outlined">arrow_back_ios_new</span>
          </button>
          <div className="flex flex-col items-center">
            <h2 className="text-sm font-extrabold leading-tight truncate max-w-[180px] font-bengali">{courseName}</h2>
            <p className="text-xs text-gray-500 font-bengali">অধ্যায় ১: উপকরণ পরিচিতি</p>
          </div>
          <div className="w-10"></div>
        </div>
        <div className="h-1 bg-gray-100 dark:bg-gray-800">
          <div className="h-full bg-primary" style={{ width: `${progress}%` }}></div>
        </div>
      </header>
      
      <main className="max-w-2xl mx-auto pb-32">
        <div className="relative aspect-video w-full overflow-hidden bg-gray-200">
            <img src="https://images.pexels.com/photos/827513/pexels-photo-827513.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="Baking ingredients" className="w-full h-full object-cover" />
        </div>
        <article className="px-6 py-8 space-y-6">
          <h1 className="text-2xl font-bold font-bengali text-gray-900 dark:text-white">কেকের উপকরণ পরিচিতি ও সঠিক পরিমাপ</h1>
          <p className="text-base font-medium leading-relaxed text-gray-700 dark:text-gray-300 font-bengali">
            একটি নিখুঁত কেক তৈরির প্রথম ধাপ হলো সঠিক উপকরণ চেনা এবং তার সঠিক পরিমাপ জানা। এই অধ্যায়ে আমরা ময়দা, চিনি, ডিম, বেকিং পাউডার এবং অন্যান্য প্রয়োজনীয় উপকরণ সম্পর্কে বিস্তারিত আলোচনা করবো। প্রতিটি উপকরণের কাজ এবং কীভাবে তা আপনার কেকে প্রভাব ফেলে, তা জানতে পারবেন।
          </p>
        </article>
      </main>

      <footer className="fixed bottom-0 left-0 right-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-xl border-t border-gray-100 dark:border-gray-800">
        <div className="max-w-2xl mx-auto p-4">
             <button onClick={handleCompleteCourse} className="w-full h-14 bg-primary text-white rounded-xl font-bold text-base shadow-lg shadow-primary/30 active:scale-95 transition-transform font-bengali flex items-center justify-center gap-2">
                <span className="material-symbols-outlined">workspace_premium</span>
                কোর্স সম্পন্ন করে সার্টিফিকেট নিন
            </button>
        </div>
      </footer>
    </div>
  );
};

export default ShopnoGoriReaderView;
