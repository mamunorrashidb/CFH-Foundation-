
import React from 'react';
import { View } from '../types';

interface RawNestDigitalPortfolioViewProps {
  setActiveView: (view: View) => void;
}

const RawNestDigitalPortfolioView: React.FC<RawNestDigitalPortfolioViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-slate-800 dark:text-slate-100 font-body">
        <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3 flex items-center justify-between">
            <button onClick={() => setActiveView('ecommerce')} className="flex items-center gap-2">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center"><span className="text-white font-display font-bold text-xs">RD</span></div>
                <h1 className="font-display font-bold text-sm text-primary dark:text-white leading-none">RawNest Digital</h1>
            </button>
        </header>
        <main className="pb-24">
            <section className="px-5 py-8">
                <div className="bg-primary rounded-xl p-6 relative overflow-hidden">
                    <h2 className="font-display text-2xl font-bold text-white leading-tight mb-2">Transforming Ideas into Digital Reality</h2>
                </div>
            </section>
            <section className="px-5">
                <h3 className="font-display font-bold text-lg mb-5">Specialized Services</h3>
                <div className="grid grid-cols-2 gap-4">
                    <div className="bg-card-light dark:bg-card-dark p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm">
                        <h4 className="font-display font-bold text-sm mb-1 leading-tight">Software Development</h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-3 leading-snug">কাস্টম সফটওয়্যার সমাধান।</p>
                    </div>
                    <div className="bg-card-light dark:bg-card-dark p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm">
                        <h4 className="font-display font-bold text-sm mb-1 leading-tight">Cyber Security</h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-3 leading-snug">ডিজিটাল নিরাপত্তা নিশ্চিতকরণ।</p>
                    </div>
                </div>
            </section>
        </main>
    </div>
  );
};

export default RawNestDigitalPortfolioView;
