import React, { useState, useEffect } from 'react';
import { View } from '../types';
import { db } from '../lib/firebase';
import { collection, onSnapshot, addDoc, deleteDoc, doc, updateDoc, query, orderBy, setDoc, getDoc } from 'firebase/firestore';

interface NewsItem {
    id: string;
    title: string;
    content: string;
    imageUrl?: string;
    publishedAt: string;
}

interface AppSettings {
    isBloodBankEnabled: boolean;
    isOxygenServiceEnabled: boolean;
    isTelemedicineEnabled: boolean;
    isChatBotEnabled: boolean;
    announcementTicker: string;
}

const AdminPanelView: React.FC<{ setActiveView: (view: View) => void, user: any }> = ({ setActiveView, user }) => {
    const [news, setNews] = useState<NewsItem[]>([]);
    const [settings, setSettings] = useState<AppSettings>({
        isBloodBankEnabled: true,
        isOxygenServiceEnabled: true,
        isTelemedicineEnabled: true,
        isChatBotEnabled: true,
        announcementTicker: "সিএফএইচ অ্যাপে আপনাকে স্বাগতম!"
    });
    const [isAddingNews, setIsAddingNews] = useState(false);
    const [newTitle, setNewTitle] = useState('');
    const [newContent, setNewContent] = useState('');
    const [newImageUrl, setNewImageUrl] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Real-time news management
        const q = query(collection(db, 'news'), orderBy('publishedAt', 'desc'));
        const unsubscribeNews = onSnapshot(q, (snapshot) => {
            const newsData = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            })) as NewsItem[];
            setNews(newsData);
        });

        // Real-time settings management
        const unsubscribeSettings = onSnapshot(doc(db, 'settings', 'app_config'), (docSnap) => {
            if (docSnap.exists()) {
                setSettings(docSnap.data() as AppSettings);
            }
            setLoading(false);
        });

        return () => {
            unsubscribeNews();
            unsubscribeSettings();
        };
    }, []);

    const toggleFeature = async (feature: keyof AppSettings) => {
        try {
            const settingsRef = doc(db, 'settings', 'app_config');
            await updateDoc(settingsRef, {
                [feature]: !settings[feature]
            });
        } catch (error) {
            // If document doesn't exist, create it
            const settingsRef = doc(db, 'settings', 'app_config');
            await setDoc(settingsRef, {
                ...settings,
                [feature]: !settings[feature]
            });
        }
    };

    const handleUpdateTicker = async () => {
        const text = prompt("টিক্কার মেসেজ পরিবর্তন করুন:", settings.announcementTicker);
        if (text !== null) {
            const settingsRef = doc(db, 'settings', 'app_config');
            await setDoc(settingsRef, { ...settings, announcementTicker: text }, { merge: true });
        }
    };

    const handleUpdateBloodStats = async () => {
        const currentStats = news.length > 0 ? "" : ""; // Just placeholder
        const text = prompt("ব্লাড ব্যাংক স্ক্রল মেসেজগুলি লিখুন (কমা দিয়ে আলাদা করুন):", "এ পজিটিভ রক্ত প্রয়োজন - মেহেরপুর সদর, ও পজিটিভ ডোনার ইচ্ছুক - গাংনী");
        if (text !== null) {
            const stats = text.split(',').map(s => s.trim());
            const statsRef = doc(db, 'settings', 'live_stats');
            await setDoc(statsRef, { bloodStats: stats });
            alert("সফলভাবে আপডেট হয়েছে!");
        }
    };

    const handleAddNews = async () => {
        if (!newTitle || !newContent) return;
        try {
            await addDoc(collection(db, 'news'), {
                title: newTitle,
                content: newContent,
                imageUrl: newImageUrl,
                publishedAt: new Date().toISOString(),
                author: user?.displayName || 'Admin'
            });
            setNewTitle('');
            setNewContent('');
            setNewImageUrl('');
            setIsAddingNews(false);
        } catch (error) {
            console.error("Error adding news:", error);
            alert("নিউজ যোগ করতে সমস্যা হয়েছে।");
        }
    };

    const handleDeleteNews = async (id: string) => {
        if (window.confirm("আপনি কি নিশ্চিত যে এই নিউজটি মুছে ফেলতে চান?")) {
            await deleteDoc(doc(db, 'news', id));
        }
    };

    return (
        <div className="bg-background-light dark:bg-background-dark min-h-screen pb-24">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
                <button onClick={() => setActiveView('profile')} className="size-10 flex items-center justify-center -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>
                <h1 className="text-lg font-bold font-bengali">অ্যাডমিন কন্ট্রোল সেন্টার</h1>
                <div className="w-10"></div>
            </header>

            <main className="p-4 space-y-6">
                {/* Statistics Overview */}
                <div className="grid grid-cols-2 gap-4">
                    <div className="bg-primary/10 p-4 rounded-2xl border border-primary/20">
                        <span className="text-primary text-xs font-bold font-bengali">মোট নিউজ</span>
                        <h3 className="text-2xl font-bold text-primary">{news.length}</h3>
                    </div>
                    <div className="bg-emerald-500/10 p-4 rounded-2xl border border-emerald-500/20">
                        <span className="text-emerald-600 text-xs font-bold font-bengali">সক্রিয় ক্যাম্পেইন</span>
                        <h3 className="text-2xl font-bold text-emerald-600">৩</h3>
                    </div>
                </div>

                {/* User Settings Control */}
                <section className="bg-gold/10 p-6 rounded-3xl border border-gold/20">
                    <h2 className="text-xl font-bold font-bengali text-gold mb-2 flex items-center gap-2">
                        <span className="material-symbols-outlined">settings_suggest</span>
                        ইউজার অ্যাপ কন্ট্রোল
                    </h2>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mb-6 font-bengali">এখান থেকে আপনি ইউজার অ্যাপের মূল ফিচারগুলো নিয়ন্ত্রণ করতে পারেন।</p>
                    
                    <div className="space-y-3">
                        {[
                            { id: 'isBloodBankEnabled', label: 'ব্লাড ব্যাংক সিস্টেম', icon: 'bloodtype' },
                            { id: 'isOxygenServiceEnabled', label: 'অক্সিজেন সার্ভিস', icon: 'masks' },
                            { id: 'isTelemedicineEnabled', label: 'টেলিমেডিসিন', icon: 'stethoscope' },
                            { id: 'isChatBotEnabled', label: 'হিউম্যানিটি বট', icon: 'smart_toy' }
                        ].map((feature) => (
                            <div key={feature.id} className="flex items-center justify-between p-4 bg-white dark:bg-card-dark rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
                                <div className="flex items-center gap-3">
                                    <span className={`material-symbols-outlined ${settings[feature.id as keyof AppSettings] ? 'text-primary' : 'text-gray-400'}`}>{feature.icon}</span>
                                    <span className="font-bold font-bengali">{feature.label}</span>
                                </div>
                                <button 
                                    onClick={() => toggleFeature(feature.id as keyof AppSettings)}
                                    className={`w-14 h-7 rounded-full relative transition-colors duration-300 ${settings[feature.id as keyof AppSettings] ? 'bg-primary' : 'bg-gray-300'}`}
                                >
                                    <div className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-all duration-300 ${settings[feature.id as keyof AppSettings] ? 'left-8' : 'left-1'}`}></div>
                                </button>
                            </div>
                        ))}

                        <div className="mt-4 p-4 bg-primary/5 rounded-2xl border border-primary/10">
                            <h4 className="text-xs font-bold text-primary mb-2 font-bengali">অ্যানাউন্সমেন্ট টিক্কার (Live Ticker)</h4>
                            <div className="flex items-center justify-between gap-3">
                                <p className="text-sm font-medium font-bengali truncate flex-1">{settings.announcementTicker}</p>
                                <button onClick={handleUpdateTicker} className="text-primary material-symbols-outlined">edit</button>
                            </div>
                        </div>

                        <div className="mt-2 p-4 bg-red-500/5 rounded-2xl border border-red-500/10">
                            <h4 className="text-xs font-bold text-red-600 mb-2 font-bengali">ব্লাড ব্যাংক স্ক্রল ডেটা (Live Stats)</h4>
                            <div className="flex items-center justify-between gap-3">
                                <p className="text-sm font-medium font-bengali truncate flex-1 text-red-700">রক্তদান সংক্রান্ত সচল বার্তা সমূহ</p>
                                <button onClick={handleUpdateBloodStats} className="text-red-500 material-symbols-outlined">edit</button>
                            </div>
                        </div>
                    </div>
                </section>

                {/* News Management Section */}
                <section>
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-bold font-bengali">নিউজ ম্যানেজমেন্ট</h2>
                        <button 
                            onClick={() => setIsAddingNews(true)}
                            className="bg-primary text-white p-2 rounded-xl flex items-center gap-1 text-sm font-bold font-bengali shadow-md"
                        >
                            <span className="material-symbols-outlined text-sm">add</span>
                            নিউজ যোগ করুন
                        </button>
                    </div>

                    {isAddingNews && (
                        <div className="bg-white dark:bg-card-dark p-4 rounded-2xl border border-primary mb-6 shadow-xl animate-fade-in space-y-4">
                            <h3 className="font-bold font-bengali">নতুন নিউজ পোস্ট করুন</h3>
                            <input 
                                type="text"
                                placeholder="শিরোনাম"
                                value={newTitle}
                                onChange={(e) => setNewTitle(e.target.value)}
                                className="w-full p-4 rounded-xl bg-gray-50 dark:bg-gray-800 border-none focus:ring-2 focus:ring-primary font-bengali"
                            />
                            <textarea 
                                placeholder=" বিস্তারিত বর্ণনা"
                                value={newContent}
                                onChange={(e) => setNewContent(e.target.value)}
                                className="w-full p-4 rounded-xl bg-gray-50 dark:bg-gray-800 border-none focus:ring-2 focus:ring-primary font-bengali h-32"
                            />
                            <input 
                                type="text"
                                placeholder="ছবির ডিরেক্ট লিংক (ঐচ্ছিক)"
                                value={newImageUrl}
                                onChange={(e) => setNewImageUrl(e.target.value)}
                                className="w-full p-4 rounded-xl bg-gray-50 dark:bg-gray-800 border-none focus:ring-2 focus:ring-primary font-bengali"
                            />
                            <div className="flex gap-3">
                                <button 
                                    onClick={handleAddNews}
                                    className="flex-1 bg-primary text-white font-bold py-4 rounded-xl font-bengali shadow-lg shadow-primary/25"
                                >
                                    পাবলিশ করুন
                                </button>
                                <button 
                                    onClick={() => setIsAddingNews(false)}
                                    className="px-6 py-4 bg-gray-100 dark:bg-gray-800 font-bold rounded-xl font-bengali"
                                >
                                    বাতিল
                                </button>
                            </div>
                        </div>
                    )}

                    <div className="space-y-4">
                        {loading ? (
                            <div className="text-center py-10 text-gray-400 font-bengali">নিউজ লোড হচ্ছে...</div>
                        ) : news.length === 0 ? (
                            <div className="text-center py-10 text-gray-400 font-bengali">কোনো নিউজ নেই।</div>
                        ) : (
                            news.map(item => (
                                <div key={item.id} className="bg-white dark:bg-card-dark p-4 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm">
                                    <div className="flex justify-between items-start mb-2">
                                        <h3 className="font-bold text-gray-800 dark:text-white font-bengali flex-1 pr-4">{item.title}</h3>
                                        <button 
                                            onClick={() => handleDeleteNews(item.id)}
                                            className="text-red-500 hover:bg-red-50 p-2 rounded-full transition-colors"
                                        >
                                            <span className="material-symbols-outlined">delete</span>
                                        </button>
                                    </div>
                                    <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-2 font-bengali mb-3">
                                        {item.content}
                                    </p>
                                    {item.imageUrl && (
                                        <div className="mb-3 rounded-lg overflow-hidden h-20 w-32 border border-gray-100">
                                            <img src={item.imageUrl} alt="preview" className="w-full h-full object-cover" />
                                        </div>
                                    )}
                                    <div className="text-[10px] text-gray-400 font-medium font-bengali flex justify-between">
                                        <span>প্রকাশিত: {new Date(item.publishedAt).toLocaleDateString('bn-BD')}</span>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </section>
            </main>
        </div>
    );
};

export default AdminPanelView;
