
import React from 'react';
import { View } from '../types';

interface EventsCalendarViewProps {
  setActiveView: (view: View) => void;
}

const EventsCalendarView: React.FC<EventsCalendarViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-primary dark:text-white font-display max-w-md mx-auto">
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-neutral-200 dark:border-neutral-800">
        <div className="flex items-center justify-between p-4 pb-2">
          <button onClick={() => setActiveView('dashboard')} className="size-10 flex items-center justify-center rounded-full bg-neutral-100 dark:bg-neutral-800">
            <span className="material-symbols-outlined text-primary dark:text-white">chevron_left</span>
          </button>
          <h2 className="text-[#002366] dark:text-emerald text-lg font-bold leading-tight tracking-tight">Global Events</h2>
          <div className="w-10"></div>
        </div>
      </header>
      <main className="pb-24">
        <div className="px-4 py-3">
          <div className="relative w-full h-[218px] bg-center bg-cover rounded-xl overflow-hidden shadow-lg" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCwP_TwMzSTcIBcR743RFR8FyKjsZ2-uGcEcL1hP0cpJ822TxslLqRUh9rBLeqctmR4gMJuFdQV2m_tTq7cg3TpMtyI5C-RTHo738zAlobMO2m-VHvMA2TbzA39uMcMA7l9ovrzUKRVmwmA1gHDBOUPQV4Uvw1H2-G0RWnbII9XAcj7Cpl2UXX_sKb9qN4oBRDtOu3Zd8RiDOgZN3al8lDzL3yofBrJT6KwqVUyGIyB-Yf10xZckVnyRBdmRzlM9YF9AYnSXwtFBoDa')"}}>
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-5">
              <span className="bg-[#002366] text-white text-[10px] font-bold px-2 py-1 rounded w-max mb-2 uppercase">Global Major Event</span>
              <h1 className="text-white text-2xl font-bold leading-tight">Annual Health Summit 2024</h1>
            </div>
          </div>
        </div>
        <div className="px-4 py-2 flex items-center justify-between">
          <h3 className="text-primary dark:text-white text-lg font-bold tracking-tight">Today's Schedule</h3>
        </div>
        <div className="px-4 space-y-4">
          <div className="bg-white dark:bg-neutral-800 rounded-xl p-4 shadow-sm border border-neutral-100 dark:border-neutral-700">
            <h4 className="text-base font-bold leading-tight">Central Park Mobile Unit</h4>
            <div className="flex items-center gap-2 mt-1">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#002366]/10 text-[#002366] uppercase">Blood Drive</span>
              <span className="flex items-center gap-1 text-[10px] font-bold text-emerald uppercase"><span className="size-1.5 bg-emerald rounded-full animate-pulse"></span>Live Now</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default EventsCalendarView;
