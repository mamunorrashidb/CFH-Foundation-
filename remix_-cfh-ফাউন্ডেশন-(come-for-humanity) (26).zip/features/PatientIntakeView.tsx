
import React from 'react';
import { View } from '../types';

interface PatientIntakeViewProps {
  setActiveView: (view: View) => void;
}

const PatientIntakeView: React.FC<PatientIntakeViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-md mx-auto overflow-x-hidden bg-background-light dark:bg-background-dark">
      <header className="sticky top-0 z-20 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-4 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center gap-3">
          <button onClick={() => setActiveView('telemedicine')} className="material-symbols-outlined text-royal-blue cursor-pointer">arrow_back_ios</button>
          <h1 className="text-xl font-extrabold tracking-tight text-royal-blue">Patient Intake</h1>
        </div>
      </header>
      <div className="px-6 pt-6 pb-2">
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs font-bold uppercase tracking-widest text-primary">Step 02 of 04</span>
          <span className="text-xs font-medium text-gray-400">Symptoms & History</span>
        </div>
        <div className="flex w-full flex-row items-center justify-between gap-2">
            <div className="h-1.5 flex-1 rounded-full bg-primary"></div>
            <div className="h-1.5 flex-1 rounded-full bg-primary"></div>
            <div className="h-1.5 flex-1 rounded-full bg-gray-100 dark:bg-gray-800"></div>
            <div className="h-1.5 flex-1 rounded-full bg-gray-100 dark:bg-gray-800"></div>
        </div>
      </div>
      <main className="flex-1 px-4 pb-32">
        <section className="mt-6">
          <h2 className="text-lg font-bold text-royal-blue px-1 mb-4">Current Symptoms</h2>
          <div className="rounded-xl bg-white dark:bg-gray-900 border border-gray-50 dark:border-gray-800 p-4">
            <textarea className="w-full min-h-[140px] p-4 text-sm bg-transparent border-none focus:ring-0 placeholder:text-gray-400" placeholder="Describe your symptoms..."></textarea>
          </div>
        </section>
        <section className="mt-8">
            <h2 className="text-lg font-bold text-royal-blue px-1 mb-4">Upload Documents</h2>
            <div className="aspect-square flex flex-col items-center justify-center border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50/50 dark:bg-gray-800/30 cursor-pointer">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mb-2"><span className="material-symbols-outlined text-primary">add_a_photo</span></div>
                <span className="text-[10px] font-bold uppercase tracking-tight text-gray-400">Add Media</span>
            </div>
        </section>
      </main>
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/80 dark:bg-background-dark/80 backdrop-blur-xl border-t border-gray-100 dark:border-gray-800 z-30 max-w-md mx-auto">
        <button className="w-full bg-primary text-white font-bold py-4 rounded-xl shadow-lg">Proceed to Consultation</button>
      </div>
    </div>
  );
};

export default PatientIntakeView;
