
import React from 'react';
import { View } from '../types';

interface SocialMediaImpactKitViewProps {
  setActiveView: (view: View) => void;
}

const SocialMediaImpactKitView: React.FC<SocialMediaImpactKitViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex h-screen w-full flex-col overflow-hidden max-w-[430px] mx-auto bg-white dark:bg-background-dark shadow-2xl">
      <div className="flex items-center bg-white dark:bg-background-dark p-4 pb-2 justify-between shrink-0">
        <button onClick={() => setActiveView('impact-tracker')} className="text-[#101418] dark:text-white flex size-12 shrink-0 items-center justify-start cursor-pointer">
          <span className="material-symbols-outlined">arrow_back_ios</span>
        </button>
        <h2 className="text-[#101418] dark:text-white text-lg font-extrabold leading-tight tracking-tight flex-1 text-center">Impact Kit</h2>
        <div className="w-12"></div>
      </div>
      <div className="flex-1 overflow-y-auto no-scrollbar bg-background-light dark:bg-gray-900/50">
        <div className="flex justify-between items-end px-6 pt-6 pb-2">
          <h3 className="text-[#101418] dark:text-white text-xl font-extrabold tracking-tight">Preview Story</h3>
        </div>
        <div className="px-6 py-4">
          <div className="relative w-full aspect-[9/16] rounded-xl overflow-hidden shadow-2xl ring-1 ring-black/5">
            <div className="absolute inset-0 bg-center bg-cover" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDTHDcZK4UkHhskil-fChqywzE9HKLKu4PHaPoY3UGbF9rvNnI0Gb_SgHPoLSa_SKMCVCW33qqAmG2WJIOk9sY5Q1oBz2_veqAK4NufaNzlcdHTj_5yi1ubPvGAOUCcGume1ufCXzPqjAXheNA_4mf3D-JW5qzd8ble-UNZyHYsOS2iYSNNqYBKCyl_QzQi3smH5v713DPFhQ8peoATVZPaRoMlAQObQ9U2AdMdh2wWsrMV5Kyvk9WkimhoZ3Yg7ApOxzmuciMj2zqC')"}}></div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40"></div>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 bg-white/90 dark:bg-background-dark/90 backdrop-blur-xl border-t border-gray-100 dark:border-gray-800 p-6 pb-10 flex gap-4">
        <button className="flex-1 bg-primary text-white font-extrabold py-4 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-primary/25 active:scale-95 transition-transform">
          Share Directly
        </button>
      </div>
    </div>
  );
};

export default SocialMediaImpactKitView;
