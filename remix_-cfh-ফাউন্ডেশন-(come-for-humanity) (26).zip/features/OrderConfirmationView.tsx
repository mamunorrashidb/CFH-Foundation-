
import React from 'react';
import { View } from '../types';

interface Product {
  id: number;
  name: string;
  price: string;
  image: string;
}

interface OrderConfirmationViewProps {
  setActiveView: (view: View) => void;
  orderId?: string;
  product?: Product;
}

const OrderConfirmationView: React.FC<OrderConfirmationViewProps> = ({ setActiveView, orderId, product }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-gray-800 dark:text-white min-h-screen flex flex-col items-center justify-center p-4">
      <main className="max-w-md w-full text-center">
        <div className="mb-6">
          <div className="w-24 h-24 bg-success/10 rounded-full flex items-center justify-center mx-auto">
            <span className="material-symbols-outlined text-success text-6xl">check_circle</span>
          </div>
        </div>
        
        <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white mb-2 font-bengali">অর্ডার সম্পন্ন হয়েছে!</h1>
        <p className="text-gray-600 dark:text-gray-400 max-w-xs mx-auto font-bengali leading-relaxed">আপনার অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে। আমাদের একজন প্রতিনিধি শীঘ্রই আপনার সাথে যোগাযোগ করবে।</p>

        <div className="bg-white dark:bg-card-dark rounded-2xl p-6 border border-gray-100 dark:border-gray-800 shadow-sm mt-8 text-left space-y-4">
            <h2 className="text-lg font-bold font-bengali mb-3">অর্ডার সারসংক্ষেপ</h2>
             {orderId && (
                <p className="text-xs text-center text-gray-500 font-mono bg-gray-50 dark:bg-gray-800/50 py-2 rounded">ORDER ID: #{orderId}</p>
            )}
            <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600 dark:text-gray-400 font-bengali">{product?.name || 'Product'} (x1)</span>
                <span className="font-bold font-bengali">৳{product?.price || '0.00'}</span>
            </div>
             <div className="border-t border-gray-100 dark:border-gray-700 pt-4 mt-4 flex justify-between items-center font-bold">
                <span className="font-bengali">সর্বমোট</span>
                <span className="text-primary text-lg font-bengali">৳{product?.price || '0.00'}</span>
            </div>
             <div className="text-center bg-primary/5 dark:bg-primary/10 text-primary dark:text-primary/90 text-xs font-bold p-3 rounded-lg mt-4 font-bengali">
                পেমেন্ট মেথড: ক্যাশ অন ডেলিভারি
            </div>
        </div>
        
        <div className="mt-8 space-y-3">
            <button onClick={() => setActiveView('ecommerce')} className="w-full bg-primary text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/20 active:scale-95 transition-transform font-bengali">
                শপে ফিরে যান
            </button>
             <button onClick={() => setActiveView('dashboard')} className="w-full text-primary font-bold py-3 rounded-xl hover:bg-primary/5 transition-colors font-bengali">
                ড্যাশবোর্ডে যান
            </button>
        </div>
      </main>
    </div>
  );
};

export default OrderConfirmationView;
