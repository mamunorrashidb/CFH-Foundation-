
import React, { useState, useMemo, useEffect } from 'react';
import { View } from '../types';
import { divisions, districts, upazilas } from '../data/locations';

interface VolunteerRegistrationViewProps {
  setActiveView: (view: View) => void;
}

const VolunteerRegistrationView: React.FC<VolunteerRegistrationViewProps> = ({ setActiveView }) => {
    const [formData, setFormData] = useState({
        fullName: '',
        phone: '',
        bloodGroup: '',
        lastDonationDate: '',
        skills: '',
        division: '',
        district: '',
        upazila: '',
        address: '',
    });

    const [currentStep, setCurrentStep] = useState(1);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    useEffect(() => {
        setFormData(prev => ({ ...prev, district: '', upazila: ''}));
    }, [formData.division]);

    useEffect(() => {
        setFormData(prev => ({ ...prev, upazila: ''}));
    }, [formData.district]);

    const availableDistricts = useMemo(() => {
        return formData.division ? districts[formData.division] || [] : [];
    }, [formData.division]);

    const availableUpazilas = useMemo(() => {
        return formData.district ? upazilas[formData.district] || [] : [];
    }, [formData.district]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        console.log('Volunteer Registration Data:', formData);
        alert('নিবন্ধন সফল হয়েছে! আমরা আপনার তথ্য যাচাই করে শীঘ্রই যোগাযোগ করব।');
        setActiveView('dashboard');
    };
    
    const nextStep = () => setCurrentStep(prev => Math.min(prev + 1, 3));
    const prevStep = () => setCurrentStep(prev => Math.max(prev - 1, 1));
    
    const bloodGroups = ['', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
    const progressPercentage = ((currentStep - 1) / 2) * 100;

  return (
    <div className="bg-background-light dark:bg-background-dark text-[#101815] dark:text-gray-100 min-h-screen max-w-md mx-auto flex flex-col">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center justify-between px-4 py-4">
          <button onClick={() => currentStep === 1 ? setActiveView('dashboard') : prevStep()} className="flex items-center justify-center size-10 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
            <span className="material-symbols-outlined text-[#101815] dark:text-white">arrow_back_ios_new</span>
          </button>
          <h1 className="text-lg font-bold tracking-tight font-bengali">স্বেচ্ছাসেবক নিবন্ধন</h1>
          <div className="size-10"></div>
        </div>
      </header>
      <main className="max-w-md mx-auto pb-10 flex-1 w-full">
        <div className="px-5 pt-6 pb-6">
            <div className="flex justify-between items-end mb-2">
                <p className="text-xs font-bold uppercase tracking-widest text-primary">ধাপ {currentStep}/৩</p>
                <p className="text-primary text-sm font-bold">{Math.round(progressPercentage)}%</p>
            </div>
            <div className="rounded-full bg-gray-100 dark:bg-gray-800 h-2 overflow-hidden">
                <div className="h-full rounded-full bg-primary transition-all duration-500" style={{ width: `${progressPercentage}%` }}></div>
            </div>
        </div>

        <form onSubmit={handleSubmit} className="px-5">
            {currentStep === 1 && (
                <div className="space-y-6 animate-fade-in">
                    <h2 className="text-2xl font-bold font-bengali">ব্যক্তিগত তথ্য</h2>
                    <div className="space-y-4">
                        <div className="space-y-1">
                            <label className="text-sm font-semibold mb-1.5 block font-bengali">আপনার পুরো নাম</label>
                            <input className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-4 font-bengali" name="fullName" value={formData.fullName} onChange={handleInputChange} placeholder="নাম লিখুন" type="text" required/>
                        </div>
                        <div className="space-y-1">
                            <label className="text-sm font-semibold mb-1.5 block font-bengali">মোবাইল নম্বর</label>
                            <input className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-4" name="phone" value={formData.phone} onChange={handleInputChange} placeholder="01XXX-XXXXXX" type="tel" required/>
                        </div>
                    </div>
                </div>
            )}
             {currentStep === 2 && (
                <div className="space-y-6 animate-fade-in">
                    <h2 className="text-2xl font-bold font-bengali">স্বেচ্ছাসেবক প্রোফাইল</h2>
                    <div className="space-y-4">
                         <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                                <label className="text-sm font-semibold mb-1.5 block font-bengali">রক্তের গ্রুপ</label>
                                <select className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-3 font-bengali" name="bloodGroup" value={formData.bloodGroup} onChange={handleInputChange}>
                                    {bloodGroups.map(group => <option key={group} value={group}>{group === '' ? 'ঐচ্ছিক' : group}</option>)}
                                </select>
                            </div>
                             <div className="space-y-1">
                                <label className="text-sm font-semibold mb-1.5 block font-bengali">সর্বশেষ রক্তদান</label>
                                <input className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-3" name="lastDonationDate" value={formData.lastDonationDate} onChange={handleInputChange} type="date" />
                            </div>
                        </div>
                        <div className="space-y-1">
                           <label className="text-sm font-semibold mb-1.5 block font-bengali">আপনার দক্ষতা/আগ্রহ</label>
                           <input className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-4 font-bengali" name="skills" value={formData.skills} onChange={handleInputChange} placeholder="যেমন: প্রাথমিক চিকিৎসা, শিক্ষাদান, আইটি" type="text"/>
                        </div>
                    </div>
                </div>
            )}
            {currentStep === 3 && (
                <div className="space-y-6 animate-fade-in">
                    <h2 className="text-2xl font-bold font-bengali">আপনার ঠিকানা</h2>
                     <div className="grid grid-cols-2 gap-4">
                         <div className="space-y-1">
                            <label className="text-sm font-semibold mb-1.5 block font-bengali">বিভাগ</label>
                            <select className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-3 font-bengali" name="division" value={formData.division} onChange={handleInputChange} required>
                               {divisions.map(d => <option key={d} value={d}>{d === '' ? 'নির্বাচন করুন' : d}</option>)}
                            </select>
                        </div>
                         <div className="space-y-1">
                            <label className="text-sm font-semibold mb-1.5 block font-bengali">জেলা</label>
                            <select className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-3 font-bengali disabled:opacity-50" name="district" value={formData.district} onChange={handleInputChange} required disabled={!formData.division}>
                                {availableDistricts.map(d => <option key={d} value={d}>{d === '' ? 'নির্বাচন করুন' : d}</option>)}
                            </select>
                        </div>
                    </div>
                    <div className="space-y-1">
                        <label className="text-sm font-semibold mb-1.5 block font-bengali">থানা / উপজেলা</label>
                        <select className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-3 font-bengali disabled:opacity-50" name="upazila" value={formData.upazila} onChange={handleInputChange} required disabled={!formData.district}>
                           {availableUpazilas.map(u => <option key={u} value={u}>{u === '' ? 'নির্বাচন করুন' : u}</option>)}
                        </select>
                    </div>
                     <div className="space-y-1">
                        <label className="text-sm font-semibold mb-1.5 block font-bengali">বিস্তারিত ঠিকানা</label>
                        <textarea className="w-full rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-4 py-3 font-bengali" name="address" value={formData.address} onChange={handleInputChange} placeholder="গ্রাম/রাস্তা, বাড়ি নং, পোস্ট অফিস" rows={2}></textarea>
                    </div>
                </div>
            )}
        </form>
      </main>
      <footer className="fixed bottom-0 left-0 right-0 p-4 bg-white/80 dark:bg-background-dark/80 backdrop-blur-xl border-t border-gray-100 dark:border-gray-800 z-50">
            <div className="max-w-md mx-auto flex gap-3">
                {currentStep > 1 && (
                    <button type="button" onClick={prevStep} className="h-14 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 rounded-xl font-bold w-1/3 font-bengali">ফিরে যান</button>
                )}
                {currentStep < 3 ? (
                    <button type="button" onClick={nextStep} className="h-14 bg-primary text-white rounded-xl font-bold flex-1 active:scale-95 transition-transform font-bengali">পরবর্তী</button>
                ) : (
                    <button type="submit" onClick={handleSubmit} className="h-14 bg-primary text-white rounded-xl font-bold flex-1 active:scale-95 transition-transform font-bengali">আবেদন জমা দিন</button>
                )}
            </div>
        </footer>
    </div>
  );
};

export default VolunteerRegistrationView;
