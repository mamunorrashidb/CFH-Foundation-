import React from 'react';
import { View } from '../types';

interface BookingConfirmationViewProps {
  setActiveView: (view: View) => void;
}

const BookingConfirmationView: React.FC<BookingConfirmationViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-[#0c1d18] dark:text-gray-100 min-h-screen">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-4 border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <div className="w-10 flex items-center">
            <span onClick={() => setActiveView('telemedicine')} className="material-symbols-outlined text-2xl cursor-pointer">arrow_back_ios</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-[#00c28e] rounded-lg flex items-center justify-center text-white font-extrabold text-sm italic">CFH</div>
            <h2 className="text-lg font-bold leading-tight tracking-tight">Come For Humanity</h2>
          </div>
          <div className="w-10"></div>
        </div>
      </header>
      <main className="max-w-md mx-auto px-4 pb-12 overflow-x-hidden">
        <div className="flex flex-col items-center pt-8 pb-6">
          <div className="w-20 h-20 bg-[#00c28e]/10 rounded-full flex items-center justify-center mb-6">
            <span className="material-symbols-outlined text-[#00c28e] text-5xl font-bold">check_circle</span>
          </div>
          <h1 className="text-[28px] font-extrabold leading-tight text-center">Booking Successful</h1>
          <h2 className="text-[24px] font-bold leading-tight text-center text-[#00c28e] mt-1 font-bengali">বুকিং সফল হয়েছে</h2>
        </div>
        <div className="bg-white dark:bg-gray-900 rounded-xl shadow-[0_10px_30px_rgba(0,0,0,0.04)] border border-gray-50 dark:border-gray-800 overflow-hidden mb-8">
          <div className="p-6 border-b border-dashed border-gray-200 dark:border-gray-700">
            <div className="flex justify-between items-start mb-4">
              <span className="px-3 py-1 bg-[#00c28e]/10 text-[#00c28e] text-xs font-bold rounded-full uppercase tracking-wider">Confirmed</span>
              <p className="text-gray-400 dark:text-gray-500 text-sm font-medium">ID: #CFH-123456</p>
            </div>
            <h3 className="text-xl font-bold mb-2">Home Nursing</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-3 text-gray-600 dark:text-gray-400"><span className="material-symbols-outlined text-[20px]">person</span><span className="text-sm">Provider: <span className="font-semibold text-[#0c1d18] dark:text-white">Sarah Ahmed</span></span></div>
              <div className="flex items-center gap-3 text-gray-600 dark:text-gray-400"><span className="material-symbols-outlined text-[20px]">calendar_today</span><span className="text-sm">Schedule: <span className="font-semibold text-[#0c1d18] dark:text-white">Oct 25, 2024 • 10:00 AM</span></span></div>
            </div>
          </div>
          <div className="p-6 bg-gray-50/50 dark:bg-gray-800/30">
            <h4 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-4">Pricing Breakdown</h4>
            <div className="space-y-3">
              <div className="flex justify-between text-sm"><span className="text-gray-600 dark:text-gray-400">Base Charge</span><span className="font-medium">৳ 2,500</span></div>
              <div className="flex justify-between text-sm pt-2 border-t border-gray-200 dark:border-gray-700 font-bold"><span>Total Amount</span><span>৳ 2,500</span></div>
              <div className="flex justify-between text-sm py-2 px-3 bg-[#00c28e]/5 rounded-lg border border-[#00c28e]/20 mt-2"><span className="text-[#00c28e] font-bold">Advance Paid</span><span className="text-[#00c28e] font-bold">৳ 500</span></div>
            </div>
          </div>
          <div className="p-8 flex flex-col items-center justify-center text-center">
            <div className="relative p-4 bg-white rounded-lg shadow-sm border border-gray-100"><img className="w-40 h-40" src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=CFH-123456" alt="Booking QR Code"/></div>
            <p className="mt-4 text-xs text-gray-500 dark:text-gray-400 max-w-[200px]">Show this QR code to your provider for verification.</p>
          </div>
        </div>
        <div className="flex flex-col gap-3">
          <button onClick={() => setActiveView('dashboard')} className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 text-[#0c1d18] dark:text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-[0.98]">
            <span className="material-symbols-outlined text-[20px]">home</span>Back to Home
          </button>
        </div>
      </main>
    </div>
  );
};

export default BookingConfirmationView;