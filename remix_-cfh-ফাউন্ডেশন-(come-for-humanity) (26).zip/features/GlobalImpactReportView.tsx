
import React from 'react';
import { View } from '../types';

interface GlobalImpactReportViewProps {
  setActiveView: (view: View) => void;
}

const GlobalImpactReportView: React.FC<GlobalImpactReportViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-[#181811] dark:text-white transition-colors duration-300">
        <div className="fixed top-0 z-50 w-full max-w-md mx-auto flex items-center bg-white/80 dark:bg-background-dark/80 backdrop-blur-md p-4 justify-between border-b border-gray-100 dark:border-white/10">
            <button onClick={() => setActiveView('dashboard')} className="text-[#181811] dark:text-white flex size-10 shrink-0 items-center justify-center bg-background-light dark:bg-white/5 rounded-full">
                <span className="material-symbols-outlined">close</span>
            </button>
            <h2 className="text-[#181811] dark:text-white text-base font-bold leading-tight tracking-tight flex-1 text-center font-display">Annual Impact Report '24</h2>
            <div className="w-10"></div>
        </div>
        <div className="pt-20 max-w-md mx-auto">
            <div className="p-4">
                <div className="relative bg-cover bg-center flex flex-col justify-end overflow-hidden rounded-xl min-h-[500px] shadow-2xl" style={{backgroundImage: 'linear-gradient(to top, rgba(0, 35, 102, 0.9) 0%, rgba(0, 0, 0, 0) 60%), url("https://lh3.googleusercontent.com/aida-public/AB6AXuDDpa8Cb22FfyaWBCZOx1XybAVejBK5wio6tZZ_j065fY8wBBoHPON_OG8cHRkqC24XPg_Vr5HdNIJFEFPRzIHe_gcuYjA8vpFL7tG5UtTsYpTs8KV_fkcPQSDoJHuSyRhqZM7im33DZ3QdGEtItUJ9Z3_YnBFr8Bc8f_7oi_Pt3x6TIQWXqc3d7CwskVGwfO8CYuvL9XzShuoH0j9aVEDtJlfVjBsentRqI-pRvuuB5DrsZZ2uHgmaQbl9sUVA47xrTTflHshDKct9")'}}>
                    <div className="p-6 pb-10">
                        <h1 className="text-white text-4xl font-bold leading-tight font-display mb-2">The Light of<br/><span className="text-primary">Humanity</span></h1>
                    </div>
                </div>
            </div>
            <div className="px-4 py-8 grid grid-cols-2 gap-4">
                <div className="bg-brand-emerald p-5 rounded-xl text-white flex flex-col justify-between h-40">
                    <div>
                        <p className="text-3xl font-bold font-display">50K+</p>
                        <p className="text-xs uppercase tracking-wider opacity-80">Lives Saved</p>
                    </div>
                </div>
                <div className="bg-brand-blue p-5 rounded-xl text-white flex flex-col justify-between h-40">
                     <div>
                        <p className="text-3xl font-bold font-display">12</p>
                        <p className="text-xs uppercase tracking-wider opacity-80">Countries Reached</p>
                    </div>
                </div>
            </div>
        </div>
        <style>{`.text-primary { color: #f9f506 }`}</style>
    </div>
  );
};

export default GlobalImpactReportView;
