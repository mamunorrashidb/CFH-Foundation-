import React, { useState, useEffect } from 'react';
import { View } from '../types';
import { getAffiliateDashboard } from '../services/apiService';

interface AffiliateDashboardViewProps {
  setActiveView: (view: View) => void;
}

interface AffiliateData {
    full_name: string;
    referral_code: string;
    user_type: string;
    balance: string;
    history: {
        commission_amount: string;
        created_at: string;
        total_amount: string;
    }[];
}

const AffiliateDashboardView: React.FC<AffiliateDashboardViewProps> = ({ setActiveView }) => {
    // In a real app, this would come from the logged-in user's context
    const MOCK_USER_ID = 6; 

    const [data, setData] = useState<AffiliateData | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');
    const [copySuccess, setCopySuccess] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await getAffiliateDashboard(MOCK_USER_ID);
                if (response.status === 'success') {
                    setData(response.data);
                } else {
                    setError(response.message);
                }
            } catch (err) {
                setError((err as Error).message);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, [MOCK_USER_ID]);

    const copyToClipboard = () => {
        if (data?.referral_code) {
            navigator.clipboard.writeText(data.referral_code).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000); // Reset after 2 seconds
            }, () => {
                alert('Code could not be copied.');
            });
        }
    };
    
    if (isLoading) return <div className="p-8 text-center">ড্যাশবোর্ড লোড হচ্ছে...</div>;
    if (error) return <div className="p-8 text-center text-red-500">ত্রুটি: {error}</div>;

    return (
        <div className="bg-background-light dark:bg-background-dark min-h-screen max-w-md mx-auto">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
                 <button onClick={() => setActiveView('profile')} className="p-2 -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"><span className="material-symbols-outlined">arrow_back_ios_new</span></button>
                 <h2 className="text-lg font-bold">Affiliate Dashboard</h2>
                 <div className="w-10"></div>
            </header>
            <main className="p-4 space-y-6">
                <div className="bg-primary/10 dark:bg-primary/20 border border-primary/20 rounded-xl p-6 text-center">
                    <p className="text-sm font-medium text-primary uppercase tracking-widest">Total Earnings</p>
                    <p className="text-5xl font-extrabold text-gray-800 dark:text-white mt-2">৳{parseFloat(data?.balance || '0').toFixed(2)}</p>
                    <p className="text-xs text-gray-500 mt-1">{data?.full_name}</p>
                </div>

                <div className="bg-white dark:bg-slate-800 rounded-xl p-4">
                    <p className="text-sm font-medium text-gray-500">Your Referral Code</p>
                    <div className="mt-2 flex items-center justify-between p-3 bg-gray-100 dark:bg-slate-700 rounded-lg">
                        <span className="font-mono font-bold text-lg text-primary">{data?.referral_code}</span>
                        <button onClick={copyToClipboard} className="text-primary hover:text-primary/80">
                            <span className="material-symbols-outlined">{copySuccess ? 'check' : 'content_copy'}</span>
                        </button>
                    </div>
                </div>

                 <div>
                    <h3 className="text-lg font-bold mb-3">Recent Commissions</h3>
                    <div className="space-y-3">
                        {data?.history && data.history.length > 0 ? data.history.map((item, index) => (
                             <div key={index} className="bg-white dark:bg-slate-800 rounded-lg p-3 flex items-center justify-between">
                                <div>
                                    <p className="font-bold text-success">+ ৳{parseFloat(item.commission_amount).toFixed(2)}</p>
                                    <p className="text-xs text-gray-500">from order (৳{parseFloat(item.total_amount).toFixed(2)})</p>
                                </div>
                                <p className="text-xs text-gray-400">{new Date(item.created_at).toLocaleDateString()}</p>
                            </div>
                        )) : (
                            <p className="text-center text-gray-500 text-sm py-4">No commissions earned yet.</p>
                        )}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default AffiliateDashboardView;