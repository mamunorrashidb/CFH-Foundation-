
import React from 'react';
import { View } from '../types';

interface InvestmentProjectDetailViewProps {
  setActiveView: (view: View) => void;
}

const InvestmentProjectDetailView: React.FC<InvestmentProjectDetailViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-[#111418] dark:text-gray-100 antialiased">
        <nav className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-800">
            <div className="flex items-center justify-between px-4 h-16">
                <button onClick={() => setActiveView('project-funding-tracker')} className="flex items-center justify-center size-10 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>
                <h1 className="font-bold text-lg tracking-tight">CFH Invest</h1>
                <div className="w-10"></div>
            </div>
        </nav>
        <main className="pb-32">
            <div className="relative w-full h-72">
                <div className="absolute inset-0 bg-cover bg-center" style={{backgroundImage: 'linear-gradient(180deg, rgba(15, 56, 123, 0.2) 0%, rgba(12, 23, 39, 0.8) 100%), url("https://lh3.googleusercontent.com/aida-public/AB6AXuBeUKHHb1HcAH3udXFLa_uYMDIJv70mPlFLFAI8UhPI5X9tC2RfbJcGKsxuOm3OTSa-wGc00b6BHoNJdW9CVkHYlonI6PcArenp_cog2EABkbBiJnWljV7RptVU3SLh8DMRCvfayDUiB82eksxdlqzszkLQyuyLfJcPL9X80alsYLIi2yWOs68OK1f49sJyRCK6thLeKwXoSHPPxZulL7P1x5bE5hawgFmrJ-1hrJK5bihCHA7Cf5ldZI1iNDB4gxM39fIKdGT-YAX8")'}}></div>
                <div className="absolute bottom-0 left-0 p-6 w-full">
                    <h2 className="text-white text-3xl font-bold leading-tight">Raw Food Bd Organic Farm Expansion</h2>
                </div>
            </div>
            <section className="px-4 py-6">
                <div className="bg-white dark:bg-gray-900 rounded-xl p-5 shadow-sm border border-gray-100 dark:border-gray-800">
                    <p className="text-base leading-relaxed text-gray-700 dark:text-gray-300">
                        Expanding organic farming to empower local communities and ensure food security through chemical-free production methods.
                    </p>
                </div>
            </section>
            <section className="px-4 pb-6">
                <div className="bg-white dark:bg-gray-900 p-5 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm">
                    <h4 className="text-xl font-bold text-emerald-impact mb-3">৳ 4,25,000 Raised</h4>
                    <div className="w-full bg-gray-100 dark:bg-gray-800 h-4 rounded-full overflow-hidden">
                        <div className="bg-emerald-impact h-full w-[85%] rounded-full"></div>
                    </div>
                </div>
            </section>
        </main>
        <div className="fixed bottom-0 left-0 right-0 z-50">
            <div className="bg-white dark:bg-gray-900 p-4 border-t border-gray-200 dark:border-gray-800 flex gap-3 max-w-md mx-auto">
                <button className="flex-1 bg-primary text-white py-4 rounded-xl font-bold">Invest Now</button>
            </div>
        </div>
    </div>
  );
};

export default InvestmentProjectDetailView;
