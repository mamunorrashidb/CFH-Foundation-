
import React from 'react';
import { View } from '../types';

interface EarningsPayoutViewProps {
  setActiveView: (view: View) => void;
}

const EarningsPayoutView: React.FC<EarningsPayoutViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-card-light dark:bg-card-dark min-h-screen">
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"></div>
        <div className="fixed bottom-0 left-0 right-0 bg-card-light dark:bg-card-dark rounded-t-[2rem] z-50 p-6 shadow-2xl max-w-md mx-auto">
            <button onClick={() => setActiveView('identity-wallet')} className="w-12 h-1.5 bg-slate-300 dark:bg-slate-600 rounded-full mx-auto mb-6 block"></button>
            <h4 className="text-xl font-extrabold text-center mb-1">Choose Method</h4>
            <p className="text-center text-slate-500 text-sm mb-6 font-bengali">টাকা উত্তোলনের মাধ্যম নির্বাচন করুন</p>
            <div className="grid grid-cols-1 gap-3">
                <button className="flex items-center justify-between p-4 rounded-xl border-2 border-slate-100 dark:border-slate-700 hover:border-primary">
                    <p className="font-bold">Bank Transfer</p>
                    <span className="material-symbols-outlined text-slate-300">chevron_right</span>
                </button>
                 <button className="flex items-center justify-between p-4 rounded-xl border-2 border-slate-100 dark:border-slate-700 hover:border-[#D82D56]">
                    <p className="font-bold">bKash</p>
                    <span className="material-symbols-outlined text-slate-300">chevron_right</span>
                </button>
                 <button className="flex items-center justify-between p-4 rounded-xl border-2 border-slate-100 dark:border-slate-700 hover:border-[#F7941D]">
                    <p className="font-bold">Nagad</p>
                    <span className="material-symbols-outlined text-slate-300">chevron_right</span>
                </button>
            </div>
        </div>
    </div>
  );
};

export default EarningsPayoutView;
