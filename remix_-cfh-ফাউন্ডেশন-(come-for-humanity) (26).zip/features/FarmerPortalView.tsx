
import React from 'react';
import { View } from '../types';

interface FarmerPortalViewProps {
  setActiveView: (view: View) => void;
}

const FarmerPortalView: React.FC<FarmerPortalViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-[#faf6f0] dark:bg-[#2d3935] text-[#101815] transition-colors duration-300 max-w-md mx-auto">
      <header className="sticky top-0 z-50 bg-[#faf6f0]/80 dark:bg-[#2d3935]/80 backdrop-blur-md border-b border-black/5 dark:border-white/5">
        <div className="flex items-center px-4 py-4 justify-between">
          <button onClick={() => setActiveView('ecommerce')} className="flex size-10 items-center justify-center">
            <span className="material-symbols-outlined text-primary">arrow_back</span>
          </button>
          <div className="flex-1 px-3">
            <h2 className="text-[#101815] dark:text-white text-lg font-extrabold leading-tight tracking-tight">CFH Market</h2>
            <p className="text-xs text-primary dark:text-primary font-bold uppercase tracking-widest">Farmer Portal</p>
          </div>
        </div>
      </header>
      <main className="pb-32">
        <div className="px-4 mb-2 pt-8">
          <button className="w-full flex items-center justify-center rounded-2xl h-14 px-5 bg-primary text-white gap-3 shadow-lg shadow-primary/20">
            <span className="material-symbols-outlined">add_circle</span><span className="text-base font-bold tracking-wide uppercase">Add New Product</span>
          </button>
        </div>
        <div className="flex items-center justify-between px-4 pt-6 pb-2">
          <h3 className="text-[#101815] dark:text-white text-xl font-bold tracking-tight">Active Inventory</h3>
        </div>
        <div className="flex flex-col gap-4 px-4">
          <div className="flex flex-col bg-white dark:bg-[#3d4a45] rounded-2xl p-4 shadow-sm border border-black/5 dark:border-white/5">
            <div className="flex gap-4">
              <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-xl size-20 shadow-sm border border-black/5" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCTbPpHAkFT8EGz0fel3SalS4BmezkuvGNLUNXcvX2ApQpgxXVUOz_ABO4Ucp_l5k-KWcpJP4iOlekXQCaFFO0YMmvIleZeH-JeRuwNvVlHnCIr_BnFWVPW7ZDu8Ec7crs8wQieDxgoZP0xcrMD2lvfkmc5OvQZ4mu6GOGJYEZZPecZFSD9wX7MZ0GOKT0a0PEbIjSV01T64D_6jHr2DIlXzCrmNnd2fXDB3OGwEfIijuI9ILXQiINNGTUr-UwncUPCJYLgxWZU7yuY')"}}></div>
              <div className="flex flex-1 flex-col justify-center min-w-0">
                <p className="text-[#101815] dark:text-white text-base font-bold leading-tight truncate">Organic Honey / অর্গানিক মধু</p>
                <button onClick={() => setActiveView('transparency-report')} className="text-left mt-2 text-primary dark:text-blue-300 text-xs font-bold uppercase hover:underline">
                  View Transparency Report
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default FarmerPortalView;
