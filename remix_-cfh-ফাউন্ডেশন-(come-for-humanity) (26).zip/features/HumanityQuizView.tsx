
import React from 'react';
import { View } from '../types';

interface HumanityQuizViewProps {
  setActiveView: (view: View) => void;
}

const HumanityQuizView: React.FC<HumanityQuizViewProps> = ({ setActiveView }) => {
  return (
    <div className="w-full max-w-[430px] min-h-screen flex flex-col relative overflow-hidden bg-background-light dark:bg-background-dark mx-auto">
      <header className="sticky top-0 z-20 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 pt-6 pb-2">
        <div className="flex items-center justify-between mb-4">
            <button onClick={() => setActiveView('gamification-hub')} className="flex items-center gap-2">
                <div className="bg-primary size-10 rounded-lg flex items-center justify-center text-white"><span className="material-symbols-outlined">volunteer_activism</span></div>
                <div><h2 className="text-lg font-extrabold leading-tight tracking-tight">CFH Quiz</h2></div>
            </button>
        </div>
      </header>
      <main className="flex-1 p-4 flex flex-col gap-6">
        <div className="w-full bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-sm border border-gray-50 dark:border-gray-700">
            <h3 className="text-xl font-extrabold leading-tight mb-4">How can you support local blood banks?</h3>
            <div className="aspect-video rounded-2xl bg-cover bg-center" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCoOPrWKBYYWVZCnnbP5Ya1XR5MGyXg8M6tvGvO4GjL5-ILJObbcnjszqxbxBRjoVpXKO5IwGnhc1wMzN6RSuP6vWj7KoHS6YVwFSY_QdCsNASRt0DOnTRbqbhDJyIMeSeell6hKI0QIQfOCuIzQd1RdQiNiFcTBOWcTxuNSwd6Alg2n-9pEQS92o79fSLEqBqWyNWzF_q_ZJBgH96w8Uz__nT4a6OjQ0RpQO28CJJIkyLMlpyS-__RAA98AqdUiHvaybb1xnsFQXDA')"}}></div>
        </div>
        <div className="flex flex-col gap-3">
            <label className="group relative flex flex-col justify-center min-h-[72px] rounded-2xl border-2 bg-white dark:bg-gray-800 px-5 py-3 cursor-pointer has-[:checked]:border-success"><input name="quiz_option" type="radio" className="hidden"/><div><p className="text-sm font-bold">Donate regularly</p></div></label>
        </div>
      </main>
    </div>
  );
};

export default HumanityQuizView;
