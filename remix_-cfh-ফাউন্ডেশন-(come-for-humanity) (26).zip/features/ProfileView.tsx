import React from 'react';
import { View } from '../types';
import { logout } from '../lib/firebase';

interface ProfileViewProps {
    setActiveView: (view: View) => void;
    user: any;
    isAdmin: boolean;
}

const ProfileView: React.FC<ProfileViewProps> = ({ setActiveView, user, isAdmin }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-[#111815] dark:text-gray-100 min-h-screen pb-32">
      <nav className="sticky top-0 z-50 flex items-center bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 justify-between border-b border-gray-100 dark:border-gray-800">
        <div className="w-10"></div>
        <h2 className="text-[#111815] dark:text-white text-lg font-extrabold leading-tight tracking-tight flex-1 text-center font-bengali">আমার প্রোফাইল</h2>
        <div className="flex w-10 items-center justify-end">
          <button onClick={() => setActiveView('notification-settings')} className="relative flex cursor-pointer items-center justify-center rounded-xl h-10 w-10 bg-transparent text-[#111815] dark:text-white">
            <span className="material-symbols-outlined">settings</span>
          </button>
        </div>
      </nav>
      <main className="max-w-md mx-auto">
        <div className="p-6">
          <div className="flex items-center gap-5">
            <div className="relative">
                {user?.photoURL ? (
                    <img src={user.photoURL} alt="Profile" className="aspect-square rounded-2xl h-20 w-20 border-2 border-primary/20 shadow-lg object-cover" />
                ) : (
                    <div className="bg-primary/10 aspect-square rounded-2xl h-20 w-20 border-2 border-primary/20 flex items-center justify-center">
                        <span className="material-symbols-outlined text-4xl text-primary">person</span>
                    </div>
                )}
              <div className="absolute -bottom-1 -right-1 size-6 bg-emerald-500 rounded-full border-2 border-white dark:border-background-dark flex items-center justify-center">
                  <span className="material-symbols-outlined text-white text-[14px]">check</span>
              </div>
            </div>
            <div className="flex flex-col">
              <p className="text-[#111815] dark:text-white text-2xl font-extrabold leading-none tracking-tight">{user?.displayName || 'ব্যবহারকারী'}</p>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="material-symbols-outlined text-secondary text-sm">stars</span>
                <p className="text-secondary text-sm font-semibold font-bengali uppercase tracking-wider">{user?.role || 'User'} Member</p>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">{user?.email}</p>
            </div>
          </div>
        </div>
        <div className="px-6 pb-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col gap-2 rounded-2xl p-5 bg-card-light dark:bg-card-dark border border-gray-100 dark:border-gray-800 shadow-sm">
              <p className="text-gray-500 dark:text-gray-400 text-xs font-bold uppercase tracking-wider font-bengali">অর্জিত পয়েন্ট</p>
              <p className="text-[#111815] dark:text-white text-3xl font-black leading-tight">{user?.points || 0}</p>
            </div>
            <div onClick={() => setActiveView('badge-collection')} className="flex flex-col gap-2 rounded-2xl p-5 bg-card-light dark:bg-card-dark border border-gray-100 dark:border-gray-800 shadow-sm cursor-pointer">
              <p className="text-gray-500 dark:text-gray-400 text-xs font-bold uppercase tracking-wider font-bengali">ইমপ্যাক্ট মেডেল</p>
              <p className="text-[#111815] dark:text-white text-3xl font-black leading-tight">৩</p>
            </div>
          </div>
        </div>
        
        <div className="px-6 space-y-3">
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">প্রশাসনিক</h3>
          <div className="space-y-2">
              {isAdmin && (
                <div onClick={() => setActiveView('admin-panel')} className="flex items-center gap-4 bg-primary/5 hover:bg-primary/10 transition-colors p-4 rounded-2xl border border-primary/20 cursor-pointer">
                    <div className="flex items-center justify-center size-10 rounded-xl bg-primary text-white shadow-md">
                        <span className="material-symbols-outlined">admin_panel_settings</span>
                    </div>
                    <div className="flex-1">
                        <p className="text-sm font-extrabold text-primary font-bengali">অ্যাডমিন কন্ট্রোল</p>
                        <p className="text-[10px] text-primary/70 font-bengali">অ্যাপ ফির্চাস ও কন্টেন্ট ম্যানেজমেন্ট</p>
                    </div>
                    <span className="material-symbols-outlined text-primary">chevron_right</span>
                </div>
              )}
              
              <div onClick={() => logout()} className="flex items-center gap-4 bg-red-50 dark:bg-red-900/10 p-4 rounded-2xl border border-red-100 dark:border-red-900/20 cursor-pointer text-red-600">
                <div className="flex items-center justify-center size-10 rounded-xl bg-red-100 dark:bg-red-900/30">
                  <span className="material-symbols-outlined">logout</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-extrabold font-bengali">লগ আউট</p>
                </div>
              </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProfileView;
