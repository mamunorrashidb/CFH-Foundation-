import React, { useState, useMemo, useEffect } from 'react';
import { View } from '../types';
import { divisions, districts, upazilas } from '../data/locations';
import { registerDonor } from '../services/apiService';

interface DonorRegistrationViewProps {
  setActiveView: (view: View, props?: any) => void;
}

const DonorRegistrationView: React.FC<DonorRegistrationViewProps> = ({ setActiveView }) => {
    const [formData, setFormData] = useState({
        fullName: '',
        phone: '',
        bloodGroup: '',
        lastDonationDate: '',
        division: '',
        district: '',
        upazila: '',
        address: '',
    });
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    useEffect(() => {
        setFormData(prev => ({ ...prev, district: '', upazila: ''}));
    }, [formData.division]);

    useEffect(() => {
        setFormData(prev => ({ ...prev, upazila: ''}));
    }, [formData.district]);

    const availableDistricts = useMemo(() => {
        return formData.division ? districts[formData.division] || [] : [];
    }, [formData.division]);

    const availableUpazilas = useMemo(() => {
        return formData.district ? upazilas[formData.district] || [] : [];
    }, [formData.district]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');
        try {
            const response = await registerDonor(formData);
            if (response.status === 'success') {
                setActiveView('donor-registration-confirmation', { 
                    name: formData.fullName, 
                    bloodGroup: formData.bloodGroup 
                });
            } else {
                setError(response.message || 'নিবন্ধনে একটি অজানা ত্রুটি ঘটেছে।');
            }
        } catch (err) {
            setError((err as Error).message || 'একটি নেটওয়ার্ক সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
        } finally {
            setIsLoading(false);
        }
    };
    
    const bloodGroups = ['', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];


  return (
    <div className="bg-background-light dark:bg-background-dark text-[#101815] dark:text-gray-100 min-h-screen max-w-md mx-auto">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center justify-between px-4 py-4">
          <button onClick={() => setActiveView('blood-bank')} className="flex items-center justify-center size-10 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
            <span className="material-symbols-outlined text-[#101815] dark:text-white">arrow_back_ios_new</span>
          </button>
          <h1 className="text-lg font-bold tracking-tight font-bengali">ডোনার রেজিস্ট্রেশন</h1>
          <div className="size-10"></div>
        </div>
      </header>
      <main className="max-w-md mx-auto pb-10">
        <div className="px-5 pt-6">
            <h2 className="text-2xl font-bold mb-1 font-bengali">জীবন বাঁচানোর এই যাত্রায় যোগ দিন</h2>
            <p className="text-gray-500 dark:text-gray-400 text-sm mb-8 font-bengali">আপনার এক ব্যাগ রক্ত পারে একজন মানুষের জীবন বাঁচাতে।</p>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-1">
                    <label className="text-sm font-semibold mb-1.5 block font-bengali">আপনার পুরো নাম</label>
                    <input className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-4 font-bengali" name="fullName" value={formData.fullName} onChange={handleInputChange} placeholder="নাম লিখুন" type="text" required/>
                </div>
                <div className="space-y-1">
                    <label className="text-sm font-semibold mb-1.5 block font-bengali">মোবাইল নম্বর</label>
                    <input className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-4" name="phone" value={formData.phone} onChange={handleInputChange} placeholder="01XXX-XXXXXX" type="tel" required/>
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                        <label className="text-sm font-semibold mb-1.5 block font-bengali">রক্তের গ্রুপ</label>
                        <select className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-3 font-bengali" name="bloodGroup" value={formData.bloodGroup} onChange={handleInputChange} required>
                            {bloodGroups.map(group => <option key={group} value={group}>{group === '' ? 'নির্বাচন করুন' : group}</option>)}
                        </select>
                    </div>
                     <div className="space-y-1">
                        <label className="text-sm font-semibold mb-1.5 block font-bengali">সর্বশেষ রক্তদান</label>
                        <input className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-3" name="lastDonationDate" value={formData.lastDonationDate} onChange={handleInputChange} type="date" />
                    </div>
                </div>

                <h3 className="text-lg font-bold pt-4 font-bengali border-t border-gray-200 dark:border-gray-700 mt-4">আপনার ঠিকানা</h3>
                
                <div className="grid grid-cols-2 gap-4">
                     <div className="space-y-1">
                        <label className="text-sm font-semibold mb-1.5 block font-bengali">বিভাগ</label>
                        <select className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-3 font-bengali" name="division" value={formData.division} onChange={handleInputChange} required>
                           {divisions.map(d => <option key={d} value={d}>{d === '' ? 'নির্বাচন করুন' : d}</option>)}
                        </select>
                    </div>
                     <div className="space-y-1">
                        <label className="text-sm font-semibold mb-1.5 block font-bengali">জেলা</label>
                        <select className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-3 font-bengali disabled:opacity-50" name="district" value={formData.district} onChange={handleInputChange} required disabled={!formData.division}>
                            <option value="">নির্বাচন করুন</option>
                            {availableDistricts.filter(d=>d).map(d => <option key={d} value={d}>{d}</option>)}
                        </select>
                    </div>
                </div>

                <div className="space-y-1">
                    <label className="text-sm font-semibold mb-1.5 block font-bengali">থানা / উপজেলা</label>
                    <select className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-3 font-bengali disabled:opacity-50" name="upazila" value={formData.upazila} onChange={handleInputChange} required disabled={!formData.district}>
                       <option value="">নির্বাচন করুন</option>
                       {availableUpazilas.filter(u=>u).map(u => <option key={u} value={u}>{u}</option>)}
                    </select>
                </div>
                
                 <div className="space-y-1">
                    <label className="text-sm font-semibold mb-1.5 block font-bengali">বিস্তারিত ঠিকানা</label>
                    <textarea className="w-full rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-4 py-3 font-bengali" name="address" value={formData.address} onChange={handleInputChange} placeholder="গ্রাম/রাস্তা, বাড়ি নং, পোস্ট অফিস" rows={2}></textarea>
                </div>

                {error && <p className="text-red-500 text-sm font-bengali text-center py-2">{error}</p>}

                <div className="pt-4">
                    <button type="submit" disabled={isLoading} className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/25 transition-all active:scale-95 font-bengali disabled:bg-primary/50 flex items-center justify-center">
                        {isLoading ? <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div> : 'ডোনার হিসাবে নিবন্ধন করুন'}
                    </button>
                </div>
            </form>
        </div>
      </main>
    </div>
  );
};

export default DonorRegistrationView;