
import React, { useState } from 'react';
import { View } from '../types';

interface DonationViewProps {
  setActiveView: (view: View) => void;
}

const DonationView: React.FC<DonationViewProps> = ({ setActiveView }) => {
  const [copySuccess, setCopySuccess] = useState('');
  const [amount, setAmount] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<'bKash' | 'Nagad' | null>(null);
  const donationNumber = '01788405091';

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopySuccess('নম্বরটি কপি করা হয়েছে!');
      setTimeout(() => setCopySuccess(''), 2000);
    }, () => {
      setCopySuccess('কপি করতে ব্যর্থ হয়েছে');
      setTimeout(() => setCopySuccess(''), 2000);
    });
  };

  const handleDonationAttempt = (method: 'bKash' | 'Nagad') => {
    if (!amount || parseFloat(amount) <= 0) {
        alert('Please enter a valid donation amount.');
        return;
    }
    setSelectedMethod(method);
    setShowConfirmation(true);
  };

  const handleConfirmDonation = () => {
    handleCopy(donationNumber);
    setShowConfirmation(false);
  };

  const presetAmounts = [100, 500, 1000, 5000];

  return (
    <div className="bg-background-light dark:bg-background-dark min-h-screen flex flex-col font-display max-w-md mx-auto">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-4 flex items-center justify-between">
        <button onClick={() => setActiveView('dashboard')} className="w-10 h-10 flex items-center justify-center rounded-full bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm border border-gray-100 dark:border-gray-700">
          <span className="material-symbols-outlined">arrow_back_ios_new</span>
        </button>
        <h2 className="text-[#111815] dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center pr-10 font-bengali">অনুদান দিন</h2>
      </header>
      <main className="flex-1 px-4 pb-8 pt-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-extrabold text-primary dark:text-white mb-2 font-bengali">মানবতার হাত বাড়িয়ে দিন</h1>
          <p className="text-gray-600 dark:text-gray-400 max-w-xs mx-auto font-bengali leading-relaxed">আপনার সামান্য অনুদানও একটি জীবন বাঁচাতে পারে বা একটি পরিবারের মুখে হাসি ফোটাতে পারে।</p>
        </div>
        
        <div className="bg-white dark:bg-card-dark rounded-2xl p-6 border border-gray-100 dark:border-gray-800 shadow-sm space-y-6">
          
          <div>
            <h3 className="text-base font-bold text-gray-800 dark:text-white mb-3 font-bengali">অনুদান পরিমাণ</h3>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold text-lg font-bengali">৳</span>
              <input 
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="পরিমাণ লিখুন"
                className="w-full h-14 pl-10 pr-4 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-primary/50 focus:border-primary text-lg font-bold font-bengali"
              />
            </div>
            <div className="grid grid-cols-4 gap-2 mt-3">
              {presetAmounts.map(preset => (
                <button key={preset} onClick={() => setAmount(String(preset))} className={`py-2 rounded-lg text-sm font-bold font-bengali transition-colors ${Number(amount) === preset ? 'bg-primary/20 text-primary' : 'bg-gray-100 dark:bg-gray-700 text-primary dark:text-primary/80'}`}>৳{preset}</button>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-base font-bold text-gray-800 dark:text-white mb-3 font-bengali">মোবাইল ব্যাংকিং (পার্সোনাল)</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 font-bengali">অনুগ্রহ করে নিচের ব্যক্তিগত নম্বরে 'সেন্ড মানি' করুন।</p>
          </div>

          <div className="space-y-4">
            {/* bKash Button */}
            <div className="bg-[#e2136e]/5 dark:bg-[#e2136e]/10 p-4 rounded-xl border-2 border-[#e2136e]/20">
              <div className="flex items-center justify-between">
                <img src="https://logowik.com/content/uploads/images/bkash-new-logo-20232185.logowik.com.webp" alt="bKash Logo" className="h-8"/>
                <button onClick={() => handleDonationAttempt('bKash')} className="px-4 py-2 rounded-lg bg-[#e2136e] text-white font-bold text-sm font-bengali active:scale-95 transition-transform">
                  দান করুন
                </button>
              </div>
            </div>

            {/* Nagad Button */}
            <div className="bg-[#F58220]/5 dark:bg-[#F58220]/10 p-4 rounded-xl border-2 border-[#F58220]/20">
              <div className="flex items-center justify-between">
                 <img src="https://media.licdn.com/dms/image/D560BAQHY-pS22w2vaw/company-logo_200_200/0/1693836746887/nagad_logo?e=2147483647&v=beta&t=HjWk-2JsA-ZJ8s_w-VfVf-Kx2sW7p-3Yw1-U2i-xN4s" alt="Nagad Logo" className="h-8 rounded"/>
                <button onClick={() => handleDonationAttempt('Nagad')} className="px-4 py-2 rounded-lg bg-[#F58220] text-white font-bold text-sm font-bengali active:scale-95 transition-transform">
                  দান করুন
                </button>
              </div>
            </div>
          </div>

          {copySuccess && (
            <div className="text-center text-sm font-bold text-green-500 mt-4 animate-fade-in font-bengali">{copySuccess}</div>
          )}
        </div>
        
        <div className="mt-8 text-center text-xs text-gray-500 font-bengali p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
            টাকা পাঠানোর পর অনুগ্রহ করে <a href="#" onClick={(e) => { e.preventDefault(); setActiveView('support-center'); }} className="font-bold text-primary underline">আমাদের জানান</a> যাতে আমরা আপনার অনুদান নিশ্চিত করতে পারি এবং আপনাকে একটি রসিদ পাঠাতে পারি।
        </div>
      </main>

      {showConfirmation && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white dark:bg-card-dark rounded-2xl shadow-xl w-full max-w-sm p-6 text-center">
                <h2 className="font-bold text-lg font-bengali mb-2">অনুদান নিশ্চিত করুন</h2>
                <p className="text-gray-600 dark:text-gray-400 font-bengali mb-6">
                    আপনি <span className="font-bold text-primary">৳{amount}</span> <span className="font-bold">{selectedMethod}</span> এর মাধ্যমে অনুদান করতে যাচ্ছেন। <br/> পরবর্তী ধাপে নম্বরটি কপি করতে 'নিশ্চিত করুন' বাটনে ক্লিক করুন।
                </p>
                <div className="space-y-3">
                    <button onClick={handleConfirmDonation} className="w-full bg-primary text-white font-bold py-3 rounded-lg font-bengali">
                        নিশ্চিত করুন
                    </button>
                    <button onClick={() => setShowConfirmation(false)} className="w-full bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 font-bold py-3 rounded-lg font-bengali">
                        বাতিল
                    </button>
                </div>
            </div>
        </div>
      )}

    </div>
  );
};

export default DonationView;
