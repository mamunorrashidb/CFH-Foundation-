
import React from 'react';
import { View } from '../types';

interface EnrollmentConfirmationViewProps {
  setActiveView: (view: View, props?: any) => void;
  studentName?: string;
  courseName?: string;
  fee?: string;
}

const EnrollmentConfirmationView: React.FC<EnrollmentConfirmationViewProps> = ({ setActiveView, studentName = "শিক্ষার্থী", courseName = "কোর্স", fee = "500" }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-gray-800 dark:text-white min-h-screen flex flex-col items-center justify-center p-4">
      <main className="max-w-md w-full text-center">
        <div className="mb-6">
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
            <span className="material-symbols-outlined text-primary text-6xl">school</span>
          </div>
        </div>
        
        <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white mb-2 font-bengali">ভর্তি সম্পন্ন হয়েছে!</h1>
        <p className="text-gray-600 dark:text-gray-400 max-w-xs mx-auto font-bengali leading-relaxed">আপনি সফলভাবে "{courseName}" কোর্সে ভর্তি হয়েছেন। আপনার শেখার যাত্রা শুরু করুন।</p>

        <div className="bg-white dark:bg-card-dark rounded-2xl p-6 border border-gray-100 dark:border-gray-800 shadow-sm mt-8 text-left space-y-4">
            <h2 className="text-lg font-bold font-bengali mb-3">ভর্তির বিবরণ</h2>
            <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600 dark:text-gray-400 font-bengali">শিক্ষার্থীর নাম</span>
                <span className="font-bold font-bengali">{studentName}</span>
            </div>
            <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600 dark:text-gray-400 font-bengali">কোর্সের নাম</span>
                <span className="font-bold font-bengali">{courseName}</span>
            </div>
             <div className="border-t border-gray-100 dark:border-gray-700 pt-4 mt-4 flex justify-between items-center font-bold">
                <span className="font-bengali">ভর্তি ফিস</span>
                <span className="text-primary text-lg font-bengali">৳{fee}</span>
            </div>
             <div className="text-center bg-success/5 dark:bg-success/10 text-success dark:text-success/90 text-xs font-bold p-3 rounded-lg mt-4 font-bengali">
                পেমেন্ট সফল হয়েছে
            </div>
        </div>
        
        <div className="mt-8 space-y-3">
            <button onClick={() => setActiveView('shopno-gori-reader', { studentName, courseName })} className="w-full bg-primary text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/20 active:scale-95 transition-transform font-bengali">
                কোর্স শুরু করুন
            </button>
             <button onClick={() => setActiveView('ecommerce')} className="w-full text-primary font-bold py-3 rounded-xl hover:bg-primary/5 transition-colors font-bengali">
                স্বপ্নগড়ি হাবে ফিরে যান
            </button>
        </div>
      </main>
    </div>
  );
};

export default EnrollmentConfirmationView;
