
import React from 'react';
import { View } from '../types';

interface CommitteeDirectoryViewProps {
  setActiveView: (view: View) => void;
}

const centralExecutiveCommittee = [
  { name: 'Dr. Abdullah Al Mamun', bengaliName: 'ডঃ আবদুল্লাহ আল মামুন', title: 'Chairman', bengaliTitle: 'চেয়ারম্যান', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDYp-HSn3tRUH5YkoL4bImaEJjDA8S2p8f_YZRpj0Vu4VJlPwkzGcmNQs7gsc0v48JkzmjGWjccSXIQeTIwlMUkp2FbSjK25XQ4pDRn1Dc2CvNGT33KTqSxRzPiJRb2D_wl0ABfjRO0rP8IrdYAC4zwUoH1qenoJgHrIvhgJp_DJ7mTEDY4Hl_lRIxAyHv-A12Qc4WI8EXM3HnbhVZekVd-_bH51Ca95tc9lGND7qSwBMywquQLgYoXQIuhnGLWL2dR22nvWVEiumb0', verified: true, color: 'secondary' },
  { name: 'Sarah Islam', bengaliName: 'সারা ইসলাম', title: 'General Secretary', bengaliTitle: 'সাধারণ সম্পাদক', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCAR2UI-qMg4srf_slyLBZBrIEUSpLXVt2oWtvexnVcMT-mKWCwa0CDOUgzy1weHi6Ij7CKSbnRG53K-uQvBi90PeNQKIOJBHZ2AzD1gUbVXvbV-ZGgQfJdygXybiGdr96GFedGkCw0GAQVqen3G51Pc1BY2er4VL746ZRIor3HNLJD6BXtmI4yt0lW8Mj_NcrkiGUa385C1mVcX-nEdYkilAgCy7WbveiqHEyQwha-D1zeBFiyV46x3SzTr6y7qbiYPgbgdfIub7FW', verified: true, color: 'primary' },
  { name: 'Kamal Uddin', bengaliName: 'কামাল উদ্দিন', title: 'Treasurer', bengaliTitle: 'কোষাধ্যক্ষ', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuADMn5fcIQf4oN57XXNS1OPYrE9NFg5tQrLptmfLEDU6LzECN0w2XkLTmzjNi50DICfg94hrx1a8IocVfQkLYqzp6KORb45p41ai0bsKgnvB05oe5amGULvn8_YUmW4qXLu8NU1c6AVfa04bbRUR7kxGj4Xq9J9pCdRt5yPKDbu6R0eZcmajQUuotRPoThKSU8TgP2NfeLA3rK52Eq9CO1ihwO0M10DjPAc2MEYG8_hIJXagA5eflyuMVyT5P_5Odz9e1to3Kn4DL-x', verified: true, color: 'primary/40' },
  { name: 'Ahmed Rafiq', bengaliName: 'আহমেদ রফিক', title: 'Vice Chairman', bengaliTitle: 'ভাইস চেয়ারম্যান', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAv0RWGxN6TP3AG3KNtAJtFPsQPhamwMxq_1MhKaN0ZMMFh7s7eXPByKCydPHkpl7EbTbNwUDHfsfT6Zjr_3zN4Km3c6RkcBRxPPaPEtM7D5tiJdWvpJltUMrYoMLcyHHuq8eIs4p_MTzCxf-uxHIR-cLMmNViayOY7ePpC5YFx8Ve2Tww8avfshw4rZ5zNySmOVnV-ZYgvRC4njqmpty50J5ynBjHSDebQ1fEvzflGraKyycq_zpzB1GMwdktPm6LzH3VpZS_xbKsM', verified: false, color: 'primary/40' }
];

const advisoryCouncil = [
  { name: 'Prof. Dr. Anisuzzaman', bengaliName: 'অধ্যাপক ডঃ আনিসুজ্জামান', title: 'Chief Advisor', bengaliTitle: 'প্রধান উপদেষ্টা', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBwiS1yPC8-vFpGibwasePSNAFDpZUOCpojrTilTJpLwbH1WhMWVbjQp0CpyilUGnlxZcBp_r1Eb_npINPaq--fYJHcAKSrTI2t6MT0q_MZOAB69OE7RBP1YSJCTzfndvne0vUL5vCaLJJRO3EnRixe5Cm3t09mD6SiX8R30en19t5Yz14-vAvYHYLZRiKPitHQL-p9EffKQETrzFSzd8Lisq029aM669_8h0h1CTQQpbAGotpXfwmz3gosSYCducqQVfnRKxlO4L4o', verified: true, color: 'secondary' },
  { name: 'Advocate Sultana Kamal', bengaliName: 'অ্যাডভোকেট সুলতানা কামাল', title: 'Legal Advisor', bengaliTitle: 'আইন উপদেষ্টা', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDlySCrntmlbNmSA2H1BOqI1VcqUDrs9RN8GaM_n3zWSPrvTXeCDBCsrDcS-p2t-ynTuL6LXRJKLbk6vw_sLt2XNaHpcGHQPSFT4J9VMp7OjFAZRkOBRhaGuTLGPNpX4luQq67yUKhhD5ghG4K01MLsxApXvXQYPnuFh8ia2uv6XdPp0Fmd3yhunHogXLK4mXZvOkwn6aZcroH7hlBpAiSn2J4liQHhgOi56snj_Z7ZOxlrIT5gUKUcIgDrYyurPZpzGTQcHnRK_2Sz', verified: true, color: 'primary' },
];

const councilOfSeniorMembers = [
  { name: 'Mr. Abdul Halim', bengaliName: 'জনাব আব্দুল হালিম', title: 'Senior Member', bengaliTitle: 'সিনিয়র সদস্য', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD2POIfzuFVS6yWNGDocN6VR2OrpuIivLhuh20-oAxJHKxrjagLuw49M1fSAm19ZW6dPNc92vd3Exj0yZUa_eAEzMr6SB0EWv2yhPhNC-gHEREjr0YNfm14eEg-GnqORJVREhy4ozxyNFXOA8IIA4zIa920aqWfwRhm1ltDDmBnx3nk83zQntaY2JPPjid0DLbYxfUKyldDs2CgeWj9bv_BYnPp2K__ImHz3eqGEwXPBq2LAMDXCkJQBc_IzI432ajQZ8Q0xnQp4YyI', verified: false, color: 'primary/40' },
  { name: 'Mrs. Rokeya Begum', bengaliName: 'বেগম রোকেয়া', title: 'Senior Member', bengaliTitle: 'সিনিয়র সদস্য', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBqFqsEHfbF_A9SGKW_QLh6SC7aRjL5TU8k6E7LcVjJwyrP4LuJqeQbWGqEOiYOkW7t6TgLdlf-xo65Q1VUHdhnaxNHnH5qytwrYlwXlOz7YNEW8wFRsghpAAXs2BvJOw-5mbBEzjtACRJJdTcaNh7jR3EN4o7Ibf_DqL3QlxiSiNlG5ZBPRbwzscPkTVmOTWWa3AYjO3JsSnxC78-3-SIUcye2XXwbn9r-yTd2X5Z8Ut8ik_rT35aAdJt6F_fbtyEBvIU0lB9eroF', verified: true, color: 'primary' },
];

const districtMetropolitanCommittee = [
   { name: 'Tanvir Rahman', bengaliName: 'তানভীর রহমান', title: 'President (Dhaka)', bengaliTitle: 'সভাপতি (ঢাকা)', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAocvUAerNhcSQ6uQf2RJ5e46CC13_UfnzpF1EAMT_YwWJIA_gBrozR3OpmVtwgbxg2s7RNFV-Ct7P6pwS9RcujThZ_dh_V25TsmHuf78JLLND_-3weHUAdgerFe3C4ffKY8MaQOyVEXXTtTJnyZkNn9Keh9tPmonn9UtsnXR6X5DlLU-5GUIGcwzR3bEv_WEhzDXWhmNgyIjs28PtshY7g9kyL9jx_oGfLKj4DVft4p5ZMDJLCQe5DSyeAAtbZ6C87onOJuDxPF8p4', verified: true, color: 'primary' },
   { name: 'Asif Ahmed', bengaliName: 'আসিফ আহমেদ', title: 'General Secretary (Dhaka)', bengaliTitle: 'সাধারণ সম্পাদক (ঢাকা)', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDtVs6f9OW0L6Y2A_Pt5Bpk_W82GHHDq9yY_rAe41tRCaQT77w0teSkv2G01a_GwadK7S-NziiV0V-oSp4KVVA_k8R9_6WwLSc7jP-_RELOinrk0Ye8n_g_XIyToaDiPNsYrbKyzxvJVvHU_p0w-_oURAqn2Rf5h_UnfWTCNnhhBqua5pEe8tf1p4wEUmcB9D4OlkHYwdMk3ytjs4sfHjKSmLRihiKWgHvgGaHGtw9hJkTQL6O3tcuLNTEe1_z5LQ7UNzdn5HjTCtst', verified: true, color: 'primary/40' },
];

const committees = [
    { title: 'Central Executive Committee', bengaliTitle: 'কেন্দ্রীয় কার্যনির্বাহী পরিষদ', members: centralExecutiveCommittee },
    { title: 'Advisory Council', bengaliTitle: 'উপদেষ্টা পরিষদ', members: advisoryCouncil },
    { title: 'Council of Senior Members', bengaliTitle: 'কাউন্সিল অফ সিনিয়র মেম্বার পরিষদ', members: councilOfSeniorMembers },
    { title: 'District/Metropolitan Committee', bengaliTitle: 'জেলা/মহানগর কমিটি', members: districtMetropolitanCommittee },
];


const MemberCard: React.FC<{ member: typeof centralExecutiveCommittee[0] }> = ({ member }) => {
    const barColor = member.color === 'secondary' ? 'bg-secondary' : member.color === 'primary' ? 'bg-primary' : 'bg-primary/40';
    return (
        <div className="flex flex-col bg-card-light dark:bg-slate-800/50 rounded-xl p-4 ios-shadow border border-gray-100 dark:border-white/5 relative overflow-hidden">
            <div className={`absolute top-0 right-0 w-1.5 h-full ${barColor}`}></div>
            <div className="flex items-center gap-4">
                <div className="relative">
                    <div className="size-20 rounded-xl bg-center bg-no-repeat bg-cover border-2 border-white dark:border-slate-700 shadow-sm" style={{ backgroundImage: `url("${member.imageUrl}")` }}></div>
                    {member.verified && (
                        <div className="absolute -bottom-1 -right-1 size-5 bg-secondary border-2 border-white dark:border-slate-800 rounded-full flex items-center justify-center">
                            <span className="material-symbols-outlined text-[12px] text-white font-bold">check</span>
                        </div>
                    )}
                </div>
                <div className="flex-1">
                    <h3 className="text-text-main dark:text-white text-base font-bold leading-tight">{member.name}</h3>
                    <p className="text-sm font-medium leading-tight font-bengali">{member.bengaliName}</p>
                    <p className="text-xs text-gray-500 mt-1 font-bengali">{member.bengaliTitle}</p>
                </div>
            </div>
        </div>
    );
};

const CommitteeDirectoryView: React.FC<{ setActiveView: (view: View) => void }> = ({ setActiveView }) => {
    return (
        <div className="relative flex min-h-screen w-full flex-col max-w-[430px] mx-auto bg-white dark:bg-background-dark overflow-x-hidden pb-24">
            <header className="sticky top-0 z-50 bg-primary px-4 py-3 flex items-center justify-between shadow-md">
                <button onClick={() => setActiveView('hall-of-fame')} className="flex items-center justify-center size-10 text-white rounded-full hover:bg-white/10 active:scale-95 transition-all">
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>
                <div className="flex flex-col items-center">
                    <h1 className="text-white text-lg font-bold">Leadership</h1>
                    <span className="text-white/80 text-[10px] uppercase tracking-widest font-medium font-bengali">নেতৃত্ব</span>
                </div>
                <div className="w-10"></div>
            </header>
            
            <main className="flex flex-col gap-10 px-5 pt-8">
                {committees.map((committee) => (
                    <section key={committee.title}>
                        <div className="pb-4">
                            <h2 className="text-[#131117] dark:text-white text-xl font-extrabold leading-tight">
                                {committee.title}
                            </h2>
                            <p className="text-gray-500 dark:text-gray-400 text-sm mt-1 font-bengali">{committee.bengaliTitle}</p>
                        </div>
                        <div className="flex flex-col gap-4">
                            {committee.members.map(member => <MemberCard key={member.name} member={member} />)}
                        </div>
                    </section>
                ))}
            </main>
            
            <style>{`
                .ios-shadow { box-shadow: 0 8px 30px rgba(36, 40, 47, 0.08); }
            `}</style>
        </div>
    );
};

export default CommitteeDirectoryView;
