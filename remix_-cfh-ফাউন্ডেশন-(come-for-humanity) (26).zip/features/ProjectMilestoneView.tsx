
import React from 'react';
import { View } from '../types';

interface ProjectMilestoneViewProps {
  setActiveView: (view: View) => void;
}

const ProjectMilestoneView: React.FC<ProjectMilestoneViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex h-auto min-h-screen w-full max-w-[430px] mx-auto flex-col bg-white dark:bg-[#0a0d14] overflow-x-hidden shadow-2xl">
      <header className="flex items-center bg-white dark:bg-[#0a0d14] p-4 pb-2 justify-between sticky top-0 z-50">
        <button onClick={() => setActiveView('project-funding-tracker')} className="text-[#111318] dark:text-white flex size-12 shrink-0 items-center justify-start">
          <span className="material-symbols-outlined cursor-pointer">close</span>
        </button>
      </header>
      <div className="relative">
        <div className="bg-cover bg-center flex flex-col justify-end overflow-hidden bg-white min-h-80 relative" style={{backgroundImage: 'linear-gradient(0deg, rgba(48, 110, 232, 0.6) 0%, rgba(0, 0, 0, 0) 50%), url("https://lh3.googleusercontent.com/aida-public/AB6AXuBGEaNq1lmhN1yxLJZaXS_b9MUv6DCzmAOv1OFdmnW7k3U1VrWIJKNeZwkLl1AziAernIloZ_i0X1l7ZWUEKlKw-jMiFnLIxFVa-BYIAey25Q0fDRB6Mbr2GIkNFuxe7AqGOBlSAiDVLKNPF4fnODVmuUfFYFCsxbDTQlkeAi0Uz48XXFRSRxbfn1-oliKZDmIH2Kpcov0wOreDhhjsDjlm0_oHguqlKzY9QuL_HNcT-Y2re_mC178EGp_F33rqE1KnYwiYSMRcdK7T")'}}>
          <div className="flex p-6 flex-col gap-1">
            <span className="bg-emerald-success text-white text-[10px] font-bold uppercase tracking-widest py-1 px-3 rounded-full w-fit mb-2">Success reached</span>
            <p className="text-white tracking-tight text-[32px] font-extrabold leading-tight font-display">New Blood Center Opened!</p>
          </div>
        </div>
      </div>
      <div className="px-6 py-4">
        <h2 className="text-[#111318] dark:text-white tracking-tight text-2xl font-extrabold leading-tight text-left font-display">Your contribution helped make this happen!</h2>
      </div>
      <div className="mt-auto p-6 bg-white dark:bg-[#0a0d14] border-t border-gray-100 dark:border-gray-800">
        <button className="w-full bg-primary text-white font-bold py-4 rounded-xl flex items-center justify-center gap-3">
          <span className="material-symbols-outlined">share</span>
          <span>Share this Achievement</span>
        </button>
      </div>
    </div>
  );
};

export default ProjectMilestoneView;
