
import React from 'react';
import { View } from '../types';

interface ImpactRewardViewProps {
  setActiveView: (view: View) => void;
}

const ImpactRewardView: React.FC<ImpactRewardViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex h-screen w-full flex-col overflow-x-hidden bg-background-light dark:bg-background-dark radial-bg">
      <header className="flex items-center bg-transparent p-4 pb-2 justify-between z-10">
        <button onClick={() => setActiveView('dashboard')} className="text-[#121714] dark:text-white flex size-12 shrink-0 items-center justify-center cursor-pointer">
          <span className="material-symbols-outlined">close</span>
        </button>
        <h2 className="text-[#121714] dark:text-white text-lg font-bold leading-tight flex-1 text-center pr-12">Monthly Impact Reward</h2>
      </header>
      <div className="flex-1 flex flex-col items-center justify-center px-6 relative overflow-hidden">
        <div className="relative w-64 h-64 flex items-center justify-center mb-8">
            <div className="absolute inset-0 rounded-full badge-glow animate-pulse"></div>
            <div className="relative z-10 w-56 h-56 rounded-full bg-gradient-to-br from-primary via-primary to-[#1e7a4d] border-8 border-luminous-gold flex flex-col items-center justify-center shadow-2xl">
                <div className="text-white mb-2"><span className="material-symbols-outlined !text-[80px]" style={{fontVariationSettings: "'FILL' 1"}}>lightbulb</span></div>
            </div>
        </div>
        <div className="text-center z-10">
          <h1 className="text-[#121714] dark:text-white tracking-tight text-[32px] font-extrabold leading-tight px-4 pb-2">
            Achievement Unlocked: <span className="text-primary block">Humanitarian of the Month!</span>
          </h1>
        </div>
      </div>
      <footer className="mt-auto pb-8 z-10">
        <div className="flex flex-1 gap-3 max-w-[480px] flex-col items-stretch px-6">
            <button onClick={() => setActiveView('dashboard')} className="flex min-w-[84px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-14 px-5 bg-primary text-white text-base font-bold leading-normal w-full shadow-lg">
                <span className="truncate">Share Success</span>
            </button>
        </div>
      </footer>
       <style>{`
        .radial-bg { background: radial-gradient(circle at center, rgba(41, 163, 102, 0.08) 0%, rgba(255, 255, 255, 1) 70%); }
        .dark .radial-bg { background: radial-gradient(circle at center, rgba(41, 163, 102, 0.15) 0%, rgba(28, 30, 34, 1) 70%); }
        .badge-glow { box-shadow: 0 0 40px rgba(41, 163, 102, 0.4), 0 0 80px rgba(235, 194, 61, 0.2); }
      `}</style>
    </div>
  );
};

export default ImpactRewardView;
