
import React from 'react';
import { View } from '../types';

interface DeveloperPortalViewProps {
  setActiveView: (view: View) => void;
}

const DeveloperPortalView: React.FC<DeveloperPortalViewProps> = ({ setActiveView }) => {
    return (
        <div className="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 antialiased overflow-x-hidden max-w-md mx-auto">
            <nav className="sticky top-0 z-50 flex items-center justify-between px-4 py-3 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-slate-200 dark:border-white/10">
                <div className="flex items-center gap-3">
                    <button onClick={() => setActiveView('dashboard')} className="p-2 hover:bg-slate-100 dark:hover:bg-white/5 rounded-lg transition-colors">
                        <span className="material-symbols-outlined text-primary">arrow_back</span>
                    </button>
                    <div className="flex flex-col">
                        <span className="text-xs font-bold text-primary tracking-widest uppercase">CFH Super App</span>
                        <h1 className="text-lg font-bold leading-none">API Reference</h1>
                    </div>
                </div>
                 <button onClick={() => setActiveView('raw-nest-system-status')} className="p-2 hover:bg-slate-100 dark:hover:bg-white/5 rounded-lg transition-colors">
                    <span className="material-symbols-outlined text-primary">monitor_heart</span>
                </button>
            </nav>
            <main className="flex flex-col min-h-screen">
                <section className="px-4 pb-24 pt-8">
                    <div className="flex items-center gap-3 mb-2">
                        <span className="px-2 py-1 rounded bg-primary text-white text-[10px] font-bold tracking-tighter">POST</span>
                        <code className="text-sm font-mono text-primary font-bold">/v1/auth/login</code>
                    </div>
                    <h2 className="text-2xl font-bold mb-3">User Authentication</h2>
                    <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed mb-6">
                        Exchange user credentials for a session token.
                    </p>
                    <div className="rounded-xl overflow-hidden bg-[#0d0e10] border border-white/10">
                         <div className="p-4 overflow-x-auto font-mono text-xs leading-relaxed">
                            <pre className="text-emerald"><span className="text-primary">const</span> res = <span className="text-primary">await</span> axios.post(<span className="text-amber-200">'/v1/auth/login'</span>, {'{...}'});</pre>
                        </div>
                    </div>
                </section>
            </main>
        </div>
    );
};

export default DeveloperPortalView;
