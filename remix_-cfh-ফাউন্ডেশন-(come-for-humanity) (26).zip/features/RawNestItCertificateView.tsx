
import React from 'react';
import { View } from '../types';

interface RawNestItCertificateViewProps {
  setActiveView: (view: View) => void;
}

const RawNestItCertificateView: React.FC<RawNestItCertificateViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between p-4 h-16 max-w-md mx-auto">
          <div className="flex items-center gap-2">
            <button onClick={() => setActiveView('course-detail')} className="material-symbols-outlined text-primary cursor-pointer">arrow_back</button>
            <span className="font-bold text-sm tracking-tight">VERIFIED CREDENTIAL</span>
          </div>
        </div>
      </header>
      <main className="flex-1 w-full max-w-md mx-auto p-4 pb-24">
        <div className="relative bg-white dark:bg-slate-900 shadow-2xl rounded-xl overflow-hidden border-8 border-primary">
          <div className="relative p-6 flex flex-col items-center text-center">
            <h1 className="text-primary dark:text-white text-2xl font-bold leading-none tracking-tight mb-1">
                Professional IT Certification
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium mb-6">পেশাদার আইটি সার্টিফিকেশন</p>
            <h2 className="text-2xl font-bold text-primary dark:text-accent border-b-2 border-primary/10 pb-2 inline-block px-4 mb-8">
                Abdullah Al Mamun
            </h2>
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">
                Advanced Cyber Security & Safe Internet
            </h3>
          </div>
        </div>
      </main>
      <nav className="fixed bottom-0 left-0 right-0 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800 pb-8 pt-2">
        <div className="max-w-md mx-auto flex justify-around items-center px-4">
          <button className="flex flex-col items-center gap-1 group">
            <div className="p-2 rounded-xl bg-primary text-white shadow-lg shadow-primary/20">
              <span className="material-symbols-outlined text-[20px]">file_download</span>
            </div>
          </button>
        </div>
      </nav>
    </div>
  );
};

export default RawNestItCertificateView;
