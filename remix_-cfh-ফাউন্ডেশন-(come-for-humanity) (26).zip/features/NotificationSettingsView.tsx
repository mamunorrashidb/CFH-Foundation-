
import React from 'react';
import { View } from '../types';

interface NotificationSettingsViewProps {
  setActiveView: (view: View) => void;
}

const NotificationSettingsView: React.FC<NotificationSettingsViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex h-full min-h-screen w-full flex-col max-w-[430px] mx-auto bg-white dark:bg-background-dark shadow-2xl">
      <header className="sticky top-0 z-50 flex items-center bg-white/80 dark:bg-background-dark/80 backdrop-blur-md p-4 pb-2 justify-between border-b border-gray-100 dark:border-gray-800">
        <button onClick={() => setActiveView('profile')} className="text-primary flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer">
          <span className="material-symbols-outlined">arrow_back_ios_new</span>
        </button>
        <h2 className="text-primary text-lg font-bold leading-tight tracking-tight flex-1 text-center pr-10">Notification Preferences</h2>
      </header>
      <main className="flex-1 pb-24 overflow-y-auto">
        <div className="px-4 pt-6 pb-2">
            <h3 className="text-xs font-extrabold uppercase tracking-widest opacity-60">Priority Alerts</h3>
        </div>
        <div className="px-4 mb-6">
            <div className="flex items-center gap-4 bg-white dark:bg-gray-900 border-2 border-emergency/20 rounded-xl p-4 shadow-sm">
                <div className="text-emergency flex items-center justify-center rounded-lg bg-emergency/10 shrink-0 size-12"><span className="material-symbols-outlined text-[28px]">bloodtype</span></div>
                <p className="text-base font-bold leading-normal flex-1">Emergency Blood Requests</p>
                <div className="shrink-0">
                    <label className="relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full bg-gray-200 dark:bg-gray-700 p-0.5">
                        <input defaultChecked className="ios-toggle invisible absolute" type="checkbox"/>
                        <div className="ios-slider h-full w-[27px] rounded-full bg-white shadow-md transition-transform duration-200 ease-in-out"></div>
                    </label>
                </div>
            </div>
        </div>
        <style>{`.ios-toggle:checked + .ios-slider { background-color: #26B265 !important; } .ios-toggle:checked + .ios-slider div { transform: translateX(20px); }`}</style>
      </main>
    </div>
  );
};

export default NotificationSettingsView;
