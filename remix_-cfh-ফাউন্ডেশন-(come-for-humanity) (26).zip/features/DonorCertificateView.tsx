
import React, { useState, useRef, useEffect } from 'react';
import { View } from '../types';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import QRCode from 'qrcode';

interface DonorCertificateViewProps {
  setActiveView: (view: View) => void;
}

const Certificate: React.FC<{ name: string; qrDataURL: string }> = ({ name, qrDataURL }) => (
    <div className="relative w-full aspect-[1.414/1] bg-white shadow-2xl border-[1px] border-gray-100 flex flex-col p-2 overflow-hidden font-serif">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.03] pointer-events-none z-0 w-[60%]">
        <div className="w-full aspect-square border-[30px] border-primary rounded-full flex items-center justify-center">
          <span className="text-[120px] font-bold text-primary">CFH</span>
        </div>
      </div>
      <div className="flex-1 border-[10px] border-transparent p-6 sm:p-10 relative z-10 flex flex-col" style={{ borderImage: 'linear-gradient(to bottom right, #D4AF37, #4169e1) 1' }}>
        <div className="flex items-start justify-between mb-8">
            <div className="flex items-center gap-3">
                 <div className="size-12 bg-primary flex items-center justify-center text-white font-sans font-bold text-xl">CFH</div>
                 <div>
                    <h1 className="text-primary text-sm font-bold tracking-widest uppercase font-sans">Come For Humanity</h1>
                    <p className="text-gold text-[10px] font-bold tracking-widest uppercase font-sans">The Light of Humanity</p>
                 </div>
            </div>
            {qrDataURL && <img src={qrDataURL} alt="Verification QR Code" className="size-16" />}
        </div>
        <div className="flex-1 flex flex-col items-center text-center">
          <p className="text-gold text-base font-medium tracking-wider mb-2 font-sans">Certificate of Appreciation</p>
          <p className="text-gray-500 text-sm font-medium mb-6 font-sans">This certificate is proudly presented to</p>
          <h2 className="text-primary text-4xl font-bold border-b-2 border-gold/50 pb-3 mb-6 min-w-[300px] font-bengali">
            {name || 'প্রাপকের নাম'}
          </h2>
          <p className="text-gray-700 text-sm leading-relaxed max-w-sm font-sans">
            In grateful recognition of your invaluable contribution and unwavering support towards our humanitarian missions. Your generosity brings light and hope to countless lives.
          </p>
        </div>
        <div className="mt-auto pt-8 flex justify-between items-end">
            <div className="text-left">
                <p className="text-[10px] text-gray-400 font-sans">Date Issued</p>
                <p className="text-xs font-semibold font-sans">{new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </div>
            <div className="text-center">
                 <img src="https://i.ibb.co/7jW7kF5/signature-placeholder.png" alt="Signature" className="h-10 mx-auto" />
                <p className="text-xs font-bold border-t border-gray-300 pt-1 mt-1 font-sans">Founder's Signature</p>
            </div>
            <div className="text-right">
                <p className="text-[10px] text-gray-400 font-sans">Certificate ID</p>
                <p className="text-xs font-semibold font-sans">CFH-DON-{Date.now().toString().slice(-6)}</p>
            </div>
        </div>
      </div>
    </div>
);

const DonorCertificateView: React.FC<DonorCertificateViewProps> = ({ setActiveView }) => {
  const [name, setName] = useState('আলেক্স চৌধুরী');
  const [certificateImage, setCertificateImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [qrDataURL, setQrDataURL] = useState('');
  const certificateRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
      const uniqueId = `CFH-DON-CERT-${Date.now()}`;
      QRCode.toDataURL(`https://cfh.org.bd/verify?cert=${uniqueId}`, { width: 128, margin: 1 })
          .then(url => setQrDataURL(url))
          .catch(err => console.error(err));
  }, []);


  const handleGenerate = async () => {
    if (certificateRef.current) {
      setIsLoading(true);
      setCertificateImage(null);
      await new Promise(resolve => setTimeout(resolve, 100)); // allow DOM to update
      try {
        const canvas = await html2canvas(certificateRef.current, { 
            scale: 2, 
            backgroundColor: null,
            useCORS: true,
        });
        setCertificateImage(canvas.toDataURL('image/png'));
      } catch (error) {
        console.error("Failed to generate certificate image:", error);
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleDownload = async () => {
    if (certificateRef.current) {
        const canvas = await html2canvas(certificateRef.current, { scale: 3, useCORS: true });
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({
            orientation: 'landscape',
            unit: 'px',
            format: [canvas.width, canvas.height]
        });
        pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
        pdf.save(`CFH_Donor_Certificate_${name.replace(/ /g, '_')}.pdf`);
    }
  };

  return (
    <div className="relative flex min-h-screen w-full flex-col bg-background-light dark:bg-background-dark pb-12 font-sans">
      <header className="flex items-center bg-white dark:bg-background-dark p-4 justify-between sticky top-0 z-20 border-b border-gray-100 dark:border-gray-800">
        <button onClick={() => setActiveView('impact-tracker')} className="flex size-12 shrink-0 items-center justify-center">
          <span className="material-symbols-outlined text-2xl">arrow_back</span>
        </button>
        <h2 className="text-lg font-bold leading-tight tracking-tight flex-1 text-center font-bengali">দাতা সম্মাননা সনদ</h2>
        <div className="w-12"></div>
      </header>
      <main className="flex-1 p-4 flex flex-col items-center">
        {!certificateImage ? (
            <div className="w-full max-w-lg space-y-6">
                <div className="text-center">
                     <h1 className="text-xl font-bold text-primary dark:text-white font-bengali">আপনার সম্মাননা তৈরি করুন</h1>
                     <p className="text-sm text-gray-500 mt-1 font-bengali">নিবন্ধিত ব্যবহারকারীর নাম ডিফল্ট হিসেবে দেওয়া আছে। আপনি চাইলে এটি পরিবর্তন করতে পারেন।</p>
                </div>
                <div className="bg-white dark:bg-card-dark p-6 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm space-y-4">
                    <label className="block">
                        <span className="text-sm font-bold text-gray-700 dark:text-gray-300 mb-2 block font-bengali">প্রাপকের নাম</span>
                        <input 
                            className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/20 text-base px-4 font-bengali" 
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="সম্পূর্ণ নাম লিখুন" 
                            type="text"
                        />
                    </label>
                    <button onClick={handleGenerate} disabled={isLoading || !name} className="w-full h-12 bg-primary text-white font-bold rounded-lg shadow-lg shadow-primary/20 flex items-center justify-center gap-2 active:scale-95 transition-transform disabled:bg-gray-400 font-bengali">
                        {isLoading ? <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div> : <><span>জেনারেট করুন</span> <span className="material-symbols-outlined">auto_awesome</span></>}
                    </button>
                </div>
            </div>
        ) : (
            <div className="w-full max-w-lg animate-fade-in space-y-6">
                <div ref={certificateRef} className="w-full max-w-lg mx-auto">
                    <Certificate name={name} qrDataURL={qrDataURL} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                    <button onClick={handleDownload} className="flex-1 bg-primary text-white py-3 rounded-lg font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-transform font-bengali">
                        <span className="material-symbols-outlined text-base">download</span>
                        ডাউনলোড PDF
                    </button>
                    <button onClick={() => setCertificateImage(null)} className="flex-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 py-3 rounded-lg font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-transform font-bengali">
                        <span className="material-symbols-outlined text-base">edit</span>
                        পরিবর্তন করুন
                    </button>
                </div>
            </div>
        )}
         {/* Hidden div for generation */}
         {!certificateImage &&
            <div className="fixed -left-[9999px] top-0">
                <div ref={certificateRef} style={{ width: '1123px', height: '794px' }}>
                    <Certificate name={name} qrDataURL={qrDataURL} />
                </div>
            </div>
         }
      </main>
    </div>
  );
};

export default DonorCertificateView;
