
import React, { useState, useEffect } from 'react';

interface OnboardingProps {
    onComplete: () => void;
}

// Language texts
const texts = {
    en: {
        welcome: "Welcome to CFH",
        tagline: "Empowering communities through global cooperation and sustainable humanitarian impact.",
        next: "Next",
        skip: "Skip",
        emergencyTitle: "Emergency Services",
        empoweringTitle: "Empowering Communities",
        getStarted: "Get Started",
        back: "Back",
    },
    bn: {
        welcome: "সিএফএইচ-এ স্বাগতম",
        tagline: "বৈশ্বিক সহযোগিতা এবং টেকসই মানবিক প্রভাবের মাধ্যমে সম্প্রদায়ের ক্ষমতায়ন।",
        next: "পরবর্তী",
        skip: "এড়িয়ে যান",
        emergencyTitle: "জরুরী সেবাসমূহ",
        empoweringTitle: "সম্প্রদায়কে ক্ষমতায়ন করা",
        getStarted: "শুরু করুন",
        back: "ফেরত",
    }
};

const LanguageSelector: React.FC<{ onSelect: (lang: 'en' | 'bn') => void }> = ({ onSelect }) => (
    <div className="flex h-full w-full flex-col justify-center items-center p-8 bg-white dark:bg-background-dark text-center animate-fade-in">
        <div className="flex items-center gap-2 mb-8">
            <div className="size-12 shrink-0 bg-primary rounded-lg flex items-center justify-center shadow-md">
                <span className="material-symbols-outlined text-white text-3xl">diversity_1</span>
            </div>
            <span className="text-2xl font-bold tracking-tight text-primary font-serif">CFH</span>
        </div>
        <h1 className="text-slate-800 dark:text-white text-xl font-bold mb-2">Choose your language</h1>
        <h2 className="text-primary text-xl font-bold font-bengali mb-10">আপনার ভাষা নির্বাচন করুন</h2>
        <div className="w-full space-y-4">
            <button onClick={() => onSelect('en')} className="w-full bg-primary/10 text-primary font-bold py-4 rounded-xl text-lg transition-colors hover:bg-primary/20">English</button>
            <button onClick={() => onSelect('bn')} className="w-full bg-primary/10 text-primary font-bold py-4 rounded-xl text-lg font-bengali transition-colors hover:bg-primary/20">বাংলা</button>
        </div>
    </div>
);


const Slide1: React.FC<{ onNext: () => void; onSkip: () => void; language: 'en' | 'bn' }> = ({ onNext, onSkip, language }) => (
    <div className="relative flex h-full w-full flex-col overflow-hidden bg-white dark:bg-background-dark animate-fade-in">
        <div className="flex items-center justify-center p-6 pt-12">
            <div className="flex items-center gap-2">
                <div className="size-10 shrink-0 bg-primary rounded-lg flex items-center justify-center shadow-sm">
                    <span className="material-symbols-outlined text-white text-2xl">diversity_1</span>
                </div>
                <span className="text-xl font-bold tracking-tight text-primary font-serif">CFH</span>
            </div>
        </div>
        <div className="px-6 py-2 h-[35%]">
            <div className="w-full h-full bg-center bg-no-repeat bg-cover rounded-xl shadow-md border border-gray-100" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAc8kKzfYx_e_wG2akiIn18ImR_zLfjcDvvyJlwBEzQ6e2dmLp5V3KhiWOVd6BWpNHUuzYd1JL5reJqW3vVMQjDLqSQO5mb-gXOPpjmStBqR7GQTOos-4CQdveoIOrGSu7cVxkrrpsWHjRxGwxPy9pHsRhEQMEJSyRJ_ZEVpzxEEEZMSIb2cbGuz1dVzUpz4_fJuGB6jUmlCDRmds9uYZvhH1OvDdvuQ21wkCKa8kadgirI5zeCwLtp3xdOdtZlWMFM9-ePuXn8862y')"}}></div>
        </div>
        <div className="flex-1 flex flex-col px-8 pt-8 overflow-y-auto">
            <div className="text-center space-y-2">
                <h1 className={`text-primary text-2xl font-bold leading-tight font-serif ${language === 'bn' ? 'font-bengali' : ''}`}>{texts[language].welcome}</h1>
            </div>
            <div className="mt-6 space-y-4 text-center">
                <p className={`text-gray-600 text-[15px] font-medium leading-relaxed ${language === 'bn' ? 'font-bengali' : ''}`}>{texts[language].tagline}</p>
            </div>
        </div>
        <div className="p-8 space-y-6 bg-white dark:bg-background-dark">
            <div className="flex w-full flex-row items-center justify-center gap-2.5">
                <div className="h-2 w-6 rounded-full bg-primary"></div>
                <div className="h-2 w-2 rounded-full bg-gray-200"></div>
                <div className="h-2 w-2 rounded-full bg-gray-200"></div>
            </div>
            <div className="space-y-4">
                <button onClick={onNext} className={`w-full bg-success hover:bg-success/90 text-white font-bold py-4 rounded-xl shadow-lg transition-all active:scale-[0.98] text-lg ${language === 'bn' ? 'font-bengali' : ''}`}>{texts[language].next}</button>
                <button onClick={onSkip} className={`w-full text-gray-500 font-semibold py-2 hover:text-primary transition-colors text-sm uppercase tracking-widest ${language === 'bn' ? 'font-bengali' : ''}`}>{texts[language].skip}</button>
            </div>
        </div>
    </div>
);

const Slide2: React.FC<{ onNext: () => void; onBack: () => void; onSkip: () => void; language: 'en' | 'bn' }> = ({ onNext, onBack, onSkip, language }) => (
    <div className="relative flex h-full w-full flex-col overflow-hidden bg-white dark:bg-background-dark animate-fade-in">
        <div className="flex items-center bg-transparent p-6 pb-2 justify-between z-10">
            <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center"><span className="text-white font-extrabold text-sm">CFH</span></div>
                <h2 className="text-[#111517] dark:text-white text-lg font-extrabold leading-tight tracking-tight">Come For Humanity</h2>
            </div>
            <button onClick={onSkip} className={`px-4 py-1.5 rounded-full bg-gray-100 dark:bg-gray-800 ${language === 'bn' ? 'font-bengali' : ''}`}><p className="text-[#647887] dark:text-gray-300 text-sm font-bold leading-normal tracking-wide">{texts[language].skip}</p></button>
        </div>
        <div className="flex w-full flex-row items-center justify-center gap-2 py-4">
            <div className="h-1.5 w-8 rounded-full bg-primary/20"></div>
            <div className="h-1.5 w-12 rounded-full bg-primary"></div>
            <div className="h-1.5 w-8 rounded-full bg-primary/20"></div>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center px-8 relative">
            <div className="absolute w-64 h-64 bg-primary/5 rounded-full -z-0"></div>
            <div className="grid grid-cols-2 gap-6 relative z-10">
                <div className="bg-white dark:bg-card-dark p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 flex flex-col items-center gap-3">
                    <div className="w-16 h-16 rounded-full bg-red-50 flex items-center justify-center"><span className="material-symbols-outlined text-red-500 text-4xl">water_drop</span></div>
                    <span className="text-xs font-bold uppercase tracking-widest text-red-500">BBS</span>
                </div>
                <div className="bg-white dark:bg-card-dark p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 flex flex-col items-center gap-3">
                    <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center"><span className="material-symbols-outlined text-primary text-4xl">stethoscope</span></div>
                    <span className="text-xs font-bold uppercase tracking-widest text-primary">Health</span>
                </div>
            </div>
        </div>
        <div className="px-6 pb-8 text-center space-y-2">
            <h1 className={`text-[#111517] dark:text-white tracking-tight text-[32px] font-extrabold leading-tight ${language === 'bn' ? 'font-bengali text-primary' : ''}`}>{texts[language].emergencyTitle}</h1>
        </div>
        <div className="p-6 pt-0 flex flex-col gap-3 mb-4">
            <button onClick={onNext} className={`w-full bg-primary hover:bg-primary/90 text-white font-extrabold py-4 rounded-xl transition-all shadow-lg shadow-primary/25 flex items-center justify-center gap-2 group ${language === 'bn' ? 'font-bengali' : ''}`}>
                <span>{texts[language].next}</span><span className="material-symbols-outlined text-xl transition-transform group-hover:translate-x-1">arrow_forward</span>
            </button>
            <button onClick={onBack} className="w-full py-3 flex items-center justify-center gap-1 group">
                <span className="material-symbols-outlined text-gray-400 group-hover:text-primary text-lg">chevron_left</span>
                <span className={`text-[#647887] dark:text-gray-300 font-bold text-sm ${language === 'bn' ? 'font-bengali' : ''}`}>{texts[language].back}</span>
            </button>
        </div>
    </div>
);

const Slide3: React.FC<{ onComplete: () => void; language: 'en' | 'bn' }> = ({ onComplete, language }) => (
    <div className="relative flex min-h-full w-full flex-col bg-[#f9fafa] dark:bg-background-dark font-display animate-fade-in">
        <main className="flex-1 flex flex-col px-6 pt-12">
            <div className="relative group">
                <div className="relative w-full aspect-[4/5] overflow-hidden rounded-2xl bg-slate-800 border border-black/5 shadow-2xl">
                    <div className="w-full h-full bg-center bg-no-repeat bg-cover" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuBcA9CwYhWAFF-7-yuNe8CIdvsCyVZE5jEu_0OEEEUFIDpqzSLybUMcLQf7mRh9CDz9sh3kQK67xh0dJCvV5gss4IFJ10zwO0skva7UjLrAvJ4ro-mz1-djvxG6atJOK8YDnVi0zWu5JHbouqQ3gqsEjh0zNaMHclOUXL8np6NUtnV88taoxsGEnkpuZ_ihvoLBGgU_j5nejJBGGEcig4Irc0vuaj03ws9meTT7zwffkSMkcYsYTq2oLYZbtOf7XVaHTOfWwrimkEiF')"}}></div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
                </div>
            </div>
            <div className="pt-8 pb-4 space-y-2">
                <h1 className={`text-3xl font-extrabold leading-tight tracking-tight text-slate-900 dark:text-white ${language === 'bn' ? 'font-bengali text-emerald/90' : ''}`}>{texts[language].empoweringTitle}</h1>
            </div>
        </main>
        <footer className="px-6 pb-12 pt-6">
            <div className="flex items-center justify-center gap-2.5 pb-8">
                <div className="h-1.5 w-6 rounded-full bg-slate-300"></div>
                <div className="h-1.5 w-6 rounded-full bg-slate-300"></div>
                <div className="h-1.5 w-12 rounded-full bg-emerald shadow-[0_0_12px_rgba(80,200,120,0.4)]"></div>
            </div>
            <button onClick={onComplete} className={`w-full bg-emerald hover:bg-emerald/90 text-white font-bold py-4 rounded-xl shadow-lg shadow-emerald/20 transition-all active:scale-[0.98] uppercase tracking-wide ${language === 'bn' ? 'font-bengali' : ''}`}>
                {texts[language].getStarted}
            </button>
        </footer>
    </div>
);


const OnboardingView: React.FC<OnboardingProps> = ({ onComplete }) => {
    const [step, setStep] = useState(1);
    const [language, setLanguage] = useState<'en' | 'bn' | null>(null);

    useEffect(() => {
        const savedLang = localStorage.getItem('cfhLanguage');
        if (savedLang === 'en' || savedLang === 'bn') {
            setLanguage(savedLang);
        }
    }, []);

    const handleLanguageSelect = (lang: 'en' | 'bn') => {
        localStorage.setItem('cfhLanguage', lang);
        setLanguage(lang);
    };

    if (!language) {
        return (
            <div className="h-screen max-w-[430px] mx-auto shadow-2xl font-sans">
                <LanguageSelector onSelect={handleLanguageSelect} />
            </div>
        );
    }

    const renderStep = () => {
        switch (step) {
            case 1:
                return <Slide1 onNext={() => setStep(2)} onSkip={onComplete} language={language} />;
            case 2:
                return <Slide2 onNext={() => setStep(3)} onBack={() => setStep(1)} onSkip={onComplete} language={language} />;
            case 3:
                return <Slide3 onComplete={onComplete} language={language} />;
            default:
                return <Slide1 onNext={() => setStep(2)} onSkip={onComplete} language={language} />;
        }
    };

    return (
        <div className="h-screen max-w-[430px] mx-auto shadow-2xl font-sans">
            {renderStep()}
        </div>
    );
};

export default OnboardingView;
