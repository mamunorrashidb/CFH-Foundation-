
import React from 'react';
import { View } from '../types';

interface MeherpurDirectoryViewProps {
  setActiveView: (view: View) => void;
}

const directoryData = {
  "প্রশাসন (Administration)": [
    { name: "জেলা প্রশাসক (DC)", office: "জেলা প্রশাসকের কার্যালয়, মেহেরপুর", phone: "+8802477784200" },
    { name: "পুলিশ সুপার (SP)", office: "পুলিশ সুপারের কার্যালয়, মেহেরপুর", phone: "+8802477784201" },
  ],
  "থানা (Police Stations)": [
    { name: "অফিসার-ইন-চার্জ", office: "মেহেরপুর সদর থানা", phone: "+8801320146333" },
    { name: "অফিসার-ইন-চার্জ", office: "গাংনী থানা", phone: "+8801320146366" },
    { name: "অফিসার-ইন-চার্জ", office: "মুজিবনগর থানা", phone: "+8801320146399" },
  ],
  "জরুরী সেবা (Emergency Services)": [
    { name: "ফায়ার সার্ভিস ও সিভিল ডিফেন্স", office: "ফায়ার স্টেশন, মেহেরপুর", phone: "02477784222" },
    { name: "র‍্যাব-১২", office: "সিপিসি-৩, গাংনী, মেহেরপুর", phone: "01777721203" },
  ],
  "বিদ্যুৎ (Electricity)": [
    { name: "পল্লী বিদ্যুৎ সমিতি", office: "অভিযোগ কেন্দ্র, মেহেরপুর", phone: "01769400111" },
    { name: "ওয়েস্ট জোন পাওয়ার ডিস্ট্রিবিউশন (ওজোপাডিকো)", office: "নির্বাহী প্রকৌশলীর দপ্তর, মেহেরপুর", phone: "02477784015" },
  ],
  "হাসপাতাল ও ক্লিনিক (Hospitals & Clinics)": [
    { name: "মেহেরপুর ২৫০ শয্যা জেনারেল হাসপাতাল", office: "হাসপাতাল রোড, মেহেরপুর", phone: "02477784204" },
    { name: "রয়েল ক্লিনিক ও ডায়াগনস্টিক সেন্টার", office: "হোটেল বাজার, মেহেরপুর", phone: "01711281896" },
  ],
};

const ContactCard: React.FC<{ name: string; office: string; phone: string }> = ({ name, office, phone }) => (
    <div className="bg-white dark:bg-card-dark p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 flex items-center justify-between gap-4">
        <div className="flex-1">
            <h3 className="text-base font-bold text-gray-800 dark:text-white font-bengali leading-tight">{name}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 font-bengali">{office}</p>
        </div>
        <a href={`tel:${phone}`} className="size-12 flex-shrink-0 bg-primary/10 hover:bg-primary/20 text-primary rounded-full flex items-center justify-center transition-colors">
            <span className="material-symbols-outlined">call</span>
        </a>
    </div>
);


const MeherpurDirectoryView: React.FC<MeherpurDirectoryViewProps> = ({ setActiveView }) => {
    return (
        <div className="bg-background-light dark:bg-background-dark min-h-screen">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
                <button onClick={() => setActiveView('directory')} className="size-10 flex items-center justify-center -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>
                <h1 className="text-lg font-bold font-bengali">মেহেরপুর ডিরেক্টরি</h1>
                <div className="w-10"></div>
            </header>
            <main className="p-4 space-y-6 pb-24">
                {Object.entries(directoryData).map(([category, contacts]) => (
                    <section key={category}>
                        <h2 className="text-base font-bold text-primary dark:text-primary/90 font-bengali mb-3 pb-2 border-b-2 border-primary/10">{category}</h2>
                        <div className="space-y-3">
                            {contacts.map((contact, index) => (
                                <ContactCard key={index} {...contact} />
                            ))}
                        </div>
                    </section>
                ))}
            </main>
        </div>
    );
};

export default MeherpurDirectoryView;
