import React from 'react';
import { View } from '../types';

interface TelemedicineViewProps {
    setActiveView: (view: View) => void;
}

const TelemedicineView: React.FC<TelemedicineViewProps> = ({ setActiveView }) => {
    return (
        <div className="max-w-[480px] mx-auto bg-white dark:bg-background-dark min-h-screen flex flex-col">
            <div className="sticky top-0 z-20 flex items-center bg-white/90 dark:bg-background-dark/90 backdrop-blur-md p-4 pb-2 justify-between border-b border-gray-100 dark:border-gray-800">
                <button onClick={() => setActiveView('dashboard')} className="text-[#121417] dark:text-white flex size-10 shrink-0 items-center justify-center cursor-pointer">
                    <span className="material-symbols-outlined">arrow_back_ios</span>
                </button>
                <h2 className="text-[#121417] dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center font-bengali">অনলাইন ডাক্তার</h2>
                <div className="w-10"></div>
            </div>
            <div className="flex-1 overflow-y-auto pb-12">
                <div className="px-4 pt-6 pb-2">
                    <h2 className="text-[#121417] dark:text-white text-[22px] font-extrabold leading-tight tracking-[-0.015em] font-bengali">রোগের লক্ষণ</h2>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 font-bengali">আপনার বর্তমান অবস্থা বুঝতে আমাদের সাহায্য করুন</p>
                </div>
                <div className="px-4 py-3">
                    <textarea className="form-input flex w-full resize-none overflow-hidden rounded-xl text-[#121417] dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/20 border border-[#dde0e4] dark:border-gray-700 bg-white dark:bg-gray-900 focus:border-primary min-h-32 placeholder:text-[#677283] p-[15px] text-base font-normal leading-normal font-bengali" placeholder="যেমন: ক্রমাগত কাশি, ২ দিনের জন্য হালকা জ্বর..."></textarea>
                </div>
                <div className="px-4 pt-8">
                    <div onClick={() => setActiveView('video-call')} className="bg-primary/5 dark:bg-primary/10 border-2 border-primary/20 rounded-2xl p-4 flex flex-col gap-4 cursor-pointer">
                        <div className="flex items-center gap-4">
                            <div className="relative">
                                <img alt="Doctor profile" className="w-16 h-16 rounded-xl object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAw3yYxqZoL2ALgOp3TMJ_PaTVZVICJy59KZrc5x1uGJk-FhTHXslzB2iRdRTmtrU_WDy6DnJ04XIrOWXMMr5lnF7S93yDaighgqwyFkrtgKrhQMV5B1GvhSBcXAwRdg4j_fiIOb7zo9sA2CXIBJexdVxJCh92n-L_UMqJN2tpzbH6L2MYdmnJCHWUnJc7rqjVOBx65e1cFZ-3TpNMJTWgRbruh01LvIktUUABngDpux3X6wLpuWRjB2VXXVimN0B5grjZi1s3hzFyf"/>
                                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
                            </div>
                            <div className="flex-1">
                                <h4 className="text-primary font-bold text-lg">Dr. Julian Bennett</h4>
                                <p className="text-sm text-gray-600 dark:text-gray-400">General Physician • 12 years exp.</p>
                            </div>
                        </div>
                        <button className="w-full bg-primary text-white py-4 rounded-xl font-bold text-lg shadow-lg shadow-primary/30 flex items-center justify-center gap-3 active:scale-[0.98] transition-transform font-bengali">
                            <span className="material-symbols-outlined">video_call</span>
                            পরামর্শ শুরু করুন
                        </button>
                    </div>
                </div>
                 <div className="px-4 pt-10 pb-4">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-[#121417] dark:text-white text-lg font-bold leading-tight font-bengali">আমার প্রেসক্রিপশন</h3>
                        <button onClick={() => setActiveView('digital-prescription')} className="text-primary text-sm font-bold font-bengali">সব দেখুন</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TelemedicineView;