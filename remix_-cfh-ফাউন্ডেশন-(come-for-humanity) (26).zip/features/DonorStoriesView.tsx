import React from 'react';
import { View } from '../types';

interface DonorStoriesViewProps {
  setActiveView: (view: View) => void;
}

const StoryCard: React.FC<{ videoData: any, setActiveView: (view: View) => void }> = ({ videoData, setActiveView }) => (
    <div className="group relative aspect-[3/4.5] w-full overflow-hidden rounded-xl bg-gray-200 shadow-xl shadow-black/5 dark:shadow-none">
        <div className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" 
             style={{backgroundImage: `linear-gradient(180deg, rgba(0,0,0,0) 40%, rgba(0,0,0,0.8) 100%), url("${videoData.thumbnailUrl}")`}}>
        </div>
        <div className="absolute inset-0 flex items-center justify-center">
            <div className="flex size-16 items-center justify-center rounded-full bg-success/90 text-white backdrop-blur-sm transition-transform active:scale-90 cursor-pointer">
                <span className="material-symbols-outlined text-4xl fill-1">play_arrow</span>
            </div>
        </div>
        <div className="absolute right-4 top-4">
            <button onClick={() => setActiveView('donation')} className="flex h-12 items-center gap-2 rounded-full bg-success px-4 text-white shadow-lg shadow-success/30 transition-transform active:scale-95">
                <span className="material-symbols-outlined fill-1">favorite</span>
                <span className="text-sm font-bold">Donate</span>
            </button>
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-6">
            <div className="mb-1 flex items-center gap-2">
                <span className={`size-2 rounded-full ${videoData.isVerified ? 'bg-success animate-pulse' : 'bg-primary'}`}></span>
                <span className={`text-[10px] font-bold uppercase tracking-widest ${videoData.isVerified ? 'text-success' : 'text-white/80'}`}>{videoData.tag}</span>
            </div>
            <h3 className="text-xl font-bold text-white leading-tight">{videoData.title}</h3>
            <p className="bengali-text text-lg text-white/90 leading-tight">{videoData.bengaliTitle}</p>
            <div className="mt-4 flex items-center gap-2 border-t border-white/20 pt-4">
                <div className="size-8 rounded-full border border-white/40 bg-center bg-cover" style={{backgroundImage: `url('${videoData.donorAvatar}')`}}></div>
                <div className="text-xs">
                    <p className="font-bold text-white">{videoData.donorName}</p>
                    <p className="text-white/70">{videoData.donorInfo}</p>
                </div>
            </div>
        </div>
    </div>
);

const DonorStoriesView: React.FC<DonorStoriesViewProps> = ({ setActiveView }) => {
    const stories = [
        { id: 1, isVerified: true, tag: 'Verified Story', title: 'Life Saved in Meherpur', bengaliTitle: 'মেহেরপুরে প্রাণ রক্ষা', thumbnailUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuA55CA6tuQD0qCMDSP66APx_a_dLO4ekkWwE1dJd6xNIL-6z4EiYQxXdjRjvr85KfVTGJvlO1UaHdr8gnv8OEpUBMwIwxEG2AjyOfOttcoO52QSxAB6f--5_jaS-uQQXIwKvWWzDuquAJCEYWuZdlgkRXVJNx9ZKSxJhwueC2_r-kcVkUxBYFSEZ77uesyGcbIZhlE2BJQE2VJxKmiwoapSH569yJQHAexkoICKXcRKuYianfEdCmUGMJsub4kOiChwcO7E96ZU41_F", donorName: 'Rahat Karim', donorInfo: 'O+ Positive Donor', donorAvatar: "https://lh3.googleusercontent.com/aida-public/AB6AXuDMhV_pXGXxowNfNJdsPMXKZeq3TmmJVtoAZKyYppSyhlDuyy9snNF0QPRU-zjCVjVbsA_dejBDMfQizsSOci3omboNXxfI-S-5QlY6Fzqma5BHbZIZAyMsdPHq1Ay6hq7c7ovUsACgA5YIRZQaDbWG1ua33nouftupsi64svQ_nfjTgoWZovrU3pia_oj3T6TiaQC6xIjCWvA6SGvZTg61TqIe5ck6-2V13fnccXyt2WDGZdzQABEfO4FrSvbklxGmjnRxCc42rqz0" },
        { id: 2, isVerified: false, tag: 'Most Viewed', title: 'The Gift of Life', bengaliTitle: 'জীবনের উপহার', thumbnailUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuCmsOuM--cxz2w2JTnmLIU5yxXfQCku-dK0dsH0NoVMPe_NKRCuMNS4bFiVvzoAWrgEx1O1R_mqj8Re8eR1ElTE3hwSpUexjmQ8jqoG_Ok9EJbnwF1uFZDCJBAK9RQB8Kng_5MB5fFk-FNhWRyhG_gwFVelUsQEACXS9aTIYWdsItHrBZuAh9lmocwlAznW9OYRY_xhSnLEqE-F5ZY88ZnTLj-Tw7jMQ0mqFH71PtBxZeKt1g7w9DYPEFK9CFstE_s113aKDrSwGj-H", donorName: 'Sarah Islam', donorInfo: 'A- Negative Donor', donorAvatar: "https://lh3.googleusercontent.com/aida-public/AB6AXuDlySCrntmlbNmSA2H1BOqI1VcqUDrs9RN8GaM_n3zWSPrvTXeCDBCsrDcS-p2t-ynTuL6LXRJKLbk6vw_sLt2XNaHpcGHQPSFT4J9VMp7OjFAZRkOBRhaGuTLGPNpX4luQq67yUKhhD5ghG4K01MLsxApXvXQYPnuFh8ia2uv6XdPp0Fmd3yhunHogXLK4mXZvOkwn6aZcroH7hlBpAiSn2J4liQHhgOi56snj_Z7ZOxlrIT5gUKUcIgDrYyurPZpzGTQcHnRK_2Sz" },
    ];

    return (
        <div className="relative mx-auto flex h-screen max-w-md flex-col overflow-hidden border-x border-gray-100 dark:border-gray-800 bg-background-light dark:bg-background-dark font-display text-[#111318] dark:text-white">
            <header className="sticky top-0 z-50 flex items-center justify-between bg-white/80 dark:bg-background-dark/80 px-6 py-4 backdrop-blur-md">
                <button onClick={() => setActiveView('dashboard')} className="flex items-center gap-3 cursor-pointer">
                    <div className="size-10 rounded-full bg-primary flex items-center justify-center text-white overflow-hidden shadow-lg shadow-primary/20">
                        <span className="material-symbols-outlined text-2xl font-bold">volunteer_activism</span>
                    </div>
                </button>
            </header>
            
            <main className="flex-1 overflow-y-auto no-scrollbar space-y-6 pb-8 px-6 pt-2">
                {stories.map(story => <StoryCard key={story.id} videoData={story} setActiveView={setActiveView} />)}
            </main>

            <style>{`
                :root { --primary: #184ed8; --success: #2ECC71; }
                .no-scrollbar::-webkit-scrollbar { display: none; }
                .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
                .bengali-text { font-family: 'Noto Sans Bengali', sans-serif; }
            `}</style>
        </div>
    );
};

export default DonorStoriesView;