
import React, { useState, useEffect } from 'react';
import { View } from '../types';
import { getMicroPartnerDashboard } from '../services/apiService';

interface MicroPartnerDashboardViewProps {
  setActiveView: (view: View) => void;
}

interface DashboardData {
    total_investment: string;
    current_earnings: string;
    profit_distribution: {
        partner_share: number;
        reinvestment: number;
        cfh_fund: number;
        operations: number;
    };
    history: {
        date: string;
        description: string;
        amount: string;
    }[];
}

const MicroPartnerDashboardView: React.FC<MicroPartnerDashboardViewProps> = ({ setActiveView }) => {
  const [data, setData] = useState<DashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const MOCK_USER_ID = 1; // In a real app, this would come from user context

  useEffect(() => {
    const fetchData = async () => {
        setIsLoading(true);
        try {
            const response = await getMicroPartnerDashboard(MOCK_USER_ID);
            if (response.status === 'success') {
                setData(response.data);
            } else {
                setError(response.message);
            }
        } catch (err) {
            setError((err as Error).message);
        } finally {
            setIsLoading(false);
        }
    };
    fetchData();
  }, [MOCK_USER_ID]);

  if (isLoading) {
    return (
        <div className="flex h-screen items-center justify-center bg-background-light dark:bg-background-dark">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
        </div>
    );
  }

  if (error) {
    return <div className="p-8 text-center text-red-500">Error loading data: {error}</div>;
  }
  
  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-[430px] mx-auto bg-background-light dark:bg-background-dark shadow-2xl overflow-x-hidden pb-24">
      <header className="flex items-center bg-white dark:bg-card-dark p-4 sticky top-0 z-50 border-b border-gray-100 dark:border-gray-800">
        <button onClick={() => setActiveView('ecommerce')} className="p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
            <span className="material-symbols-outlined text-primary">arrow_back</span>
        </button>
        <div className="ml-3 flex-1">
          <h2 className="text-gray-900 dark:text-white text-base font-bold leading-tight tracking-tight">CFH Micro-Partner</h2>
          <p className="text-[10px] text-gray-500 dark:text-gray-400 font-medium tracking-wider uppercase">Investment Hub</p>
        </div>
      </header>
      <main className="flex-1 overflow-y-auto p-4 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="flex flex-col gap-1 rounded-xl p-4 bg-primary/5 dark:bg-primary/10 border border-primary/20">
            <p className="text-primary dark:text-primary/90 text-xs font-bold leading-tight uppercase tracking-wider">মোট বিনিয়োগ</p>
            <p className="text-gray-900 dark:text-white text-3xl font-bold leading-tight mt-1">৳{data?.total_investment}</p>
          </div>
          <div className="flex flex-col gap-1 rounded-xl p-4 bg-emerald/5 dark:bg-emerald/10 border border-emerald/20">
            <p className="text-emerald text-xs font-bold leading-tight uppercase tracking-wider">বর্তমান আয়</p>
            <p className="text-gray-900 dark:text-white text-3xl font-bold leading-tight mt-1">৳{data?.current_earnings}</p>
          </div>
        </div>
        
        <div className="bg-white dark:bg-card-dark p-5 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm">
            <h3 className="text-lg font-bold mb-4 font-bengali">লাভের বন্টন (20-30-30-20 মডেল)</h3>
            <div className="space-y-4">
                {data?.profit_distribution && Object.entries(data.profit_distribution).map(([key, value]) => (
                    <div key={key}>
                        <div className="flex justify-between items-center mb-1">
                            <span className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{key.replace('_', ' ')}</span>
                            <span className="text-sm font-bold text-primary">{value}%</span>
                        </div>
                        <div className="h-2 w-full bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                            <div className="h-full bg-primary rounded-full" style={{width: `${value}%`}}></div>
                        </div>
                    </div>
                ))}
            </div>
        </div>

        <div>
            <h3 className="text-lg font-bold mb-3 font-bengali">সাম্প্রতিক লেনদেন</h3>
            <div className="space-y-2">
                {data?.history?.map((item, index) => (
                    <div key={index} className="bg-white dark:bg-card-dark p-3 rounded-lg flex items-center justify-between border border-gray-100 dark:border-gray-800">
                        <div>
                            <p className="font-bold text-sm text-emerald">+ ৳{item.amount}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400 font-bengali">{item.description}</p>
                        </div>
                        <p className="text-xs text-gray-400">{new Date(item.date).toLocaleDateString()}</p>
                    </div>
                ))}
            </div>
        </div>
      </main>
    </div>
  );
};

export default MicroPartnerDashboardView;
