
import React from 'react';
import { View } from '../types';

interface BloodRequestsViewProps {
  setActiveView: (view: View) => void;
}

const BloodRequestsView: React.FC<BloodRequestsViewProps> = ({ setActiveView }) => {
    // This component statically renders the design which includes an active bottom sheet.
    // In a real app, the sheet's visibility would be controlled by state.
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-[#111317] dark:text-white antialiased max-w-md mx-auto">
        <header className="sticky top-0 z-30 bg-white dark:bg-background-dark border-b border-[#dcdee5] dark:border-gray-700">
            <div className="flex items-center p-4 justify-between">
                <div className="flex items-center gap-3">
                    <span onClick={() => setActiveView('blood-bank')} className="material-symbols-outlined text-primary cursor-pointer">arrow_back_ios</span>
                    <h2 className="text-primary text-xl font-bold tracking-tight">Pending Blood Requests</h2>
                </div>
                <div className="flex gap-4">
                    <button className="flex items-center justify-center size-10 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                        <span className="material-symbols-outlined text-[#111317] dark:text-white">search</span>
                    </button>
                </div>
            </div>
            <div className="flex border-b border-[#dcdee5] dark:border-gray-700 px-4 gap-8">
                <a className="flex flex-col items-center justify-center border-b-[3px] border-b-primary text-primary pb-3 pt-4" href="#"><p className="text-sm font-bold tracking-wide uppercase">Urgent</p></a>
                <a className="flex flex-col items-center justify-center border-b-[3px] border-b-transparent text-[#646d87] pb-3 pt-4" href="#"><p className="text-sm font-bold tracking-wide uppercase">Processing</p></a>
                <a className="flex flex-col items-center justify-center border-b-[3px] border-b-transparent text-[#646d87] pb-3 pt-4" href="#"><p className="text-sm font-bold tracking-wide uppercase">Fulfilled</p></a>
            </div>
        </header>
        <main className="flex flex-col p-4 gap-4 pb-32">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-4 ios-shadow border-l-4 border-urgent-red flex justify-between items-center bg-primary/5">
                <div className="flex gap-4 items-center">
                    <div className="size-12 bg-urgent-red/10 rounded-lg flex items-center justify-center">
                        <span className="material-symbols-outlined text-urgent-red">bloodtype</span>
                    </div>
                    <div>
                        <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-[#111317] dark:text-white">John Doe • O Negative</h3>
                            <span className="bg-urgent-red text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">Urgent</span>
                        </div>
                        <p className="text-sm text-[#646d87] dark:text-gray-400">St. Mary Hospital • 15 mins ago</p>
                    </div>
                </div>
                <span className="material-symbols-outlined text-primary">radio_button_checked</span>
            </div>
        </main>

        <div className="fixed inset-0 z-40 bg-black/40 flex flex-col justify-end">
            <div className="bg-white dark:bg-background-dark rounded-t-[2.5rem] flex flex-col max-h-[90%] overflow-hidden ios-shadow">
                <div className="flex h-10 w-full items-center justify-center sticky top-0 bg-white dark:bg-background-dark z-50">
                    <div className="h-1.5 w-12 rounded-full bg-[#dcdee5] dark:bg-gray-600"></div>
                </div>
                <div className="overflow-y-auto px-6 pb-24">
                    <div className="flex justify-between items-start mb-6">
                        <div>
                            <h2 className="text-2xl font-bold dark:text-white">John Doe</h2>
                            <p className="text-primary font-semibold flex items-center gap-1">
                                <span className="material-symbols-outlined text-base">emergency</span>
                                O Negative Blood Request
                            </p>
                            <p className="text-sm text-gray-500 mt-1">Request ID: #BBS-78219</p>
                        </div>
                        <button className="bg-primary size-12 rounded-full flex items-center justify-center text-white shadow-lg shadow-primary/30">
                            <span className="material-symbols-outlined">call</span>
                        </button>
                    </div>
                    
                    <div className="bg-urgent-red/5 border border-urgent-red/20 rounded-xl p-4 mb-8">
                        <div className="flex items-center gap-2 mb-2">
                            <span className="material-symbols-outlined text-urgent-red text-xl">clinical_notes</span>
                            <h4 className="font-bold text-urgent-red uppercase text-xs tracking-wider">Medical Urgency Note</h4>
                        </div>
                        <p className="text-sm leading-relaxed text-[#111317] dark:text-gray-300">
                            Patient requires immediate transfusion following emergency surgery. Multi-organ trauma. No stock currently available in hospital blood bank. <strong>Critical response required within 45 mins.</strong>
                        </p>
                    </div>
                    <div className="mb-6">
                        <div className="flex justify-between items-center mb-4">
                            <h4 className="font-bold text-lg dark:text-white">Nearest Matching Donors</h4>
                            <span className="text-xs bg-gray-100 dark:bg-gray-800 text-gray-500 px-2 py-1 rounded font-semibold">5 MATCHES FOUND</span>
                        </div>
                        <div className="flex flex-col gap-3">
                            <div onClick={() => setActiveView('donor-profile')} className="flex items-center justify-between p-3 rounded-xl border border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/30 cursor-pointer">
                                <div className="flex gap-3 items-center">
                                    <div className="size-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">AM</div>
                                    <div>
                                        <p className="text-sm font-semibold dark:text-white">Alex Morgan</p>
                                        <p className="text-xs text-gray-500">O- • 0.8 km away • Ready</p>
                                    </div>
                                </div>
                                <button className="bg-white dark:bg-gray-700 border border-primary/30 text-primary text-[10px] font-bold px-4 py-1.5 rounded-lg hover:bg-primary hover:text-white transition-colors">ASSIGN</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-6 bg-white dark:bg-background-dark border-t border-gray-100 dark:border-gray-800 flex gap-3">
                    <button className="flex-1 bg-primary text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-primary/20">
                        <span className="material-symbols-outlined text-xl">campaign</span>
                        Broadcast to All
                    </button>
                </div>
            </div>
        </div>
        <style>{`
            :root {
              --primary: #4169e1;
              --background-dark: #22252a;
              --urgent-red: #E74C3C;
            }
            .ios-shadow { box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        `}</style>
    </div>
  );
};

export default BloodRequestsView;
