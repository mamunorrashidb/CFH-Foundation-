
import React from 'react';
import { View } from '../types';

interface RawNestSupportTicketViewProps {
  setActiveView: (view: View) => void;
}

const RawNestSupportTicketView: React.FC<RawNestSupportTicketViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-[480px] mx-auto bg-white dark:bg-[#1a1c21] overflow-x-hidden pb-32">
      <header className="sticky top-0 z-50 flex items-center bg-primary p-4 pb-4 justify-between shadow-md">
        <div className="flex items-center gap-3">
          <button onClick={() => setActiveView('support-center')} className="text-white flex size-10 shrink-0 items-center justify-center rounded-full bg-white/10 active:scale-95 transition-transform">
            <span className="material-symbols-outlined">arrow_back_ios_new</span>
          </button>
          <div className="flex flex-col">
            <h1 className="text-white text-lg font-bold leading-tight">RawNest IT Support</h1>
          </div>
        </div>
      </header>
      <main className="flex-1 overflow-y-auto px-4 pt-6">
        <div className="mb-6">
          <h2 className="text-[#111318] dark:text-white text-2xl font-extrabold leading-tight">New Support Ticket</h2>
        </div>
        <form className="space-y-5">
            <div className="bg-white dark:bg-[#22252a] p-4 rounded-xl border border-gray-100 dark:border-gray-800">
                <label className="flex flex-col gap-2">
                    <span className="text-[#111318] dark:text-white text-base font-bold leading-none">Service Category</span>
                    <div className="relative mt-2">
                        <select className="form-select w-full rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-[#1a1c21] py-3.5 pl-4 pr-10 text-sm focus:border-primary focus:ring-primary appearance-none dark:text-white">
                            <option>Software</option>
                        </select>
                    </div>
                </label>
            </div>
            <div className="bg-white dark:bg-[#22252a] p-4 rounded-xl border border-gray-100 dark:border-gray-800">
                 <label className="flex flex-col gap-2">
                    <span className="text-[#111318] dark:text-white text-base font-bold leading-none">Issue Description</span>
                    <textarea className="form-textarea mt-2 w-full rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-[#1a1c21] p-4 text-sm" placeholder="Describe your issue..." rows={4}></textarea>
                </label>
            </div>
        </form>
      </main>
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-white/80 dark:bg-[#1a1c21]/80 backdrop-blur-lg border-t border-gray-100 dark:border-gray-800 p-4 pb-8 flex flex-col gap-4">
        <button className="w-full bg-accent-green text-white font-bold py-4 rounded-xl">Submit Ticket</button>
      </div>
    </div>
  );
};

export default RawNestSupportTicketView;
