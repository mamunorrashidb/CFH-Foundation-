import React, { useState } from 'react';
import { View } from '../types';

interface MultimediaGalleryViewProps {
  setActiveView: (view: View) => void;
}

const MultimediaGalleryView: React.FC<MultimediaGalleryViewProps> = ({ setActiveView }) => {
  const [activeTab, setActiveTab] = useState<'photos' | 'videos'>('photos');
  
  const photos = [
    { title: 'Flood Relief 2023 | বন্যা ত্রাণ ২০২৩', date: 'Oct 12, 2023', imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAeXPy6SeVHt_5-dUkYRrxJYKUMP7TPnvsQD3-BKw8deejdwUdB3-NVycf_hk7ObNUQui1-0HB9f7_-OgUAPD2CM_L5P7DVEXIn7Q7fqXEbn0vQbIKDOES-sSdq-Bce65HAcBK8pmNTJ11A0OGtReEfLu1w__AZVOjx_uZHG6MSWOvvOnsIQmIMUMYSasH_L4dy4BCvJ6jjw_PGLYA0gmj-wMry0IyvR6d3Ek2-UBGKswZ7ZnesvrjAtOmLIpFU_0cb6e8X8isdggfj" },
    { title: 'Education Program | শিক্ষা কার্যক্রম', date: 'Sep 05, 2023', imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAyr5prNVzu-icvndWhJ1IJeZGAHB1KRLlnIY8-3k23FruYSXYxsj4P2hKfTu-rWUOijrzxl9euyduh2YBMD7f6wU9lcxxjW-y8MpJ5hQqGkFcQmA3ngUzXWAOnfbTV6MS0xQc-GcAtRqksB7L4x6-Z30XLAx5p8aSTTwK-fqghbYd5LsYDQMAhgfWUIvPpfe1jfPhnMXFyoUQOMmws7MMH1cpfEZB_lPuLoKubduwtpGtJaawZFJV1d5yK6kDd_O91uJpWqsz3XuU_" },
    { title: 'Medical Camp | মেডিকেল ক্যাম্প', date: 'Aug 20, 2023', imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDJOI8h4bBUkwlq_r83uKQbxce0nA1IfiZ6QhivnEq3w7Ll9OYvoOiqNNkByGpkVYf6k-SLXSHYe1OhOSGLQdDe3dhjj8eCR5HZfQGRy_0xBhWH-eptC29xKCbNpYANQ8s5a4xRWbeYJUAQiP2RIjAZqq7zAvF3MHXxY8e0MS2UMaIo8t6NGGZr4jAhp9fLrciyoeThxdzc2EbuKExkd1esoROeeJjZg5-vb2oyQqUH8sbN2S-XQBrsCqQou4h_WAGE8X9-c3_TpBh9" },
    { title: 'Winter Aid | শীতবস্ত্র বিতরণ', date: 'Jan 15, 2023', imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBb5GSbPZqaOD0zEARPjs0cA2tNx_QnZteH4FRHzNs1EKsWUV2IoYrbFaCrEaDxqeZExGtHPWX3V2ZbzhPhaPqBZrc3GEw01PrjrI2KQOVWASj7qUCzgV6x-rxl45ehqWyQV7U4wNQWCH5CCEmoypD4avTCOtUO0eJEYDpUqX82HKDFFg9vhmkAQo83B4LZZp9MqSNZZtVGO44QkaI6Exf47mgIWWpZAbeOP4z6RtjUjcySIyu9bI87U_iNV1wKhaVQI6scxN-gM8uk" },
  ];
  
  const videos = [
      { title: 'Mission Documentary 2024', bengaliTitle: 'মিশন ডকুমেন্টারি ২০২৪', thumbnailUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuD0w1GMYSO6Q2p9TwDocz1Ks4I6Yk_EvA8pl26NhZGBHDAfoEloFtLvyiQGb0RbVpsqr09wk2fGQXgKQy7AXt9uqLUZBy23yYyAmwa8VsmrVhOoC6_UwqVBziR52Ki-hWB0NeIKFYBfMt3PO8biI8X6VpUOKp8gYYrUt0A8CZlSPKJFN0kFnlt5S5E9crADlioSP5rKTpD_pRDswgXMCNhUwUCoaywmnN6WvlfBLbmW_QYEudZxI7IK9fHBl8YHEtRThjZEp8En4iKR" },
      { title: 'CFH Impact Report | সিএফএইচ ইমপ্যাক্ট', bengaliTitle: 'Stories of change from the ground', thumbnailUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuB-P3f10hQxwriw09f4gD2oz4Z69Ni1nOkadbSzGeA7zY6q6n5m-LhTho3GZ0gLtTJeOQe72NlOeLkXQBJdsgA_ycBHCZhOqyCzyJwQxHhgGpaz4Q4viv4dkq4LsISq0IDwLID3IVLhzv76bjPEQE03K7jQMV66WmzorZlBYkZZbkEmOgp282WFeFYIYbn2LHOVXp2UvWEhwcFmpLmzTaubUJZ-lwBFhUvsy-NBuPkm0p6YeevV7sfeqXb_-rpJi9OyGpbQ-Fwi-9xA" },
  ]

  return (
    <div className="max-w-md mx-auto bg-background-light dark:bg-background-dark font-display text-[#111317] dark:text-white antialiased">
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
        <button onClick={() => setActiveView('dashboard')} className="flex items-center gap-3">
          <div className="bg-primary p-1.5 rounded-lg flex items-center justify-center"><span className="material-symbols-outlined text-white text-2xl font-bold">volunteer_activism</span></div>
          <h1 className="text-primary dark:text-white text-lg font-bold leading-tight tracking-tight">Multimedia Gallery</h1>
        </button>
      </header>
      
      <nav className="bg-white dark:bg-background-dark border-b border-[#dcdee5] dark:border-gray-800 sticky top-[68px] z-40">
        <div className="flex px-4">
          <button onClick={() => setActiveTab('photos')} className={`flex-1 flex flex-col items-center justify-center border-b-[3px] pb-[13px] pt-4 ${activeTab === 'photos' ? 'border-primary text-primary' : 'border-transparent text-[#646d87] dark:text-gray-400'}`}><span className="text-sm font-bold tracking-wide">Photos</span></button>
          <button onClick={() => setActiveTab('videos')} className={`flex-1 flex flex-col items-center justify-center border-b-[3px] pb-[13px] pt-4 ${activeTab === 'videos' ? 'border-primary text-primary' : 'border-transparent text-[#646d87] dark:text-gray-400'}`}><span className="text-sm font-bold tracking-wide">Videos</span></button>
        </div>
      </nav>

      <main className="pb-8">
        {activeTab === 'photos' && (
          <>
            <div className="flex items-center justify-between px-4 pt-6 pb-2"><h3 className="text-[#111317] dark:text-white text-lg font-bold leading-tight">Latest Missions</h3><button className="text-primary text-sm font-bold flex items-center gap-1">Filter <span className="material-symbols-outlined text-sm">tune</span></button></div>
            <div className="grid grid-cols-2 gap-4 p-4">
              {photos.map((photo, i) => (
                <div key={i} className="flex flex-col gap-2 group cursor-pointer">
                  <div className="relative aspect-[4/5] w-full overflow-hidden rounded-xl shadow-sm border border-gray-100 dark:border-gray-800">
                    <div className="w-full h-full bg-center bg-cover transition-transform duration-500 group-hover:scale-105" style={{backgroundImage: `url("${photo.imageUrl}")`}}></div>
                  </div>
                  <div className="px-1"><p className="text-[#111317] dark:text-white text-sm font-semibold leading-tight line-clamp-2">{photo.title}</p><p className="text-[#646d87] dark:text-gray-400 text-xs font-medium mt-1 uppercase tracking-wider">{photo.date}</p></div>
                </div>
              ))}
            </div>
          </>
        )}
        {activeTab === 'videos' && (
           <>
            <div className="px-4 pt-6 pb-2 flex items-center justify-between"><h3 className="text-[#111317] dark:text-white text-lg font-bold leading-tight">Featured Documentaries</h3><span className="bg-[#50C878]/10 text-[#50C878] px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest">Watch Now</span></div>
            <div className="grid grid-cols-1 gap-4 p-4">
                {videos.map((video, i) => (
                    <div key={i} className="group relative overflow-hidden rounded-2xl aspect-video cursor-pointer shadow-md">
                        <div className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" style={{backgroundImage: `linear-gradient(0deg, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.2) 50%, rgba(0,0,0,0) 100%), url("${video.thumbnailUrl}")`}}></div>
                        <div className="absolute inset-0 flex items-center justify-center"><div className="w-14 h-14 bg-primary/90 text-white rounded-full flex items-center justify-center shadow-xl transform transition-all group-hover:scale-110 group-active:scale-95"><span className="material-symbols-outlined text-3xl ml-1">play_arrow</span></div></div>
                        <div className="absolute bottom-4 left-4 right-4 text-white"><p className="text-lg font-bold leading-tight drop-shadow-md">{video.title}</p><p className="text-sm font-medium opacity-90 drop-shadow-md">{video.bengaliTitle}</p></div>
                    </div>
                ))}
            </div>
           </>
        )}
      </main>
    </div>
  );
};

export default MultimediaGalleryView;