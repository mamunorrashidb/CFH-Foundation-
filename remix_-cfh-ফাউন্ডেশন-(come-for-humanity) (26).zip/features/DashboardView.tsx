import React, { useState, useEffect } from 'react';
import { View, CartItem, SdgProject } from '../types';
import { getCurrentLocation } from '../utils/location';
import { getMockWeather, WeatherData } from '../utils/weather';
import { db } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, doc, limit } from 'firebase/firestore';

interface NewsItem {
    id: string;
    title: string;
    imageUrl?: string;
    tag?: string;
}

interface AppSettings {
    isBloodBankEnabled: boolean;
    isOxygenServiceEnabled: boolean;
    isTelemedicineEnabled: boolean;
    isChatBotEnabled: boolean;
    announcementTicker: string;
}

const DashboardView: React.FC<{ setActiveView: (view: View, props?: any) => void; cart: CartItem[] }> = ({ setActiveView, cart }) => {
    const [currentTime, setCurrentTime] = useState(new Date());
    const [weather, setWeather] = useState<WeatherData | null>(null);
    const [sdgProjects, setSdgProjects] = useState<any[]>([]);
    const [newsSlides, setNewsSlides] = useState<NewsItem[]>([]);
    const [currentSlide, setCurrentSlide] = useState(0);
    const [liveStats, setLiveStats] = useState<string[]>([]);
    const [settings, setSettings] = useState<AppSettings>({
        isBloodBankEnabled: true,
        isOxygenServiceEnabled: true,
        isTelemedicineEnabled: true,
        isChatBotEnabled: true,
        announcementTicker: "সিএফএইচ অ্যাপে আপনাকে স্বাগতম!"
    });
    const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

    useEffect(() => {
        // Fetch Settings
        const unsubSettings = onSnapshot(doc(db, 'settings', 'app_config'), (docSnap) => {
            if (docSnap.exists()) setSettings(docSnap.data() as AppSettings);
        });

        // Fetch Live Stats for Blood Bank scroll
        const unsubStats = onSnapshot(doc(db, 'settings', 'live_stats'), (docSnap) => {
            if (docSnap.exists()) {
                const data = docSnap.data();
                if (data.bloodStats) setLiveStats(data.bloodStats);
            } else {
                // Default stats if none in Firebase
                setLiveStats([
                    "এ পজিটিভ রক্ত প্রয়োজন - মেহেরপুর সদর",
                    "ও পজিটিভ ডোনার ইচ্ছুক - গাংনী",
                    "বি নেগেটিভ ডোনার জরুরি - মুজিবনগর"
                ]);
            }
        });

        // Fetch Live News for Slider
        const newsQ = query(collection(db, 'news'), orderBy('publishedAt', 'desc'), limit(5));
        const unsubNews = onSnapshot(newsQ, (snap) => {
            const data = snap.docs.map(d => ({ id: d.id, ...d.data() })) as NewsItem[];
            if (data.length > 0) setNewsSlides(data);
        });

        // Fetch Projects
        const unsubProjects = onSnapshot(collection(db, 'projects'), (snap) => {
            const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
            setSdgProjects(data);
        });

        const timeInterval = setInterval(() => setCurrentTime(new Date()), 1000);

        return () => {
            unsubSettings();
            unsubStats();
            unsubNews();
            unsubProjects();
            clearInterval(timeInterval);
        };
    }, []);

    useEffect(() => {
        if (newsSlides.length > 0) {
            const timer = setInterval(() => {
                setCurrentSlide((prev) => (prev + 1) % newsSlides.length);
            }, 6000);
            return () => clearInterval(timer);
        }
    }, [newsSlides]);

    useEffect(() => {
        const fetchWeather = async () => {
            try {
                const { latitude, longitude } = await getCurrentLocation();
                setWeather(await getMockWeather(latitude, longitude));
            } catch (e) {}
        };
        fetchWeather();
    }, []);


    return (
        <div className="bg-background-light dark:bg-background-dark text-[#101815] transition-colors duration-300 pb-32">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
                <div className="flex items-center gap-3">
                    <div className="size-11 rounded-full bg-primary flex items-center justify-center text-white overflow-hidden shadow-md border-2 border-white dark:border-gray-700">
                        <span className="material-symbols-outlined text-2xl">volunteer_activism</span>
                    </div>
                    <div>
                        <h1 className="text-primary dark:text-white text-xl font-black leading-none tracking-tight">CFH</h1>
                        <p className="text-[9px] text-emerald font-bold uppercase tracking-[0.2em]">Come For Humanity</p>
                    </div>
                </div>
                <div className="flex gap-2">
                    <button onClick={() => setActiveView('cart')} className="size-10 flex items-center justify-center rounded-full bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-300 relative">
                        <span className="material-symbols-outlined text-[22px]">shopping_bag</span>
                        {cartItemCount > 0 && (
                            <span className="absolute -top-1 -right-1 size-5 bg-primary text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white dark:border-background-dark">{cartItemCount}</span>
                        )}
                    </button>
                    <button onClick={() => setActiveView('notification-center')} className="size-10 flex items-center justify-center rounded-full bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-300 relative">
                        <span className="material-symbols-outlined text-[22px]">notifications</span>
                        <span className="absolute top-2 right-2 size-2 bg-red-500 rounded-full border-2 border-white dark:border-gray-800"></span>
                    </button>
                </div>
            </header>

            <main>
                 <section className="p-4">
                    <div className="bg-white dark:bg-card-dark rounded-xl p-4 border border-gray-100 dark:border-gray-800 shadow-sm flex items-center justify-between">
                        <div>
                            <p className="font-bold text-lg font-bengali">{currentTime.toLocaleDateString('bn-BD', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
                            <p className="text-2xl font-black text-primary">{currentTime.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })}</p>
                        </div>
                        {weather ? (
                            <div className="text-right">
                                <div className="flex items-center gap-2 justify-end">
                                    <span className="material-symbols-outlined text-amber-500 text-2xl">{weather.icon}</span>
                                    <p className="text-2xl font-black text-gray-800 dark:text-white">{weather.temperature}°C</p>
                                </div>
                                <p className="text-sm font-bold text-gray-500 dark:text-gray-400 font-bengali">{weather.condition}, {weather.location}</p>
                            </div>
                        ) : (
                             <div className="w-16 h-8 bg-gray-100 dark:bg-gray-700 rounded animate-pulse"></div>
                        )}
                    </div>
                </section>
                
                <section className="relative w-full aspect-video overflow-hidden group bg-gray-200 dark:bg-gray-800">
                    {newsSlides.length > 0 ? (
                        <>
                            <div className="relative h-full w-full">
                                {newsSlides.map((slide, index) => (
                                    <div key={index} className={`absolute inset-0 transition-opacity duration-1000 ${index === currentSlide ? 'opacity-100' : 'opacity-0'}`}>
                                        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url('${slide.imageUrl || 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&q=80&w=800'}')` }}></div>
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                                        <div className="absolute bottom-0 left-0 right-0 p-5 text-white">
                                            <span className="bg-primary px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-widest mb-2 inline-block font-bengali">খবর ও আপডেট</span>
                                            <h2 className="text-lg font-bold leading-tight font-bengali line-clamp-2">{slide.title}</h2>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="absolute bottom-4 right-4 flex gap-1.5">
                                {newsSlides.map((_, index) => (
                                    <button key={index} onClick={() => setCurrentSlide(index)} className={`h-1.5 rounded-full transition-all ${index === currentSlide ? 'w-4 bg-white' : 'w-1.5 bg-white/50'}`}></button>
                                ))}
                            </div>
                        </>
                    ) : (
                        <div className="flex items-center justify-center h-full">
                            <span className="text-gray-400 font-bengali">লোড হচ্ছে...</span>
                        </div>
                    )}
                </section>

                <section className="p-4">
                    <div className="grid grid-cols-2 gap-3">
                        {settings.isBloodBankEnabled && (
                            <button onClick={() => setActiveView('blood-bank')} className="flex flex-col items-start justify-between gap-2 p-4 bg-red-500/10 dark:bg-red-900/20 rounded-xl border border-red-100 dark:border-red-900/30 h-28">
                                <span className="material-symbols-outlined text-red-500 text-3xl">bloodtype</span>
                                <span className="text-base font-bold text-red-700 dark:text-red-300 font-bengali text-left">রক্ত দিন</span>
                            </button>
                        )}
                        {settings.isOxygenServiceEnabled && (
                            <button onClick={() => setActiveView('oxygen-service')} className="flex flex-col items-start justify-between gap-2 p-4 bg-blue-500/10 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-900/30 h-28">
                                <span className="material-symbols-outlined text-blue-500 text-3xl">masks</span>
                                <span className="text-base font-bold text-blue-700 dark:text-blue-300 font-bengali text-left">অক্সিজেন</span>
                            </button>
                        )}
                        <button onClick={() => setActiveView('hall-of-fame')} className="flex flex-col items-start justify-between gap-2 p-4 bg-amber-500/10 dark:bg-amber-900/20 rounded-xl border border-amber-100 dark:border-amber-900/30 h-28">
                            <span className="material-symbols-outlined text-amber-500 text-3xl">groups</span>
                            <span className="text-base font-bold text-amber-700 dark:text-amber-300 font-bengali text-left">আমাদের সম্পর্কে</span>
                        </button>
                        {settings.isTelemedicineEnabled && (
                            <button onClick={() => setActiveView('telemedicine')} className="flex flex-col items-start justify-between gap-2 p-4 bg-emerald-500/10 dark:bg-emerald-900/20 rounded-xl border border-emerald-100 dark:border-emerald-900/30 h-28">
                                <span className="material-symbols-outlined text-emerald-500 text-3xl">stethoscope</span>
                                <span className="text-base font-bold text-emerald-700 dark:text-emerald-300 font-bengali text-left">আমাদের ডাক্তার</span>
                            </button>
                        )}
                    </div>
                </section>
                
                <section className="px-4">
                    <div className="bg-white dark:bg-card-dark rounded-2xl p-4 border border-gray-100 dark:border-gray-800 shadow-sm flex items-center gap-3 overflow-hidden">
                        <span className="bg-primary text-white text-[10px] font-bold px-2 py-1 rounded shrink-0">Live</span>
                        <div className="flex-1 overflow-hidden">
                            <p className="animate-marquee whitespace-nowrap text-sm font-medium font-bengali">{settings.announcementTicker}</p>
                        </div>
                    </div>
                </section>
                
                <section className="px-4">
                    <button onClick={() => setActiveView('live-news')} className="w-full bg-white dark:bg-card-dark rounded-2xl p-5 border border-gray-100 dark:border-gray-800 shadow-sm flex justify-between items-center">
                        <div className="text-left">
                            <h3 className="text-lg font-bold text-gray-800 dark:text-white font-bengali flex items-center gap-2">
                                <span className="material-symbols-outlined text-primary">newspaper</span>
                                লাইভ সংবাদ
                            </h3>
                            <p className="text-xs text-gray-500 dark:text-gray-400 font-bengali">মেহেরপুর জেলার সর্বশেষ খবর</p>
                        </div>
                        <span className="material-symbols-outlined text-gray-400">chevron_right</span>
                    </button>
                </section>
                
                <section className="px-4 mt-3">
                    <div className="bg-white dark:bg-card-dark rounded-2xl p-5 border border-red-100 dark:border-gray-800 shadow-sm">
                        <div className="flex justify-between items-start">
                             <div className="min-w-0">
                                <h3 className="text-lg font-bold text-red-800 dark:text-red-200 font-bengali flex items-center gap-2">
                                    <span className="material-symbols-outlined text-red-500">bloodtype</span>
                                    বিবিএস ব্লাড ব্যাংক
                                </h3>
                                <div className="relative flex overflow-x-hidden mt-2 text-xs text-red-500 font-medium font-bengali">
                                    <div className="flex animate-scroll whitespace-nowrap">
                                        {(liveStats.length > 0 ? [...liveStats, ...liveStats] : ['ডেটা লোড হচ্ছে...', 'ডেটা লোড হচ্ছে...']).map((item, index) => (
                                            <span key={index} className="mx-4">{item}</span>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="mt-4 pt-4 border-t border-red-100 dark:border-gray-700">
                            <button onClick={() => setActiveView('blood-bank')} className="w-full bg-red-500 text-white font-bold py-3 px-5 rounded-lg flex items-center justify-center gap-2 shadow-lg shadow-red-500/20 active:scale-95 transition-transform">
                                <span className="material-symbols-outlined">search</span>
                                <span className="font-bengali">ডোনার খুঁজুন</span>
                            </button>
                        </div>
                        <div className="mt-3">
                            <button onClick={() => setActiveView('donor-registration')} className="w-full bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-300 font-bold py-3 rounded-lg flex items-center justify-center gap-2 text-sm hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors">
                                <span className="material-symbols-outlined">person_add</span>
                                <span className="font-bengali">নতুন ডোনার হিসাবে নিবন্ধন করুন</span>
                            </button>
                        </div>
                    </div>
                </section>


                <section className="py-4">
                    <h2 className="text-xl font-bold tracking-tight px-4 mb-3 font-bengali mt-4">আমাদের উদ্যোগ</h2>
                    <div className="flex overflow-x-auto gap-3 px-4 no-scrollbar">
                        <button onClick={() => setActiveView('live-news')} className="flex-shrink-0 w-40 space-y-2 text-left"><div className="aspect-square bg-cover bg-center rounded-xl" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuBb5GSbPZqaOD0zEARPjs0cA2tNx_QnZteH4FRHzNs1EKsWUV2IoYrbFaCrEaDxqeZExGtHPWX3V2ZbzhPhaPqBZrc3GEw01PrjrI2KQOVWASj7qUCzgV6x-rxl45ehqWyQV7U4wNQWCH5CCEmoypD4avTCOtUO0eJEYDpUqX82HKDFFg9vhmkAQo83B4LZZp9MqSNZZtVGO44QkaI6Exf47mgIWWpZAbeOP4z6RtjUjcySIyu9bI87U_iNV1wKhaVQI6scxN-gM8uk')"}}></div><p className="font-bold text-sm font-bengali">শীত উৎসব</p></button>
                        <button onClick={() => setActiveView('live-news')} className="flex-shrink-0 w-40 space-y-2 text-left"><div className="aspect-square bg-cover bg-center rounded-xl" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCmsOuM--cxz2w2JTnmLIU5yxXfQCku-dK0dsH0NoVMPe_NKRCuMNS4bFiVvzoAWrgEx1O1R_mqj8Re8eR1ElTE3hwSpUexjmQ8jqoG_Ok9EJbnwF1uFZDCJBAK9RQB8Kng_5MB5fFk-FNhWRyhG_gwFVelUsQEACXS9aTIYWdsItHrBZuAh9lmocwlAznW9OYRY_xhSnLEqE-F5ZY88ZnTLj-Tw7jMQ0mqFH71PtBxZeKt1g7w9DYPEFK9CFstE_s113aKDrSwGj-H')"}}></div><p className="font-bold text-sm font-bengali">সবার জন্য ইফতার</p></button>
                        <button onClick={() => setActiveView('live-news')} className="flex-shrink-0 w-40 space-y-2 text-left"><div className="aspect-square bg-cover bg-center rounded-xl" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDTHDcZK4UkHhskil-fChqywzE9HKLKu4PHaPoY3UGbF9rvNnI0Gb_SgHPoLSa_SKMCVCW33qqAmG2WJIOk9sY5Q1oBz2_veqAK4NufaNzlcdHTj_5yi1ubPvGAOUCcGume1ufCXzPqjAXheNA_4mf3D-JW5qzd8ble-UNZyHYsOS2iYSNNqYBKCyl_QzQi3smH5v713DPFhQ8peoATVZPaRoMlAQObQ9U2AdMdh2wWsrMV5Kyvk9WkimhoZ3Yg7ApOxzmuciMj2zqC')"}}></div><p className="font-bold text-sm font-bengali">ঈদ উপহার</p></button>
                        <button onClick={() => setActiveView('live-news')} className="flex-shrink-0 w-40 space-y-2 text-left"><div className="aspect-square bg-cover bg-center rounded-xl" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAyr5prNVzu-icvndWhJ1IJeZGAHB1KRLlnIY8-3k23FruYSXYxsj4P2hKfTu-rWUOijrzxl9euyduh2YBMD7f6wU9lcxxjW-y8MpJ5hQqGkFcQmA3ngUzXWAOnfbTV6MS0xQc-GcAtRqksB7L4x6-Z30XLAx5p8aSTTwK-fqghbYd5LsYDQMAhgfWUIvPpfe1jfPhnMXFyoUQOMmws7MMH1cpfEZB_lPuLoKubduwtpGtJaawZFJV1d5yK6kDd_O91uJpWqsz3XuU_')"}}></div><p className="font-bold text-sm font-bengali">গ্রিন স্কুল</p></button>
                    </div>
                </section>
                
                <section className="p-4 space-y-3">
                     <div className="flex items-center justify-between">
                        <h2 className="text-xl font-bold tracking-tight font-bengali">ইভেন্ট ও প্রেস রিলিজ</h2>
                        <button onClick={() => setActiveView('events-calendar')} className="text-primary text-sm font-bold">সব দেখুন</button>
                     </div>
                     <div onClick={() => setActiveView('events-calendar')} className="bg-white dark:bg-card-dark rounded-xl p-3 flex items-center gap-4 border border-gray-100 dark:border-gray-800 shadow-sm">
                        <div className="flex flex-col items-center justify-center size-14 rounded-lg bg-gray-100 dark:bg-gray-800 shrink-0"><span className="text-xs font-bold text-primary uppercase">জুলাই</span><span className="text-xl font-bold text-primary dark:text-white">২৯</span></div>
                        <div><p className="font-bold text-sm leading-tight">বার্ষিক সাধারণ সভা ২০২৪</p><p className="text-xs text-gray-500 mt-0.5">স্থান: সিএফএইচ প্রধান কার্যালয়</p></div>
                     </div>
                      <div onClick={() => setActiveView('news-feed')} className="bg-white dark:bg-card-dark rounded-xl p-3 flex items-center gap-4 border border-gray-100 dark:border-gray-800 shadow-sm">
                        <div className="size-14 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"><span className="material-symbols-outlined text-primary text-3xl">campaign</span></div>
                        <div><p className="font-bold text-sm leading-tight">নতুন অক্সিজেন কনসেন্ট্রেটর হস্তান্তর</p><p className="text-xs text-gray-500 mt-0.5">প্রেস রিলিজ • জুলাই ২৬, ২০২৪</p></div>
                     </div>
                </section>

                <section className="py-4">
                    <div className="flex items-center justify-between px-4 mb-3">
                        <h2 className="text-xl font-bold tracking-tight font-bengali">সামাজিক ব্যবসার অনলাইন স্টোর</h2>
                        <button onClick={() => setActiveView('ecommerce')} className="text-primary text-sm font-bold">সব দেখুন</button>
                    </div>
                    <div className="flex overflow-x-auto gap-4 px-4 no-scrollbar">
                        <div onClick={() => setActiveView('shopno-gori-product-detail', {product: {id: 1, name: 'নকশি কাঁথা সিল্ক শাল', price: '1250', image: 'https://i.etsystatic.com/22588305/r/il/69cb31/4891233930/il_794xN.4891233930_t1x0.jpg'}})} className="flex-shrink-0 w-48 bg-white dark:bg-card-dark rounded-xl shadow-sm overflow-hidden group border border-gray-100 dark:border-gray-800 cursor-pointer">
                            <div className="h-32 overflow-hidden">
                                <img src="https://i.etsystatic.com/22588305/r/il/69cb31/4891233930/il_794xN.4891233930_t1x0.jpg" alt="নকশি কাঁথা সিল্ক শাল" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                            </div>
                            <div className="p-3">
                                <h4 className="font-bold text-sm text-gray-800 dark:text-white truncate font-bengali">নকশি কাঁথা সিল্ক শাল</h4>
                                <p className="font-extrabold text-primary text-md font-bengali mt-2">৳1250</p>
                            </div>
                        </div>
                        <div onClick={() => setActiveView('shopno-gori-product-detail', {product: {id: 4, name: 'সুন্দরবনের মধু', price: '980', image: 'https://i0.wp.com/foodbank.com.bd/wp-content/uploads/2021/04/sundarban-honey-500-gram.jpg?fit=800%2C800&ssl=1'}})} className="flex-shrink-0 w-48 bg-white dark:bg-card-dark rounded-xl shadow-sm overflow-hidden group border border-gray-100 dark:border-gray-800 cursor-pointer">
                            <div className="h-32 overflow-hidden">
                                <img src="https://i0.wp.com/foodbank.com.bd/wp-content/uploads/2021/04/sundarban-honey-500-gram.jpg?fit=800%2C800&ssl=1" alt="সুন্দরবনের মধু" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                            </div>
                            <div className="p-3">
                                <h4 className="font-bold text-sm text-gray-800 dark:text-white truncate font-bengali">সুন্দরবনের মধু</h4>
                                <p className="font-extrabold text-primary text-md font-bengali mt-2">৳980</p>
                            </div>
                        </div>
                        <div onClick={() => setActiveView('shopno-gori-product-detail', {product: {id: 3, name: 'খাঁটি সরিষার তেল', price: '320', image: 'https://chaldal.com/asset/cod-slider/c-23-23/mustard-oil-cat-tile-pc.jpg?v=2.2'}})} className="flex-shrink-0 w-48 bg-white dark:bg-card-dark rounded-xl shadow-sm overflow-hidden group border border-gray-100 dark:border-gray-800 cursor-pointer">
                            <div className="h-32 overflow-hidden">
                                <img src="https://chaldal.com/asset/cod-slider/c-23-23/mustard-oil-cat-tile-pc.jpg?v=2.2" alt="খাঁটি সরিষার তেল" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                            </div>
                            <div className="p-3">
                                <h4 className="font-bold text-sm text-gray-800 dark:text-white truncate font-bengali">খাঁটি সরিষার তেল</h4>
                                <p className="font-extrabold text-primary text-md font-bengali mt-2">৳320</p>
                            </div>
                        </div>
                    </div>
                </section>
                
                <section className="py-4">
                    <div className="flex items-center justify-between px-4 mb-3">
                        <h2 className="text-xl font-bold tracking-tight font-bengali">আমাদের SDG প্রকল্পসমূহ</h2>
                        <button onClick={() => setActiveView('sdg-projects')} className="text-primary text-sm font-bold">সব দেখুন</button>
                    </div>
                    <div className="px-4 space-y-3">
                        {sdgProjects.slice(0, 2).map(project => {
                            const progress = project.target_goal ? (project.current_progress / project.target_goal) * 100 : 0;
                            return (
                                <div key={project.id} onClick={() => setActiveView('sdg-projects')} className="bg-white dark:bg-card-dark rounded-xl p-4 border border-gray-100 dark:border-gray-800 shadow-sm cursor-pointer">
                                    <div className="flex justify-between items-start">
                                         <h4 className="font-bold text-sm text-gray-800 dark:text-white font-bengali">{project.title}</h4>
                                         <span className={`px-2 py-0.5 text-[10px] font-bold text-white rounded-full ${project.status === 'Completed' ? 'bg-emerald-500' : 'bg-blue-500'}`}>{project.status}</span>
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1 font-bengali line-clamp-2">{project.description}</p>
                                    {project.target_goal && (
                                        <div className="mt-3">
                                            <div className="flex justify-between text-[10px] font-medium text-gray-500 dark:text-gray-400 mb-1">
                                                <span>Progress</span>
                                                <span>{Math.round(progress)}%</span>
                                            </div>
                                            <div className="w-full bg-gray-100 dark:bg-gray-700 rounded-full h-1.5">
                                                <div className="bg-primary h-1.5 rounded-full" style={{ width: `${progress}%` }}></div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )
                        })}
                    </div>
                </section>

            </main>
        </div>
    );
};

export default DashboardView;