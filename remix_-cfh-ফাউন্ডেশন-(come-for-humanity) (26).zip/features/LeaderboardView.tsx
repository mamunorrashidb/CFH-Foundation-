
import React from 'react';
import { View } from '../types';

interface LeaderboardViewProps {
  setActiveView: (view: View) => void;
}

const LeaderboardView: React.FC<LeaderboardViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-md mx-auto shadow-2xl bg-white dark:bg-background-dark overflow-x-hidden">
        <header className="sticky top-0 z-50 flex items-center bg-white/90 dark:bg-background-dark/90 backdrop-blur-md px-4 py-4 border-b border-gray-100 dark:border-gray-800 justify-between">
            <button onClick={() => setActiveView('hall-of-fame')} className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                <span className="material-symbols-outlined text-primary">arrow_back</span>
            </button>
            <div className="flex flex-col items-center flex-1">
                <h2 className="text-[#111318] dark:text-white text-[15px] font-extrabold leading-tight tracking-tight text-center">Community Growth Champion</h2>
                <span className="text-[10px] text-primary font-bold uppercase tracking-widest">CFH Leaderboard</span>
            </div>
            <div className="w-10"></div>
        </header>
        <main className="flex-1 pb-44">
            <div className="px-4 pt-6 pb-4">
                <div className="flex items-end justify-center gap-3 h-64">
                    <div className="flex-1 flex flex-col items-center">
                        <div className="w-full bg-slate-50 dark:bg-gray-800/50 rounded-t-xl p-3 border-t-4 border-silver-medal text-center h-28 flex flex-col justify-center shadow-sm">
                            <p className="text-xs font-bold truncate dark:text-white">Sarah Ahmed</p>
                            <p className="text-[11px] text-gray-500 font-medium">128 Referrals</p>
                        </div>
                    </div>
                    <div className="flex-[1.2] flex flex-col items-center">
                         <div className="w-full bg-primary/5 dark:bg-primary/10 rounded-t-2xl p-4 border-t-4 border-gold-medal text-center h-40 flex flex-col justify-center shadow-md relative overflow-hidden">
                            <p className="text-sm font-extrabold truncate dark:text-white">Ariful Islam</p>
                            <p className="text-xs text-primary font-bold">142 Referrals</p>
                        </div>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                         <div className="w-full bg-slate-50 dark:bg-gray-800/50 rounded-t-xl p-3 border-t-4 border-bronze-medal text-center h-24 flex flex-col justify-center shadow-sm">
                            <p className="text-xs font-bold truncate dark:text-white">Joy Ghosh</p>
                            <p className="text-[11px] text-gray-500 font-medium">115 Referrals</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <div className="fixed bottom-[64px] left-0 right-0 max-w-md mx-auto px-4 pb-4">
            <div className="bg-white/95 dark:bg-background-dark/95 backdrop-blur-lg border border-gray-100 dark:border-gray-800 rounded-2xl shadow-2xl p-4 flex items-center justify-between gap-4">
                <button className="flex-1 bg-emerald-growth hover:bg-emerald-600 active:scale-95 transition-all text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-growth/20">
                    <span className="material-symbols-outlined text-xl">share</span>
                    <span className="text-sm">Share Referral Link</span>
                </button>
            </div>
        </div>
    </div>
  );
};

export default LeaderboardView;
