import React from 'react';
import { View } from '../types';

interface NewsFeedViewProps {
  setActiveView: (view: View) => void;
}

const NewsFeedView: React.FC<NewsFeedViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 min-h-screen font-display pb-8">
        <header className="sticky top-0 z-40 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-slate-100 dark:border-slate-800 px-5 py-3 flex items-center justify-between">
            <button onClick={() => setActiveView('dashboard')} className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary">arrow_back</span>
                <span className="text-xl font-bold tracking-tight text-primary">CFH</span>
            </button>
            <div className="flex items-center gap-4">
                <button onClick={() => setActiveView('profile')} className="relative">
                    <img alt="Profile" className="w-9 h-9 rounded-full object-cover border-2 border-primary/20" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAbWW7KiFfn6o_WpxUS7lfpCAUwmZWcj00wrV4C0BeqyK46o4pCWz48ruJjEOP28LzM4F2mHCprc5BGyMNsAy9AeakDfsd0u_x6IUl818T9HQBLiIMnHNMVLyPKJIxP9eQUIa1InrfDwj8nWwxQ5B2a-exqyec_e9Embwq5X_mOOstXHj3dTEv4IlBTsSfhrk2c35SXhBql-sGdIWWIosB_ut6i0GTYTShlBDX5c0q6rtzPVsS8i-vWTLV5ds059qFCaHSBd8ouWLI8"/>
                </button>
            </div>
        </header>
        <main className="pt-4 px-4 max-w-lg mx-auto space-y-6">
            <article className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
                <div className="p-4 flex items-start justify-between">
                    <div className="flex items-center gap-3">
                        <img alt="Requester" className="w-12 h-12 rounded-lg object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAsK0KRwtNtRUEgFV0J6FXQOftvFXns1SxUSo2-Ffr7XvbZXrjgoPGDueyQgjYMEbKqGzng8tcG8r6VwrasjlQU3CkffFZFL3eoQGJ5KhIYIzsLBfHZGNWGDL02grYbeQco9JZxoDjYAurvGOR1cNKv5bxqS-LDzkWjo_krKnGrY6XVRLCCQ-hg2rx-5wdqqnsvToUlk0eeFA1DytYaFLEG-vugzIOQcjwNrUH8F2DzxbkoQxe6K-lHGxz4BwlVIbGQyMR8n1m1a-wm"/>
                        <div>
                            <div className="flex items-center gap-1.5">
                                <h3 className="font-bold text-slate-900 dark:text-white">Aisha Rahman</h3>
                                <span className="material-symbols-outlined text-primary text-[18px] font-variation-fill">verified</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="px-4 pb-4">
                    <p className="text-slate-700 dark:text-slate-300 text-sm leading-relaxed">
                        Need help with emergency medications for a child with post-surgery recovery requirements.
                    </p>
                </div>
                <div className="p-4 border-t border-slate-100 dark:border-slate-800 flex gap-3">
                    <button onClick={() => setActiveView('donation')} className="flex-1 bg-success text-white font-bold py-3 rounded-lg">
                        Support
                    </button>
                </div>
            </article>
        </main>
    </div>
  );
};

export default NewsFeedView;