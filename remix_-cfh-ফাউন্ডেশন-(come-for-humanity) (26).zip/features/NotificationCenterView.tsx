
import React from 'react';
import { View } from '../types';

interface NotificationCenterViewProps {
  setActiveView: (view: View) => void;
}

const NotificationCenterView: React.FC<NotificationCenterViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-[#121417] dark:text-white antialiased">
        <div className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md">
            <div className="flex items-center px-4 pt-6 pb-2 justify-between">
                <button onClick={() => setActiveView('dashboard')} className="text-[#121417] dark:text-white flex size-10 items-center justify-center rounded-full hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer">
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>
                <h1 className="text-2xl font-bold tracking-tight">Search & Notifications</h1>
                 <div className="w-10"></div>
            </div>
            <div className="px-4 py-3">
                <div className="relative flex items-center group">
                    <div className="absolute left-4 text-[#657586] pointer-events-none group-focus-within:text-primary transition-colors">
                        <span className="material-symbols-outlined">search</span>
                    </div>
                    <input className="w-full h-12 pl-12 pr-4 rounded-xl border-none bg-white dark:bg-white/10 text-base font-normal placeholder:text-[#657586] focus:ring-2 focus:ring-primary/50 shadow-sm transition-all" placeholder="Search donors, supplies..." type="text"/>
                </div>
            </div>
        </div>
        <main className="px-4 pb-24">
            <div className="flex items-center justify-between pt-4 pb-3">
                <h3 className="text-sm font-bold uppercase tracking-wider text-[#657586]">Urgent Requests</h3>
            </div>
            <div className="space-y-3">
                <div className="bg-white dark:bg-[#2d303a] rounded-xl p-4 shadow-sm border-l-4 border-urgent">
                    <div className="flex gap-3">
                        <div className="size-10 rounded-full bg-urgent/10 flex items-center justify-center text-urgent shrink-0">
                            <span className="material-symbols-outlined">emergency</span>
                        </div>
                        <div>
                            <h4 className="font-bold text-[#121417] dark:text-white">O+ Required at City Hospital</h4>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
  );
};

export default NotificationCenterView;
