
import React from 'react';
import { View } from '../types';

interface RapidDeploymentViewProps {
  setActiveView: (view: View) => void;
}

const RapidDeploymentView: React.FC<RapidDeploymentViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-dark font-display text-white overflow-hidden h-screen max-w-md mx-auto">
      <nav className="relative z-50 flex items-center bg-background-dark/90 backdrop-blur-md p-4 border-b border-white/10 justify-between">
        <button onClick={() => setActiveView('emergency-help')} className="flex items-center gap-3">
          <div className="bg-alert-red size-3 rounded-full animate-pulse"></div>
          <h2 className="text-white text-lg font-bold uppercase">Rapid Deployment</h2>
        </button>
      </nav>
      <main className="relative flex-1 h-[calc(100vh-64px)] overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="w-full h-full bg-slate-900 bg-cover bg-center grayscale contrast-125 brightness-50" style={{backgroundImage: "url('https://i.stack.imgur.com/7bI1Y.png')"}}></div>
        </div>
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-full max-w-sm">
          <div className="bg-alert-red/90 backdrop-blur-sm border-l-4 border-white py-2 px-4 shadow-2xl">
            <span className="text-white text-xs font-black tracking-widest uppercase">CRISIS ALERT ACTIVE</span>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 z-20 flex flex-col">
            <div className="bg-panel-dark border-t border-primary/30 p-6 pt-2 pb-10 rounded-t-xl shadow-lg">
                <div className="w-12 h-1 bg-white/10 rounded-full mx-auto mb-6"></div>
                <h3 className="text-xl font-black uppercase tracking-tighter mb-6">Geo-Fence Target</h3>
                <button className="w-full bg-alert-red py-4 px-6 flex items-center justify-between rounded-sm shadow-lg active:scale-[0.98] transition-all">
                    <div className="flex items-center gap-4">
                        <span className="material-symbols-outlined font-bold text-2xl">emergency_share</span>
                        <span className="text-base font-black uppercase tracking-widest">Trigger Notification</span>
                    </div>
                </button>
            </div>
        </div>
      </main>
      <style>{`
        body { --primary: #4169e1; --alert-red: #DC3545; --background-dark: #0D0D0D; --panel-dark: #161616; }
      `}</style>
    </div>
  );
};

export default RapidDeploymentView;
