
import React, { useState, useEffect } from 'react';
import { View, Product, CartItem, Course } from '../types';
import { fetchVendorData } from '../services/apiService';


interface EcommerceViewProps {
    setActiveView: (view: View, props?: any) => void;
    addToCart: (product: Product) => void;
    cart: CartItem[];
}

const mockCourse: Course = {
    id: 1,
    title: 'Basic Cake Baking Course',
    bengaliTitle: 'বেসিক কেক বেকিং কোর্স',
    fee: '500',
    image: 'https://images.pexels.com/photos/8963458/pexels-photo-8963458.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    description: 'আমাদের এই কোর্সটি বিশেষভাবে নতুনদের জন্য ডিজাইন করা হয়েছে যারা ঘরে বসেই কেক বেকিংয়ের মৌলিক বিষয়গুলো শিখতে চান। এই কোর্সের মাধ্যমে আপনি একজন দক্ষ বেকার হয়ে উঠতে পারবেন এবং নিজের ব্যবসা শুরু করার আত্মবিশ্বাস অর্জন করবেন।',
    learnings: [
        'কেকের উপকরণ পরিচিতি ও সঠিক পরিমাপ।',
        'বিভিন্ন প্রকার কেক (ভ্যানিলা, চকলেট) তৈরির কৌশল।',
        'বেকিং ওভেন ব্যবহারের নিয়মাবলী।'
    ]
};

const ProductCard: React.FC<{ product: Product; addToCart: (product: Product) => void }> = ({ product, addToCart }) => {
    return (
        <div className="bg-white dark:bg-card-dark rounded-2xl shadow-sm overflow-hidden group border border-gray-100 dark:border-gray-800">
            <div className="h-40 overflow-hidden">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
            </div>
            <div className="p-3">
                <h4 className="font-bold text-sm text-gray-800 dark:text-white truncate font-bengali">{product.name}</h4>
                <div className="flex justify-between items-center mt-2">
                    <p className="font-extrabold text-primary text-md font-bengali">৳{product.price}</p>
                    <button 
                        onClick={() => addToCart(product)}
                        className="size-8 bg-primary/10 text-primary rounded-full flex items-center justify-center hover:bg-primary/20 transition-colors font-bold"
                        aria-label={`Add ${product.name} to cart`}
                    >
                       <span className="material-symbols-outlined">add</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

const EcommerceView: React.FC<EcommerceViewProps> = ({ setActiveView, addToCart, cart }) => {
    const [products, setProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

    useEffect(() => {
        const loadProducts = async () => {
            setIsLoading(true);
            try {
                // For this unified view, we'll fetch from a default or combined source
                const response = await fetchVendorData('shwapnogori'); // Or a new 'all' endpoint
                if (response.status === 'success' && response.data.products) {
                    setProducts(response.data.products);
                } else {
                    setProducts([]);
                }
            } catch (error) {
                console.error("Failed to fetch products:", error);
                setProducts([]);
            } finally {
                setIsLoading(false);
            }
        };
        loadProducts();
    }, []);

    const popularProducts = products.slice(0, 2);
    const newCollection = products.slice(2);

    return (
        <div className="bg-background-light dark:bg-background-dark min-h-screen pb-24">
             <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
                <button onClick={() => setActiveView('dashboard')} className="size-10 flex items-center justify-center -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>
                <h1 className="text-lg font-bold font-bengali">সামাজিক ব্যবসা</h1>
                 <button onClick={() => setActiveView('cart')} className="size-10 flex items-center justify-center rounded-full bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-300 relative">
                        <span className="material-symbols-outlined text-[22px]">shopping_bag</span>
                        {cartItemCount > 0 && (
                            <span className="absolute -top-1 -right-1 size-5 bg-primary text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white dark:border-background-dark">{cartItemCount}</span>
                        )}
                    </button>
            </header>
            
            <main>
                <section className="p-4">
                    <div className="bg-primary/5 dark:bg-primary/10 rounded-2xl p-5 border-2 border-primary/20 text-center">
                        <h2 className="text-xl font-bold text-primary dark:text-primary/90 font-bengali">উদ্যোক্তাদের স্বাবলম্বী করার একটি উদ্যোগ</h2>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-2 font-bengali">আপনার প্রতিটি কেনাকাটা গ্রামীণ নারীদের কর্মসংস্থানে সহায়তা করে।</p>
                    </div>
                </section>

                <section className="py-4">
                    <h3 className="text-lg font-bold font-bengali mb-3 px-4">জনপ্রিয় পণ্য</h3>
                     {isLoading ? (
                        <div className="text-center py-6"><div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto"></div></div>
                    ) : (
                        <div className="p-4 pt-0 grid grid-cols-2 gap-4">
                            {popularProducts.map(product => (
                                <ProductCard key={product.id} product={product} addToCart={addToCart} />
                            ))}
                        </div>
                    )}
                </section>
                
                <section className="py-4">
                    <h3 className="text-lg font-bold font-bengali mb-3 px-4">নতুন কালেকশন</h3>
                     {isLoading ? (
                         <div className="text-center py-6"><div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto"></div></div>
                    ) : (
                        <div className="p-4 pt-0 grid grid-cols-2 gap-4">
                            {newCollection.map(product => (
                                <ProductCard key={product.id} product={product} addToCart={addToCart} />
                            ))}
                        </div>
                    )}
                </section>

                <section className="p-4">
                    <div className="bg-white dark:bg-card-dark rounded-2xl p-4 border border-gray-100 dark:border-gray-800 shadow-sm">
                        <h3 className="text-lg font-bold font-bengali mb-4 flex items-center gap-2"><span className="material-symbols-outlined text-primary">school</span>নারীর স্বাবলম্বিতা - স্বপ্নগড়ি প্রকল্প</h3>
                        <div onClick={() => setActiveView('shopno-gori-enrollment', { course: mockCourse })} className="bg-cover bg-center rounded-xl p-5 flex flex-col justify-end h-48 cursor-pointer group" style={{backgroundImage: `linear-gradient(to top, rgba(0,0,0,0.7), transparent), url('${mockCourse.image}')`}}>
                            <h4 className="text-white text-xl font-bold font-bengali drop-shadow-md">{mockCourse.bengaliTitle}</h4>
                            <p className="text-white/90 text-sm font-bengali drop-shadow-sm">ঘরে বসেই শিখুন এবং স্বাবলম্বী হোন।</p>
                            <span className="mt-3 bg-white text-primary px-4 py-2 rounded-lg font-bold text-xs inline-block self-start group-hover:bg-primary group-hover:text-white transition-colors">ভর্তি হোন</span>
                        </div>
                    </div>
                </section>

            </main>
        </div>
    );
};

export default EcommerceView;
