import React from 'react';
import { View } from '../types';

interface SpiritualSessionPlayerViewProps {
  setActiveView: (view: View) => void;
}

const SpiritualSessionPlayerView: React.FC<SpiritualSessionPlayerViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-dark font-display text-white">
        <div className="fixed inset-0 z-0 overflow-hidden">
            <div className="absolute inset-0 bg-cover bg-center" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDPOOllK_5v_W1L0u2URl7mRXHxSF1eETzATbsvxlsm-vhfNGg93NrugHbrlvqWocUhsKsFhXZNRmtfigrRg6jYtbBVRsUf9idySDC1EPIS52Bbgd2LLQ8ObxzTDguFTI-0Brw6G-nVblOOsl8rxW8rsJ5MzHwSo35L4t8B4YgBGwOUJfTk7KFUtCcUsaksecpZ9O5KWXxGFmPI8YdCH0DJtZIF0AzCDjDa-2XNkaJYFfAw6i0QVp5bWIsA6nJIFam1j1JUa4HGC2Ww')"}}></div>
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-background-dark/90"></div>
        </div>
        <div className="relative z-10 flex flex-col h-screen max-w-md mx-auto overflow-hidden">
            <header className="flex items-center justify-between p-6 pt-12">
                <button onClick={() => setActiveView('spiritual-journal')} className="w-10 h-10 flex items-center justify-center rounded-full bg-black/20 backdrop-blur-sm border border-white/10">
                    <span className="material-symbols-outlined text-white">expand_more</span>
                </button>
            </header>
            <div className="flex-grow"></div>
            <div className="flex flex-col items-center justify-center py-10">
                <div className="relative w-64 h-64 flex items-center justify-center">
                    <div className="absolute inset-0 rounded-full" style={{background: "radial-gradient(closest-side, transparent 90%, rgba(23, 109, 53, 0.2) 90%), conic-gradient(#176d35 30%, rgba(255, 255, 255, 0.1) 0)"}}></div>
                    <button className="w-48 h-48 rounded-full bg-primary/90 flex items-center justify-center shadow-2xl shadow-primary/40">
                        <span className="material-symbols-outlined text-white text-6xl">pause</span>
                    </button>
                </div>
            </div>
            <div className="px-8 text-center space-y-2 pb-12">
                <h1 className="text-2xl font-bold leading-tight">Inner Peace & Gratitude</h1>
            </div>
        </div>
    </div>
  );
};

export default SpiritualSessionPlayerView;