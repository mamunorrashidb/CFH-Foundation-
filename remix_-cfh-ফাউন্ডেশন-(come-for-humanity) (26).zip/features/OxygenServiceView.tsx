
import React, { useState } from 'react';
import { submitOxygenRequest } from '../services/apiService';
import { getCurrentLocation } from '../utils/location';
import { View } from '../types';

interface OxygenServiceViewProps {
  setActiveView: (view: View) => void;
}

const OxygenServiceView: React.FC<OxygenServiceViewProps> = ({ setActiveView }) => {
    const [formData, setFormData] = useState({
        patientName: '',
        contactNumber: '',
        address: '',
        oxygenLevel: '',
        cylinderSize: 'Large (1.4m3)',
    });
    const [isLoading, setIsLoading] = useState(false);

    const handleGetLocation = async () => {
        setIsLoading(true);
        try {
            const { latitude, longitude } = await getCurrentLocation();
            setFormData(prev => ({ ...prev, address: `Lat: ${latitude.toFixed(5)}, Lon: ${longitude.toFixed(5)}` }));
        } catch (error) {
            alert((error as Error).message);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleSubmit = async () => {
        // Here you would normally call submitOxygenRequest(formData)
        // For now, we simulate success and navigate to the confirmation page.
        setActiveView('booking-confirmation');
    };

    return (
        <div className="max-w-md mx-auto flex flex-col min-h-screen bg-background-light dark:bg-background-dark text-[#101718] dark:text-white font-display">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
                <div className="flex items-center p-4 justify-between">
                    <div className="flex items-center gap-3">
                         <button onClick={() => setActiveView('dashboard')} className="size-10 flex items-center justify-center -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
                           <span className="material-symbols-outlined">arrow_back_ios_new</span>
                         </button>
                        <div className="text-primary"><span className="material-symbols-outlined text-3xl">masks</span></div>
                        <div>
                            <h1 className="text-lg font-bold leading-tight tracking-tight">অক্সিজেন সেবা</h1>
                            <p className="text-xs text-gray-500 dark:text-gray-400">Come For Humanity</p>
                        </div>
                    </div>
                </div>
            </header>

            <main className="flex-1 pb-24">
                <section className="px-4 pt-6">
                    <div className="bg-primary/5 dark:bg-primary/10 border-2 border-primary/20 rounded-2xl p-6 text-center">
                        <h2 className="text-2xl font-bold text-primary font-bengali mb-1">জরুরী প্রয়োজনে কল করুন</h2>
                        <p className="text-sm text-gray-600 dark:text-gray-400 font-bengali">আমাদের হটলাইন ২৪/৭ খোলা আছে।</p>
                        <a href="tel:+8801788405091" className="w-full flex items-center justify-center gap-3 bg-primary text-white py-4 mt-5 rounded-xl font-bold text-lg shadow-lg shadow-primary/30 active:scale-95 transition-transform">
                            <span className="material-symbols-outlined">call</span>
                            <span>+8801788405091</span>
                        </a>
                        <p className="text-xs text-gray-500 mt-3 font-bengali">সরাসরি কল করে সিলিন্ডার অর্ডার করুন, আবেদন ফর্ম পূরণের প্রয়োজন নেই।</p>
                    </div>
                </section>
                
                <section className="px-4 pt-6">
                    <h3 className="text-base font-bold mb-3 font-bengali">লাইভ স্ট্যাটাস</h3>
                    <div className="grid grid-cols-2 gap-3">
                        <div className="flex flex-col gap-1 rounded-xl p-4 bg-white dark:bg-card-dark shadow-sm border border-gray-100 dark:border-gray-800 items-center">
                            <p className="text-primary text-4xl font-black leading-tight">2</p>
                            <p className="text-gray-500 dark:text-gray-400 text-xs font-bold uppercase tracking-wider font-bengali">সিলিন্ডার মজুদ আছে</p>
                        </div>
                        <div className="flex flex-col gap-1 rounded-xl p-4 bg-white dark:bg-card-dark shadow-sm border border-gray-100 dark:border-gray-800 items-center">
                            <p className="text-gray-700 dark:text-gray-200 text-4xl font-black leading-tight">128</p>
                            <p className="text-gray-500 dark:text-gray-400 text-xs font-bold uppercase tracking-wider font-bengali">রোগী সেবা নিচ্ছেন</p>
                        </div>
                    </div>
                </section>

                <section className="mt-8">
                    <div className="flex items-center justify-between px-4 pb-3">
                        <h2 className="text-lg font-bold leading-tight tracking-tight font-bengali">বিকল্প পদ্ধতি: আবেদন ফর্ম</h2>
                    </div>
                    <div className="px-4 space-y-4">
                        <div className="space-y-1"><label className="text-xs font-bold text-gray-500 dark:text-gray-400 ml-1 uppercase tracking-wider font-bengali">রোগীর নাম</label><input className="w-full h-12 bg-white dark:bg-card-dark border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-primary/50 focus:border-primary text-sm px-4" placeholder="সম্পূর্ণ নাম লিখুন" type="text"/></div>
                        <div className="space-y-1"><label className="text-xs font-bold text-gray-500 dark:text-gray-400 ml-1 uppercase tracking-wider font-bengali">ফোন নম্বর</label><div className="relative"><span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm font-bold">+880</span><input className="w-full h-12 pl-16 bg-white dark:bg-card-dark border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-primary/50 focus:border-primary text-sm px-4" placeholder="1XXX XXXXXX" type="tel"/></div></div>
                        <div className="space-y-1">
                            <label className="text-xs font-bold text-gray-500 dark:text-gray-400 ml-1 uppercase tracking-wider font-bengali">ডেলিভারি ঠিকানা</label>
                            <div className="relative"><input value={formData.address} onChange={(e) => setFormData(p => ({...p, address: e.target.value}))} className="w-full h-12 pr-12 bg-white dark:bg-card-dark border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-primary/50 focus:border-primary text-sm px-4" placeholder="বাড়ি, রাস্তা, এলাকা" type="text"/><button onClick={handleGetLocation} className="absolute right-3 top-1/2 -translate-y-1/2 text-primary"><span className={`material-symbols-outlined ${ isLoading ? 'animate-spin' : ''}`}>{ isLoading ? 'progress_activity' : 'my_location'}</span></button></div>
                        </div>
                        <div className="pt-4"><button onClick={handleSubmit} className="w-full h-14 bg-primary/80 hover:bg-primary text-white rounded-xl font-bold shadow-lg shadow-primary/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 font-bengali"><span>আবেদন জমা দিন</span><span className="material-symbols-outlined">send</span></button></div>
                    </div>
                </section>
            </main>
        </div>
    );
};

export default OxygenServiceView;