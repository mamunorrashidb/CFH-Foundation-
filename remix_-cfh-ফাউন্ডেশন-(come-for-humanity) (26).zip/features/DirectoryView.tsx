import React from 'react';
import { View } from '../types';
import { CATEGORIES } from '../constants';

const CategoryCard: React.FC<{ category: typeof CATEGORIES[0]; onClick: (view: View) => void }> = ({ category, onClick }) => (
    <button onClick={() => onClick(category.id)} className="bg-white dark:bg-card-dark p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 flex flex-col items-center text-center gap-2 hover:border-primary transition-colors">
        <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary text-2xl">
            {category.icon}
        </div>
        <h3 className="text-sm font-bold text-gray-800 dark:text-white leading-tight">{category.title}</h3>
        <p className="text-xs text-gray-500 dark:text-gray-400 font-bengali">{category.description}</p>
    </button>
);

const DirectoryView: React.FC<{ setActiveView: (view: View) => void }> = ({ setActiveView }) => {
    return (
        <div className="bg-background-light dark:bg-background-dark min-h-screen">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
                <h1 className="text-xl font-bold text-gray-800 dark:text-white">Explore Services</h1>
                <div className="w-10"></div>
            </header>
            <main className="p-4 grid grid-cols-2 sm:grid-cols-3 gap-4 pb-32">
                {CATEGORIES.map(cat => (
                    <CategoryCard key={cat.id} category={cat} onClick={setActiveView} />
                ))}
            </main>
        </div>
    );
};

export default DirectoryView;
