
import React from 'react';
import { View } from '../types';

interface ProviderOnboardingViewProps {
  setActiveView: (view: View) => void;
}

const ProviderOnboardingView: React.FC<ProviderOnboardingViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex min-h-screen w-full flex-col overflow-x-hidden font-display bg-background-light dark:bg-background-dark text-[#111317] dark:text-white">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center p-4 justify-between max-w-md mx-auto w-full">
            <button onClick={() => setActiveView('ecommerce')} className="flex items-center justify-center size-10 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer">
                <span className="material-symbols-outlined">arrow_back_ios_new</span>
            </button>
            <div className="flex flex-col items-center">
                <h2 className="text-lg font-bold leading-tight tracking-tight">Onboarding</h2>
                <span className="text-[10px] uppercase tracking-widest text-primary font-extrabold">CFH Market</span>
            </div>
            <div className="size-10 flex items-center justify-center">
                <span className="material-symbols-outlined text-emerald">verified_user</span>
            </div>
        </div>
        <div className="flex w-full px-4 pb-4 gap-2 max-w-md mx-auto">
            <div className="h-1.5 flex-1 rounded-full bg-primary"></div>
            <div className="h-1.5 flex-1 rounded-full bg-primary/20 dark:bg-gray-700"></div>
            <div className="h-1.5 flex-1 rounded-full bg-primary/20 dark:bg-gray-700"></div>
            <div className="h-1.5 flex-1 rounded-full bg-primary/20 dark:bg-gray-700"></div>
        </div>
      </header>
      <main className="flex-1 max-w-md mx-auto w-full pb-32">
        <section className="px-6 py-8">
            <h3 className="text-3xl font-extrabold tracking-tight mb-2">Choose Your Path</h3>
            <div className="grid grid-cols-1 gap-4">
                <div className="group relative overflow-hidden rounded-xl border-2 border-emerald bg-card-light dark:bg-card-dark p-6 transition-all active:scale-95 shadow-lg shadow-emerald/5">
                    <h4 className="text-xl font-bold text-emerald">Local Farmer</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Supply fresh, organic produce directly from your farm.</p>
                </div>
                <div className="group relative overflow-hidden rounded-xl border border-gray-200 dark:border-gray-800 bg-card-light dark:bg-card-dark p-6 transition-all active:scale-95">
                    <h4 className="text-xl font-bold text-primary">Handicraft Artisan</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Showcase your unique handmade creations.</p>
                </div>
            </div>
        </section>
      </main>
      <footer className="fixed bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-background-light dark:from-background-dark via-background-light dark:via-background-dark to-transparent">
        <div className="max-w-md mx-auto">
            <button className="w-full bg-primary text-white font-extrabold py-4 rounded-xl shadow-xl shadow-primary/25 active:scale-95 transition-transform flex items-center justify-center gap-2">
                    CONTINUE
                    <span className="material-symbols-outlined text-sm">arrow_forward</span>
            </button>
        </div>
      </footer>
    </div>
  );
};

export default ProviderOnboardingView;
