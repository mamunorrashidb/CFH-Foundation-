
import React from 'react';
import { View } from '../types';

interface NewsletterSignupViewProps {
  setActiveView: (view: View) => void;
}

const NewsletterSignupView: React.FC<NewsletterSignupViewProps> = ({ setActiveView }) => {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-black/10 backdrop-blur-sm">
      <div className="relative w-full max-w-[400px] overflow-hidden rounded-xl bg-background-light dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800">
        <div className="relative h-56 w-full">
            <div className="h-full w-full bg-center bg-cover" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDKuYIJsbjLc_7viE3atKPFRjg7zT10ASSILtUFlSJsgFQpFu4DIvqzQUgXmqaUoykG7p7iQa__Dn6SPo2g9w_Ytjb9AgsfL0DzSye95UJOFlCjpPJmxaWtkwKbWNr1j_m5ZtcKbFzSPARJVEMKWr1U5O2pTaBujnOV_z8lOGPiFu6TmExD7Iedkrs6AojEVIWIm_-yp6Zg1DdB9oeMaOHpzxa__SV1jU5-LihhLDMxq4vp2wNnOJ-zdUaoffPUAKA_CrXDXksJYpFv')"}}></div>
             <button onClick={() => setActiveView('dashboard')} className="absolute top-4 right-4 h-8 w-8 rounded-full bg-black/20 backdrop-blur-md flex items-center justify-center text-white">
                <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
        </div>
        <div className="flex flex-col px-6 pt-6 pb-8">
            <h1 className="text-slate-900 dark:text-white tracking-tight text-[28px] font-bold leading-tight text-center pb-2">Stay in the Light</h1>
            <input className="form-input w-full rounded-lg text-slate-900 dark:text-white border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 h-12 pl-12 pr-4 mt-6" placeholder="Enter your email address" type="email" />
            <button className="w-full h-12 bg-primary text-white font-bold rounded-lg shadow-lg mt-4">Subscribe</button>
        </div>
      </div>
    </div>
  );
};

export default NewsletterSignupView;
