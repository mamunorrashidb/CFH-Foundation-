
import React, { useState, useEffect } from 'react';
import { SdgProject, View } from '../types';
import { fetchSdgProjects, saveSdgProject } from '../services/apiService';

interface SdgProjectsViewProps {
  setActiveView: (view: View) => void;
}

const statusColors: { [key: string]: string } = {
    'Ongoing': 'bg-blue-500',
    'Completed': 'bg-cfh-emerald-green',
    'Planning': 'bg-yellow-500',
    'On-Hold': 'bg-gray-500',
};

const ProjectCard: React.FC<{ project: SdgProject, onEdit: (project: SdgProject) => void }> = ({ project, onEdit }) => {
    const progress = project.target_goal ? (project.current_progress / project.target_goal) * 100 : 0;
    
    return (
        <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
            <div className="flex justify-between items-start">
                <h3 className="text-xl font-bold text-cfh-royal-blue">{project.title}</h3>
                <span className={`px-3 py-1 text-xs font-semibold text-white rounded-full ${statusColors[project.status]}`}>{project.status}</span>
            </div>
            <p className="text-gray-600 my-3">{project.description}</p>
            {project.target_goal && (
                <div>
                    <div className="flex justify-between text-sm font-medium text-gray-700 mb-1">
                        <span>অগ্রগতি</span>
                        <span>{`${project.current_progress} / ${project.target_goal} ${project.goal_unit || ''}`}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-cfh-emerald-green h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                    </div>
                </div>
            )}
            <div className="text-right mt-4">
                 <button onClick={() => onEdit(project)} className="text-sm font-semibold text-cfh-royal-blue hover:underline">প্রকল্প পরিচালনা করুন</button>
            </div>
        </div>
    );
};

const ProjectFormModal: React.FC<{ project: Partial<SdgProject> | null, onClose: () => void, onSave: () => void }> = ({ project, onClose, onSave }) => {
    const [formData, setFormData] = useState<Partial<SdgProject> | null>(project);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        setFormData(project);
    }, [project]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => prev ? { ...prev, [name]: value } : null);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData || !formData.title || !formData.description) {
            setError('শিরোনাম এবং বর্ণনা প্রয়োজন।');
            return;
        }
        setIsLoading(true);
        setError('');
        try {
            const response = await saveSdgProject(formData);
            if (response.status === 'success') {
                onSave();
            } else {
                setError(response.message || 'একটি ত্রুটি ঘটেছে।');
            }
        } catch (err) {
            setError((err as Error).message);
        } finally {
            setIsLoading(false);
        }
    };

    if (!project) return null;

    return (
         <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg animate-fade-in">
                <h3 className="text-2xl font-bold text-cfh-royal-blue mb-4">{project.id ? 'প্রকল্প সম্পাদনা করুন' : 'নতুন প্রকল্প যোগ করুন'}</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="title" className="block text-sm font-medium text-gray-700">প্রকল্পের শিরোনাম</label>
                        <input type="text" name="title" value={formData?.title || ''} onChange={handleChange} className="mt-1 block w-full input-style" required />
                    </div>
                    <div>
                        <label htmlFor="description" className="block text-sm font-medium text-gray-700">সংক্ষিপ্ত বর্ণনা</label>
                        <textarea name="description" value={formData?.description || ''} onChange={handleChange} rows={3} className="mt-1 block w-full input-style" required></textarea>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="status" className="block text-sm font-medium text-gray-700">স্ট্যাটাস</label>
                            <select name="status" value={formData?.status || 'Planning'} onChange={handleChange} className="mt-1 block w-full input-style">
                                <option>Planning</option>
                                <option>Ongoing</option>
                                <option>Completed</option>
                                <option>On-Hold</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="goal_unit" className="block text-sm font-medium text-gray-700">লক্ষ্যের একক</label>
                            <input type="text" name="goal_unit" value={formData?.goal_unit || ''} onChange={handleChange} placeholder="যেমন, গাছ, পরিবার" className="mt-1 block w-full input-style" />
                        </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="current_progress" className="block text-sm font-medium text-gray-700">বর্তমান অগ্রগতি</label>
                            <input type="number" name="current_progress" value={formData?.current_progress || 0} onChange={handleChange} className="mt-1 block w-full input-style" />
                        </div>
                        <div>
                            <label htmlFor="target_goal" className="block text-sm font-medium text-gray-700">লক্ষ্যমাত্রা</label>
                            <input type="number" name="target_goal" value={formData?.target_goal || ''} onChange={handleChange} className="mt-1 block w-full input-style" />
                        </div>
                    </div>

                    {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                    
                    <div className="flex justify-end gap-4 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg">বাতিল</button>
                        <button type="submit" disabled={isLoading} className="px-4 py-2 bg-cfh-royal-blue text-white rounded-lg disabled:bg-gray-400">
                            {isLoading ? 'সংরক্ষণ করা হচ্ছে...' : 'প্রকল্প সংরক্ষণ করুন'}
                        </button>
                    </div>
                </form>
            </div>
             <style>{`.input-style { border: 1px solid #D1D5DB; border-radius: 0.5rem; padding: 0.5rem 0.75rem; width: 100%; }`}</style>
        </div>
    );
};


const SdgProjectsView: React.FC<SdgProjectsViewProps> = ({ setActiveView }) => {
    const [projects, setProjects] = useState<SdgProject[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');
    const [editingProject, setEditingProject] = useState<Partial<SdgProject> | null>(null);

    const loadProjects = async () => {
        setIsLoading(true);
        setError('');
        try {
            const response = await fetchSdgProjects();
            if (response.status === 'success') {
                setProjects(response.data);
            } else {
                setError(response.message);
            }
        } catch (err) {
            setError((err as Error).message);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        loadProjects();
    }, []);

    const handleSave = () => {
        setEditingProject(null);
        loadProjects(); // Reload projects after saving
    };

    const handleAddNew = () => {
        setEditingProject({
            title: '',
            description: '',
            status: 'Planning',
            current_progress: 0,
            target_goal: 0,
            goal_unit: ''
        });
    };

    return (
        <div className="container mx-auto px-4 animate-fade-in">
             <ProjectFormModal project={editingProject} onClose={() => setEditingProject(null)} onSave={handleSave} />
            <div className="flex justify-between items-center my-8">
                <div>
                    <h2 className="text-3xl font-bold text-cfh-royal-blue">SDG প্রকল্প ব্যবস্থাপনা</h2>
                    <p className="text-gray-600 mt-2">আমাদের টেকসই উন্নয়ন উদ্যোগগুলি ট্র্যাক এবং পরিচালনা করুন।</p>
                </div>
                <button onClick={handleAddNew} className="px-4 py-2 bg-cfh-emerald-green text-white font-semibold rounded-lg shadow-md hover:bg-green-600 transition-colors">
                    + নতুন প্রকল্প
                </button>
            </div>
             <div className="my-4">
                <button onClick={() => setActiveView('project-funding-tracker')} className="w-full bg-primary text-white font-bold py-3 rounded-lg shadow-md flex items-center justify-center gap-2">
                    <span className="material-symbols-outlined">monitoring</span>
                    View Funding Tracker
                </button>
            </div>

            {isLoading && <p className="text-center">প্রকল্প লোড হচ্ছে...</p>}
            {error && <p className="text-center text-red-500">{error}</p>}

            {!isLoading && !error && (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {projects.map(project => (
                        <ProjectCard key={project.id} project={project} onEdit={setEditingProject} />
                    ))}
                </div>
            )}
        </div>
    );
};

export default SdgProjectsView;
