
import React, { useRef } from 'react';
import { View } from '../types';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface ShopnoGoriCertificateViewProps {
  setActiveView: (view: View) => void;
  studentName?: string;
  courseName?: string;
}

const ShopnoGoriCertificateView: React.FC<ShopnoGoriCertificateViewProps> = ({ setActiveView, studentName = 'শিক্ষার্থী', courseName = 'কোর্স' }) => {
  const certificateRef = useRef<HTMLDivElement>(null);

  const handleDownload = async () => {
    if (certificateRef.current) {
        const canvas = await html2canvas(certificateRef.current, { scale: 3, useCORS: true });
        const imgData = canvas.toDataURL('image/png');
        
        // Calculate PDF dimensions to match canvas aspect ratio
        const pdfWidth = 297; // A4 landscape width in mm
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
        
        const pdf = new jsPDF({
            orientation: 'landscape',
            unit: 'mm',
            format: [pdfWidth, pdfHeight]
        });
        
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save(`CFH_ShopnoGori_Certificate_${studentName.replace(/ /g, '_')}.pdf`);
    }
  };


  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between p-4 h-16 max-w-md mx-auto">
          <div className="flex items-center gap-2">
            <button onClick={() => setActiveView('shopno-gori-reader')} className="material-symbols-outlined text-primary cursor-pointer">arrow_back</button>
            <span className="font-bold text-sm tracking-tight uppercase">Verified Certificate</span>
          </div>
          <button onClick={handleDownload} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
             <span className="material-symbols-outlined">ios_share</span>
          </button>
        </div>
      </header>
      <main className="flex-1 w-full max-w-md mx-auto p-4 pb-24 flex items-center">
        <div ref={certificateRef} className="relative bg-white dark:bg-slate-900 shadow-2xl rounded-2xl overflow-hidden border-4 border-primary/20 w-full">
          <div className="relative p-6 flex flex-col items-center text-center">
            <div className="mb-6">
                <div className="size-16 bg-primary rounded-full flex items-center justify-center text-white mb-2">
                    <span className="material-symbols-outlined text-4xl">workspace_premium</span>
                </div>
                <h1 className="text-primary dark:text-white text-xl font-bold leading-none tracking-tight font-bengali">
                    স্বপ্নগড়ি প্রকল্প
                </h1>
                <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Self-Reliance Project</p>
            </div>
            
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">This is to certify that</p>
            <h2 className="text-2xl font-bold text-primary dark:text-accent-amber border-b-2 border-primary/10 pb-2 inline-block px-4 mb-4 font-bengali">
                {studentName}
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">has successfully completed the</p>
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 font-bengali">
                {courseName}
            </h3>
             <p className="text-xs text-gray-500 mt-1">{courseName === 'বেসিক কেক বেকিং কোর্স' ? 'Basic Cake Baking Course' : ''}</p>

            <div className="mt-8 flex justify-between w-full items-end">
                <div className="text-left">
                    <p className="text-[10px] text-gray-400">Date Issued</p>
                    <p className="text-xs font-semibold">{new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                </div>
                <div className="text-right">
                    <p className="text-[10px] text-gray-400">Certificate ID</p>
                    <p className="text-xs font-semibold">CFH-SG-24-001</p>
                </div>
            </div>
          </div>
        </div>
      </main>
      <nav className="fixed bottom-0 left-0 right-0 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800 pb-8 pt-2">
        <div className="max-w-md mx-auto flex justify-around items-center px-4">
          <button onClick={handleDownload} className="flex flex-col items-center gap-1 group">
            <div className="p-3 rounded-xl bg-primary text-white shadow-lg shadow-primary/20">
              <span className="material-symbols-outlined text-[22px]">file_download</span>
            </div>
            <span className="text-xs font-bold text-primary">Download PDF</span>
          </button>
        </div>
      </nav>
    </div>
  );
};

export default ShopnoGoriCertificateView;
