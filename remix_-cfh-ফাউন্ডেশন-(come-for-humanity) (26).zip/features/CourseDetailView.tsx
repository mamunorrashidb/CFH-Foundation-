
import React from 'react';
import { View } from '../types';

interface CourseDetailViewProps {
  setActiveView: (view: View) => void;
}

const CourseDetailView: React.FC<CourseDetailViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-dark font-display text-white selection:bg-primary/30 max-w-md mx-auto">
      <header className="sticky top-0 z-50 bg-background-dark/80 backdrop-blur-md border-b border-primary/10">
        <div className="flex items-center justify-between p-4 h-16">
          <div className="flex items-center gap-3">
            <button onClick={() => setActiveView('gamification-hub')} className="size-10 rounded-lg bg-primary flex items-center justify-center"><span className="material-symbols-outlined text-white text-2xl">arrow_back</span></button>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-white uppercase leading-none">CFH IT School</h1>
              <p className="text-[10px] text-primary font-medium tracking-widest uppercase mt-0.5">Safe Internet Module</p>
            </div>
          </div>
        </div>
      </header>
      <main className="pb-24">
        <div className="relative w-full aspect-video group overflow-hidden bg-black">
          <div className="absolute inset-0 bg-cover bg-center opacity-70" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuBbrB1qWPx96LkvR9CmhuqZgZqbuokAaBbvRtNf_36j-7KCTO_-BwYiAS2TwCxbWSNORI3xh4CAJwlbRee1QW67kqPyHUqiWjCSBlpLUjk8vQ7_e7lOkBkK1N5HcgTdvVgxZIiGe2KCkTmCbC2l24qYUm8aV0SvIy6U07l0mqQ_KnD-DxFuIoiiRHYTHNqD0Yxsh2KTnIuYH7joEyGOcMmiM3jrSn32Z4IBs10bsSzh3TUaM0zRudMUjCPUfCegDP-mlvQ5N3DTHmAF')"}}></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 flex flex-col justify-between p-4">
            <div></div>
            <div className="flex flex-col items-center"><button className="size-16 rounded-full bg-primary/90 text-white flex items-center justify-center border-4 border-white/10"><span className="material-symbols-outlined text-4xl fill-1">play_arrow</span></button><p className="mt-4 text-white font-bold text-center drop-shadow-md">Workshop: Safe Internet Practices<br/><span className="font-normal opacity-90 text-sm">সেফ ইন্টারনেট প্র্যাকটিস ওয়ার্কশপ</span></p></div>
            <div className="space-y-2"><div className="flex h-1 w-full bg-white/20 rounded-full overflow-hidden"><div className="h-full bg-primary w-[37%]"></div></div><div className="flex justify-between items-center text-[10px] font-medium text-white/70"><span>12:45</span><span>34:20</span></div></div>
          </div>
        </div>
        <div className="p-6 bg-surface-dark border-y border-white/5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex flex-col"><h3 className="text-white text-sm font-bold leading-tight">Certificate Progress / কোর্সের অগ্রগতি</h3><p className="text-xs text-white/50 mt-0.5">Complete all lessons to unlock certificate</p></div>
            <div className="text-right"><p className="text-xl font-bold text-primary">45%</p></div>
          </div>
          <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden"><div className="h-full bg-primary rounded-full" style={{width: '45%'}}></div></div>
           <button onClick={() => setActiveView('raw-nest-it-certificate')} className="mt-4 w-full bg-primary/20 text-primary font-bold py-2 rounded-lg text-xs">View Certificate</button>
        </div>
        <div className="px-4 py-6 space-y-4">
          <h2 className="text-xs font-bold text-white/40 uppercase tracking-[0.2em] px-2">Module Lessons / মডিউল পাঠ</h2>
          <div className="bg-white/5 rounded-xl p-4 flex items-center gap-4"><div className="size-12 rounded-lg bg-success/20 border border-success/30 flex items-center justify-center shrink-0"><span className="material-symbols-outlined text-success">check_circle</span></div><div className="flex-1 min-w-0"><h4 className="text-white font-medium text-sm leading-snug line-clamp-1">Protecting Your Data</h4><p className="text-white/50 text-xs font-normal mt-0.5">আপনার তথ্য সুরক্ষিত রাখা • 15 min</p></div></div>
          <div className="bg-primary/5 rounded-xl p-4 flex items-center gap-4 border border-primary/60"><div className="size-12 rounded-lg bg-primary flex items-center justify-center shrink-0"><span className="material-symbols-outlined text-white">visibility</span></div><div className="flex-1 min-w-0"><div className="flex items-center gap-2 mb-0.5"><span className="text-[8px] bg-primary text-white px-1.5 py-0.5 rounded-full font-bold uppercase tracking-widest">Current</span><h4 className="text-white font-medium text-sm leading-snug line-clamp-1">Identifying Scams</h4></div><p className="text-white/50 text-xs font-normal">প্রতারণা শনাক্ত করা • 12 min</p></div></div>
        </div>
      </main>
    </div>
  );
};

export default CourseDetailView;
