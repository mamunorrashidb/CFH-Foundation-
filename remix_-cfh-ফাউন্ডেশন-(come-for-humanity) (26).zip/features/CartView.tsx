
import React from 'react';
import { View, CartItem } from '../types';

interface CartViewProps {
    setActiveView: (view: View, props?: any) => void;
    cart: CartItem[];
    updateCartQuantity: (productId: number, quantity: number) => void;
    clearCart: () => void;
}

const CartView: React.FC<CartViewProps> = ({ setActiveView, cart, updateCartQuantity, clearCart }) => {
    
    const subtotal = cart.reduce((sum, item) => sum + (parseFloat(item.price) * item.quantity), 0);
    const deliveryFee = 50;
    const total = subtotal + deliveryFee;

    const handleCheckout = () => {
        // In a real app, this would navigate to a checkout page with forms
        // For now, it will simulate an order and go to confirmation
        if(cart.length > 0) {
            const mockOrderDetails = {
                orderId: `CFH-${Date.now()}`,
                product: cart[0] // Simplify for now
            };
            setActiveView('order-confirmation', mockOrderDetails);
            clearCart();
        } else {
            alert("Your cart is empty!");
        }
    }

    return (
        <div className="bg-background-light dark:bg-background-dark min-h-screen pb-40">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
                <button onClick={() => setActiveView('ecommerce')} className="size-10 flex items-center justify-center -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>
                <h1 className="text-lg font-bold font-bengali">শপিং কার্ট</h1>
                <div className="w-10"></div>
            </header>

            <main className="p-4">
                {cart.length === 0 ? (
                    <div className="text-center py-20">
                        <span className="material-symbols-outlined text-6xl text-gray-300 dark:text-gray-600">shopping_bag</span>
                        <p className="mt-4 text-gray-500 font-bengali">আপনার কার্ট খালি</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {cart.map(item => (
                            <div key={item.id} className="bg-white dark:bg-card-dark p-3 rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 flex items-center gap-4">
                                <img src={item.image} alt={item.name} className="size-20 rounded-lg object-cover" />
                                <div className="flex-1">
                                    <h3 className="font-bold text-sm text-gray-800 dark:text-white font-bengali">{item.name}</h3>
                                    <p className="font-extrabold text-primary text-md font-bengali mt-1">৳{item.price}</p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <button onClick={() => updateCartQuantity(item.id, item.quantity - 1)} className="size-8 bg-gray-100 dark:bg-gray-700 rounded-full font-bold">-</button>
                                    <span className="w-6 text-center font-bold">{item.quantity}</span>
                                    <button onClick={() => updateCartQuantity(item.id, item.quantity + 1)} className="size-8 bg-gray-100 dark:bg-gray-700 rounded-full font-bold">+</button>
                                </div>
                            </div>
                        ))}

                        <div className="bg-white dark:bg-card-dark rounded-xl p-5 border border-gray-100 dark:border-gray-800 shadow-sm mt-6 space-y-3">
                            <h3 className="font-bold font-bengali mb-2">মূল্য বিবরণ</h3>
                            <div className="flex justify-between text-sm"><span className="text-gray-600 dark:text-gray-400 font-bengali">সাবটোটাল</span><span className="font-medium font-bengali">৳{subtotal.toFixed(2)}</span></div>
                            <div className="flex justify-between text-sm"><span className="text-gray-600 dark:text-gray-400 font-bengali">ডেলিভারি ফি</span><span className="font-medium font-bengali">৳{deliveryFee.toFixed(2)}</span></div>
                            <div className="border-t border-gray-100 dark:border-gray-700 pt-3 mt-3 flex justify-between items-center font-bold">
                                <span className="font-bengali">সর্বমোট</span>
                                <span className="text-primary text-xl font-bengali">৳{total.toFixed(2)}</span>
                            </div>
                        </div>
                    </div>
                )}
            </main>
            
            {cart.length > 0 && (
                <footer className="fixed bottom-0 left-0 right-0 p-4 bg-white/80 dark:bg-background-dark/80 backdrop-blur-xl border-t border-gray-100 dark:border-gray-800 z-50">
                    <div className="max-w-md mx-auto">
                        <button onClick={handleCheckout} className="w-full h-14 bg-primary text-white rounded-xl font-bold text-lg shadow-lg shadow-primary/30 active:scale-95 transition-transform font-bengali">
                            চেকআউট করুন
                        </button>
                    </div>
                </footer>
            )}
        </div>
    );
};

export default CartView;
