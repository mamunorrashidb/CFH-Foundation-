import React from 'react';
import { View } from '../types';

interface OnlineLibraryReaderViewProps {
  setActiveView: (view: View) => void;
}

const OnlineLibraryReaderView: React.FC<OnlineLibraryReaderViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-white dark:bg-[#121212] text-[#121517] dark:text-gray-100 max-w-md mx-auto">
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 dark:bg-[#121212]/90 backdrop-blur-md border-b border-gray-100 dark:border-gray-800 max-w-md mx-auto">
        <div className="flex items-center p-4 h-16">
          <button onClick={() => setActiveView('gamification-hub')} className="p-2 -ml-2"><span className="material-symbols-outlined">arrow_back</span></button>
          <div className="flex items-center gap-3 flex-1 overflow-hidden ml-4">
            <div className="flex flex-col min-w-0">
              <h1 className="text-sm font-bold truncate leading-tight">The Great Gatsby</h1>
              <h2 className="text-gray-500 dark:text-gray-400 text-xs truncate font-bengali">দ্য গ্রেট গেটসবি</h2>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button aria-label="Bookmark" className="p-2 text-[#008060]"><span className="material-symbols-outlined fill-1">bookmark</span></button>
          </div>
        </div>
      </header>
      
      <main className="pt-24 pb-48 px-6 min-h-screen">
        <div className="font-serif text-lg md:text-xl space-y-8" style={{lineHeight: 1.8, letterSpacing: '0.01em'}}>
          <p>In my younger and more vulnerable years my father gave me some advice that I've been turning over in my mind ever since.</p>
          <p className="font-bengali text-[#1a4f7a] dark:text-[#1a4f7a]/80 italic border-l-2 border-[#1a4f7a]/20 pl-4" style={{lineHeight: 2}}>আমার অল্প বয়সে যখন আমি কিছুটা বেশি সংবেদনশীল ছিলাম, আমার বাবা আমাকে এমন কিছু উপদেশ দিয়েছিলেন যা আমি সেই সময় থেকে আজ পর্যন্ত মনের ভেতর গেঁথে রেখেছি।</p>
          <p>'Whenever you feel like criticizing anyone,' he told me, 'just remember that all the people in this world haven't had the advantages that you've had.'</p>
        </div>
      </main>

      <div className="fixed bottom-6 left-4 right-4 z-40 flex flex-col items-center max-w-md mx-auto">
        <div className="w-full max-w-lg shadow-xl border border-gray-100 dark:border-gray-800 rounded-xl p-4 space-y-4 bg-white/95 dark:bg-[#121212]/95 backdrop-blur-sm">
            <div className="space-y-2">
                <div className="flex justify-between items-end"><span className="text-xs font-bold uppercase tracking-wider text-gray-400">Reading Progress</span><span className="text-sm font-bold text-[#008060]">45%</span></div>
                <div className="h-1.5 w-full bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden"><div className="h-full bg-[#008060] rounded-full" style={{width: "45%"}}></div></div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default OnlineLibraryReaderView;