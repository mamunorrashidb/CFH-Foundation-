import React from 'react';
import { View } from '../types';

interface SpiritualJournalViewProps {
  setActiveView: (view: View) => void;
}

const SpiritualJournalView: React.FC<SpiritualJournalViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-[#111318] dark:text-white min-h-screen pb-32">
      <nav className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center p-4 justify-between max-w-xl mx-auto">
          <button onClick={() => setActiveView('gamification-hub')} className="flex size-10 shrink-0 items-center justify-center bg-primary rounded-xl">
            <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-lg size-7" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuBgbTLIIMY-RAKwV-LkpFLKD3l8_1sivVBqyE5lq6xtONdZOwdF9rOtTm_6rWW1D4ack6z-WuH_t-iB2GI1eQYXR9h9YrgzbkxjqYqQgBdsbXM45yW9IIxBwHbHiTuoiphpkHNUrsAACTctmwS9rGHn65lSkNQDbCSM20qKLXNgMtwyV3xB3q9OJWgbp_cGW-gGOhkwkWy9lfGnpGhV02XZmrFBXOT3g8mG9Ct3QnrZV5Y3Clioiq4mHLXmEAeH7mnFSso19KafEgBo')"}}></div>
          </button>
          <div className="flex-1 px-4">
            <h2 className="text-[#111318] dark:text-white text-lg font-extrabold leading-tight tracking-tight">Prayer Board</h2>
            <p className="text-[10px] uppercase tracking-widest text-primary font-bold">CFH Spiritual Centre</p>
          </div>
        </div>
      </nav>
      
      <main className="max-w-xl mx-auto px-4 space-y-4">
        <div className="flex items-center justify-between pt-2">
          <h3 className="text-[#111318] dark:text-white text-base font-bold">Recent Requests</h3>
        </div>
        <div className="bg-white dark:bg-[#1c222b] rounded-xl p-5 prayer-card-shadow border border-gray-100 dark:border-gray-800">
          <div className="space-y-2 mb-6">
            <h4 className="text-[#111318] dark:text-white text-lg font-bold leading-snug">Healing for my mother</h4>
            <h4 className="text-[#111318]/70 dark:text-white/70 text-base font-medium leading-snug font-bengali">আমার মায়ের আরোগ্য কামনায়</h4>
          </div>
          <div className="flex items-center justify-between gap-4">
            <p className="text-xs text-gray-500 font-medium italic">12 community members are praying</p>
            <button className="flex items-center gap-2 px-4 py-2 bg-emerald-action hover:bg-emerald-600 text-white rounded-lg transition-colors shadow-sm">
              <span className="material-symbols-outlined text-lg">folded_hands</span>
              <span className="text-sm font-bold truncate">Praying</span>
            </button>
          </div>
        </div>
      </main>

      <div className="fixed bottom-10 right-10 z-50">
          <button className="flex items-center gap-3 bg-primary text-white px-6 py-4 rounded-full shadow-2xl hover:scale-105 transition-transform">
            <span className="material-symbols-outlined">add_circle</span>
            <span className="text-base font-bold tracking-tight uppercase">Post a Request</span>
          </button>
      </div>
      <style>{`.prayer-card-shadow { box-shadow: 0 2px 12px -2px rgba(0, 0, 0, 0.05); }`}</style>
    </div>
  );
};

export default SpiritualJournalView;