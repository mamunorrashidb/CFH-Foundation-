
import React, { useState } from 'react';
import { View } from '../types';
import { placeOrder } from '../services/apiService';

interface Product {
  id: number;
  name: string;
  price: string;
  image: string;
}

interface ShopnoGoriProductDetailViewProps {
  setActiveView: (view: View, props?: any) => void;
  product: Product;
}

const ShopnoGoriProductDetailView: React.FC<ShopnoGoriProductDetailViewProps> = ({ setActiveView, product }) => {
  const [isOrdering, setIsOrdering] = useState(false);

  if (!product) {
      return (
        <div className="flex h-screen items-center justify-center">
            <p>Product not found. Please go back.</p>
            <button onClick={() => setActiveView('ecommerce')}>Go Back</button>
        </div>
      );
  }

  const handleOrder = async () => {
        setIsOrdering(true);
        try {
            const orderData = {
                customerId: 1, // Mock customer ID
                totalAmount: parseFloat(product.price),
                shippingAddress: '123 CFH Road, Meherpur',
                cart: [{ id: product.id, quantity: 1, price: product.price }],
            };
            const response = await placeOrder(orderData);
            if (response.status === 'success') {
                setActiveView('order-confirmation', { orderId: response.data.orderId, product: product });
            } else {
                alert('Order failed: ' + response.message);
            }
        } catch (error) {
            alert('An error occurred while placing the order.');
            console.error(error);
        } finally {
            setIsOrdering(false);
        }
    };


  return (
    <div className="bg-background-light dark:bg-background-dark text-[#101815] dark:text-white min-h-screen">
      <header className="sticky top-0 z-50 flex items-center bg-white/80 dark:bg-background-dark/80 backdrop-blur-md p-4 justify-between border-b border-gray-100 dark:border-gray-800">
        <button onClick={() => setActiveView('ecommerce')} className="text-[#101815] dark:text-white flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer -ml-2">
          <span className="material-symbols-outlined">arrow_back_ios_new</span>
        </button>
        <h2 className="text-lg font-bold leading-tight tracking-tight flex-1 text-center pr-10 font-bengali">পণ্যের বিবরণ</h2>
      </header>
      
      <main className="pb-32">
        <div className="relative aspect-square bg-cover bg-center" style={{backgroundImage: `url('${product.image}')`}}>
        </div>
        
        <div className="p-5 space-y-4">
            <h1 className="text-2xl font-bold leading-tight font-bengali">{product.name}</h1>
            
            <p className="text-3xl font-extrabold text-primary font-bengali">৳{product.price}</p>

            <div className="bg-primary/5 dark:bg-primary/10 rounded-xl p-4 border border-primary/20">
                 <p className="text-sm text-primary dark:text-primary/90 font-bengali">এই পণ্যটি কিনে আপনি সরাসরি একজন গ্রামীণ কারিগরকে আর্থিকভাবে স্বচ্ছল হতে সাহায্য করছেন। স্বপ্নগড়ি উদ্যোগের মাধ্যমে আমরা নারীদের ক্ষমতায়ন এবং তাদের তৈরি ঐতিহ্যবাহী হস্তশিল্প বিশ্বজুড়ে ছড়িয়ে দেওয়ার জন্য কাজ করছি।</p>
            </div>
            
            <div>
                <h3 className="text-base font-bold mb-2 font-bengali">বিস্তারিত</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed font-bengali">
                    সম্পূর্ণ হাতে বোনা এবং প্রাকৃতিক রঙে রাঙানো এই সিল্ক শালটি ঐতিহ্য ও আধুনিকতার এক দারুণ মিশ্রণ। প্রতিটি কাঁথার ফোঁড়ে রয়েছে বাংলার গ্রামীণ নারীদের মমতা ও দক্ষতার ছোঁয়া। এটি যেকোনো অনুষ্ঠানে ব্যবহারের জন্য উপযুক্ত এবং প্রিয়জনকে উপহার দেওয়ার জন্য অনন্য।
                </p>
            </div>
        </div>
      </main>
      
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/80 dark:bg-background-dark/80 backdrop-blur-xl border-t border-gray-100 dark:border-gray-800 z-[100]">
        <div className="flex gap-4 max-w-md mx-auto">
          <button 
            onClick={handleOrder}
            disabled={isOrdering}
            className="flex-1 bg-primary text-white font-display font-bold text-base py-4 rounded-xl shadow-lg shadow-primary/30 active:scale-95 transition-transform font-bengali disabled:bg-primary/50"
          >
            {isOrdering ? 'অর্ডার করা হচ্ছে...' : 'অর্ডার করুন (ক্যাশ অন ডেলিভারি)'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ShopnoGoriProductDetailView;
