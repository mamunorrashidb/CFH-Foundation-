import React from 'react';
import { View } from '../types';

interface VolunteerTrainingViewProps {
  setActiveView: (view: View) => void;
}

const VolunteerTrainingView: React.FC<VolunteerTrainingViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-[#111318] dark:text-white antialiased max-w-md mx-auto min-h-screen">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center p-4 justify-between">
          <button onClick={() => setActiveView('gamification-hub')} className="flex items-center gap-3">
            <span className="material-symbols-outlined text-[#111318] dark:text-white cursor-pointer">arrow_back_ios</span>
            <h2 className="text-lg font-extrabold leading-tight tracking-tight text-primary">Volunteer Training</h2>
          </button>
        </div>
      </header>
      <main className="pb-32">
        <div className="p-4 space-y-2">
            <h3 className="text-base font-bold text-primary">Module 1: Humanitarian Protocols</h3>
            <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full" style={{ width: '20%' }}></div>
            </div>
        </div>
        <div className="px-4 py-2">
            <div className="relative aspect-video bg-black flex items-center justify-center group cursor-pointer rounded-xl overflow-hidden">
                <img alt="Humanitarian relief efforts" className="absolute inset-0 w-full h-full object-cover opacity-60" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBPwycxLzXRINsrYoslHsnEf6H6X33-ntlIpH-FI5MaD6Ge-uIu_9pouGfLbHmCbYBnkBPvOSzOOBt0IQ9VRLcUXzU-NLuYmZ1I2Ba0Veaiqeccr3ngWmuBrCdWM_QXP66eo27FKvoXz-jGnSRDGzRAQ_azyhXOpChOFzFQrfgZQfE2QH47jRT0xNiz9JF5h__0BJAOAFblnKirYAVrAdsI5CbCP9En__fP_NcxAMl5lExzxSayoAwvGlrQr7eWC7AVT8r_XheUgOIs"/>
                <button className="relative z-10 flex items-center justify-center rounded-full size-16 bg-white/20 backdrop-blur-md text-white border border-white/30"><span className="material-symbols-outlined text-4xl fill-1">play_arrow</span></button>
            </div>
        </div>
      </main>
      <div className="fixed bottom-0 inset-x-0 z-50 max-w-md mx-auto">
        <div className="bg-white/80 dark:bg-background-dark/80 backdrop-blur-xl p-4 border-t border-slate-100 dark:border-slate-800">
            <button className="w-full bg-success text-white font-extrabold py-4 rounded-xl shadow-lg active:scale-[0.98] transition-all flex items-center justify-center gap-2">
                <span>Continue to Module 2</span><span className="material-symbols-outlined">arrow_forward</span>
            </button>
        </div>
      </div>
    </div>
  );
};

export default VolunteerTrainingView;