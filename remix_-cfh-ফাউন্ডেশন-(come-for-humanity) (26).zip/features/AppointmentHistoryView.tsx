import React from 'react';
import { View } from '../types';

interface AppointmentHistoryViewProps {
  setActiveView: (view: View) => void;
}

const AppointmentHistoryView: React.FC<AppointmentHistoryViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 min-h-screen pb-8">
        <nav className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center px-4 py-4 justify-between">
                <button onClick={() => setActiveView('telemedicine')} className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <span className="material-symbols-outlined text-primary font-bold">medical_services</span>
                    </div>
                    <div>
                        <h1 className="text-[#111317] dark:text-white text-base font-extrabold leading-tight">CFH</h1>
                        <p className="text-[10px] text-primary font-bold tracking-widest uppercase">Telemedicine</p>
                    </div>
                </button>
            </div>
            <div className="px-4 pb-4">
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Appointment History</h2>
                <p className="text-sm text-slate-500 dark:text-slate-400">অ্যাপয়েন্টমেন্টের ইতিহাস</p>
            </div>
        </nav>
        <main className="p-4 space-y-4">
            <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
                <div className="p-4">
                    <div className="flex justify-between items-start mb-4">
                        <div className="flex gap-3">
                            <div className="w-14 h-14 rounded-full bg-cover bg-center ring-2 ring-primary/10" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDPFWVvIEgmzRFTdkmefOhHKxu7xrwvMhzIxqcFaru3-mGrnpOri6jMMRptq7iDZa9qoHC3-HxREH7ZaMuykmlKnO683ShHlDUC00lH0pnGcoEf-ldjlRvK5llVeAL_RnTQdr6nnpWJn0BtQDqO25XLeFN0gvvY-m-qTA7If1QHozD8tm4DNZReooUFjkDTzE1KW8puSSJYgpE1Ey7C1YxXsaZkblRYhuh0YrHHcqACd9ySdkeS69qSGVyOcTcxsu_iYG2D4s4RKZV6')"}}></div>
                            <div>
                                <p className="text-primary text-xs font-bold mb-0.5">COMPLETED</p>
                                <h3 className="text-base font-bold text-slate-900 dark:text-white">Dr. Mahbubur Rahman</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
  );
};

export default AppointmentHistoryView;