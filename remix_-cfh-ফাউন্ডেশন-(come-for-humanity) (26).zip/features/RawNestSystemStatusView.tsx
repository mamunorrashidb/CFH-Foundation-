
import React from 'react';
import { View } from '../types';

interface RawNestSystemStatusViewProps {
  setActiveView: (view: View) => void;
}

const RawNestSystemStatusView: React.FC<RawNestSystemStatusViewProps> = ({ setActiveView }) => {
  return (
    <body className="bg-background-light dark:bg-background-dark font-display text-[#121317] dark:text-white min-h-screen">
      <nav className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-[#dcdfe5] dark:border-[#2d3139]">
        <div className="flex items-center justify-between p-4 max-w-lg mx-auto">
          <button onClick={() => setActiveView('developer-portal')} className="flex items-center gap-3">
            <div className="bg-primary p-1.5 rounded-lg flex items-center justify-center">
              <span className="material-symbols-outlined text-white text-2xl">nest_remote</span>
            </div>
            <h1 className="text-[#121317] dark:text-white text-lg font-bold leading-tight tracking-tight">RawNest Status</h1>
          </button>
        </div>
      </nav>
      <main className="max-w-lg mx-auto pb-20">
        <div className="p-4">
          <div className="flex flex-col items-start justify-between gap-4 rounded-xl border border-success/30 bg-success/5 p-5 dark:bg-success/10">
            <p className="text-[#121317] dark:text-white text-base font-bold leading-tight">All Systems Operational</p>
          </div>
        </div>
        <div className="px-4 py-2">
            <div className="bg-white dark:bg-[#1f2228] border border-[#dcdfe5] dark:border-[#2d3139] rounded-xl p-4">
                <div className="flex items-center justify-between mb-4">
                    <p className="text-[#121317] dark:text-white text-base font-bold">Web Hosting</p>
                    <span className="text-success text-xs font-bold">OPERATIONAL</span>
                </div>
            </div>
        </div>
      </main>
    </body>
  );
};

export default RawNestSystemStatusView;
