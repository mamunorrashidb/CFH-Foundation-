
import React from 'react';
import { View } from '../types';

interface CommitteeApplicationViewProps {
  setActiveView: (view: View) => void;
}

const CommitteeApplicationView: React.FC<CommitteeApplicationViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-[#121417] dark:text-gray-100 min-h-screen">
      <nav className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 ios-blur border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center justify-between px-4 py-3">
            <button onClick={() => setActiveView('senior-council')} className="flex items-center gap-3">
                <div className="bg-primary p-1.5 rounded-lg">
                    <span className="material-symbols-outlined text-white text-2xl">arrow_back</span>
                </div>
            </button>
          <div className="flex items-center gap-1">
            <div className="flex gap-1.5 px-3 py-1.5 bg-gray-100 dark:bg-gray-800 rounded-full">
              <div className="h-2 w-2 rounded-full bg-primary"></div>
              <div className="h-2 w-2 rounded-full bg-primary/30"></div>
              <div className="h-2 w-2 rounded-full bg-primary/30"></div>
            </div>
          </div>
          <button className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
            <span className="material-symbols-outlined text-gray-500">help_outline</span>
          </button>
        </div>
      </nav>
      <main className="max-w-md mx-auto px-4 py-6 space-y-6 pb-32">
        <header>
          <h2 className="text-2xl font-bold tracking-tight">Join Committee / কমিটিতে যোগ দিন</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Complete the form below to apply for a leadership position.</p>
        </header>
        <section className="bg-white dark:bg-gray-900 rounded-xl p-4 soft-shadow border border-gray-100 dark:border-gray-800">
          <div className="flex items-center gap-2 mb-4">
            <span className="material-symbols-outlined text-primary text-xl">layers</span>
            <h3 className="font-bold">Committee Tier / কমিটির স্তর</h3>
          </div>
          <label className="block group">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Select Target Level / লক্ষ্যমাত্রা স্তর নির্বাচন করুন</p>
            <div className="relative">
              <select className="appearance-none w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg h-14 px-4 text-base focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all">
                <option disabled selected value="">Choose a level...</option>
                <option value="intl">International / আন্তর্জাতিক</option>
                <option value="central">Central / কেন্দ্রীয়</option>
                <option value="district">District / জেলা</option>
                <option value="upazila">Upazila / উপজেলা</option>
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                <span className="material-symbols-outlined">expand_more</span>
              </div>
            </div>
          </label>
        </section>
      </main>
      <footer className="fixed bottom-0 left-0 right-0 bg-white/90 dark:bg-background-dark/90 ios-blur border-t border-gray-200 dark:border-gray-800 p-4 z-50">
        <div className="max-w-md mx-auto">
          <button className="w-full bg-primary hover:bg-primary/90 text-white h-14 rounded-xl font-bold text-lg flex items-center justify-center gap-2 shadow-lg shadow-primary/20 active:scale-[0.98] transition-all">
            Submit Application / আবেদন জমা দিন
            <span className="material-symbols-outlined">send</span>
          </button>
        </div>
      </footer>
       <style>{`.ios-blur { backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); } .soft-shadow { box-shadow: 0 4px 20px -2px rgba(0, 0, 0, 0.05); }`}</style>
    </div>
  );
};

export default CommitteeApplicationView;
