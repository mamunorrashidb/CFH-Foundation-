
import React from 'react';
import { View } from '../types';

interface EmergencyHelpViewProps {
  setActiveView: (view: View) => void;
}

const EmergencyHelpView: React.FC<EmergencyHelpViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex h-screen w-full flex-col max-w-md mx-auto overflow-hidden bg-background-dark text-white">
        <div className="flex flex-col items-center pt-8 pb-4">
            <h1 className="text-primary font-bold tracking-tighter text-2xl">CFH</h1>
        </div>
        <div className="bg-red-500 py-3 flex items-center justify-center gap-3 animate-pulse">
            <span className="material-symbols-outlined text-white text-xl">error</span>
            <h2 className="text-white text-sm font-bold leading-tight tracking-widest uppercase">CRITICAL ALERT</h2>
        </div>
        <div className="flex-1 flex flex-col px-6 pt-8 overflow-y-auto">
            <div className="text-center mb-8">
                <h3 className="text-3xl font-bold leading-tight tracking-tight">A+ Blood Needed</h3>
            </div>
             <div className="relative w-full aspect-[16/9] bg-[#1a1a1c] rounded-xl overflow-hidden border border-white/10 shadow-2xl mb-8">
            </div>
        </div>
        <div className="p-6 pb-10 flex flex-col gap-3 bg-background-dark/80 backdrop-blur-xl border-t border-white/5">
            <button className="w-full bg-green-500 text-white font-bold py-5 rounded-xl">
                Accept Mission
            </button>
            <button onClick={() => setActiveView('rapid-deployment')} className="w-full bg-primary text-white font-bold py-4 rounded-xl">
                Activate Rapid Deployment
            </button>
            <button onClick={() => setActiveView('dashboard')} className="w-full bg-[#2c2c2e] text-gray-300 font-semibold py-4 rounded-xl">
                Decline
            </button>
        </div>
    </div>
  );
};

export default EmergencyHelpView;
