
import React from 'react';
import { View } from '../types';

interface DistrictDetailViewProps {
  setActiveView: (view: View) => void;
}

const DistrictDetailView: React.FC<DistrictDetailViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-white dark:bg-[#18181b] font-display text-[#111317] dark:text-gray-100 antialiased max-w-md mx-auto">
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-zinc-900/80 backdrop-blur-md border-b border-gray-100 dark:border-zinc-800">
        <div className="flex items-center p-4 justify-between">
          <button onClick={() => setActiveView('directory')} className="w-10 h-10 flex items-center justify-center">
            <span className="material-symbols-outlined text-primary">arrow_back_ios_new</span>
          </button>
          <div><h1 className="text-lg font-bold leading-tight tracking-tight">Dhaka District</h1><p className="text-[10px] text-[#009640] font-bold tracking-widest uppercase">ঢাকা জেলা শাখা</p></div>
          <div className="w-10"></div>
        </div>
      </header>
      <main className="pb-32">
        <section className="mt-2">
          <div className="px-4 flex items-center justify-between mb-4">
            <div><h2 className="text-xl font-extrabold tracking-tight">District Committee</h2><p className="text-sm text-gray-500 font-medium">জেলা কমিটি</p></div>
          </div>
          <div className="flex overflow-x-auto gap-4 px-4 pb-4 no-scrollbar">
            <div className="flex-shrink-0 w-44 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-2xl p-4 shadow-sm"><div className="relative mb-3"><img className="w-full h-32 object-cover rounded-xl" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAocvUAerNhcSQ6uQf2RJ5e46CC13_UfnzpF1EAMT_YwWJIA_gBrozR3OpmVtwgbxg2s7RNFV-Ct7P6pwS9RcujThZ_dh_V25TsmHuf78JLLND_-3weHUAdgerFe3C4ffKY8MaQOyVEXXTtTJnyZkNn9Keh9tPmonn9UtsnXR6X5DlLU-5GUIGcwzR3bEv_WEhzDXWhmNgyIjs28PtshY7g9kyL9jx_oGfLKj4DVft4p5ZMDJLCQe5DSyeAAtbZ6C87onOJuDxPF8p4"/></div><div className="text-center"><h3 className="font-bold text-sm truncate">Tanvir Rahman</h3><p className="text-xs text-primary font-bold mt-1">President</p></div></div>
            <div className="flex-shrink-0 w-44 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-2xl p-4 shadow-sm"><div className="relative mb-3"><img className="w-full h-32 object-cover rounded-xl" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDtVs6f9OW0L6Y2A_Pt5Bpk_W82GHHDq9yY_rAe41tRCaQT77w0teSkv2G01a_GwadK7S-NziiV0V-oSp4KVVA_k8R9_6WwLSc7jP-_RELOinrk0Ye8n_g_XIyToaDiPNsYrbKyzxvJVvHU_p0w-_oURAqn2Rf5h_UnfWTCNnhhBqua5pEe8tf1p4wEUmcB9D4OlkHYwdMk3ytjs4sfHjKSmLRihiKWgHvgGaHGtw9hJkTQL6O3tcuLNTEe1_z5LQ7UNzdn5HjTCtst"/></div><div className="text-center"><h3 className="font-bold text-sm truncate">Asif Ahmed</h3><p className="text-xs text-primary font-bold mt-1">General Secretary</p></div></div>
          </div>
        </section>
        <section className="mt-6">
          <div className="px-4 mb-4"><h2 className="text-xl font-extrabold tracking-tight">Upazilas under Dhaka</h2></div>
          <div className="space-y-3 px-4">
            <div className="group flex items-center justify-between p-4 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-2xl"><div className="flex items-center gap-4"><div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary"><span className="material-symbols-outlined">location_city</span></div><div><h4 className="font-bold text-base">Savar</h4></div></div><span className="material-symbols-outlined text-gray-400">chevron_right</span></div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default DistrictDetailView;
