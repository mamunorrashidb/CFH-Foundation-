
import React from 'react';
import { View } from '../types';

interface DonorVerificationViewProps {
  setActiveView: (view: View) => void;
}

const DonorVerificationView: React.FC<DonorVerificationViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-[#121717] dark:text-white font-display max-w-md mx-auto">
      <div className="sticky top-0 z-50 bg-white dark:bg-background-dark border-b border-[#dce4e5] dark:border-gray-800">
        <div className="flex items-center p-4 justify-between">
          <button onClick={() => setActiveView('dashboard')} className="flex items-center gap-3">
            <span className="material-symbols-outlined text-primary cursor-pointer">arrow_back</span>
            <h2 className="text-lg font-bold leading-tight tracking-tight">Donor Verification</h2>
          </button>
        </div>
      </div>
      <main className="pb-40">
        <div className="bg-white dark:bg-gray-900/50 p-6">
          <div className="flex items-center gap-5">
            <div className="relative">
              <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-xl h-24 w-24 border-2 border-primary/20" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAotLcl78ZzxHBIm4gmFzd7q2T6-YT1MWUofZj-MnhrC-dotBe-G1oXM_vcuJiticOGw5xYkC96GMbKGhXyJB0RXPNgo2huzTKUCgzAqZnxIJ5rlfM-SNV7PDQdDlZLxfTqLOFeUK6MKLjmsSv2k0rXKizj2UmDCiDxylfY2NLtmI6lIn7uozvXZUIzkyEFx2iD2VrVS7CpMmbnA4h1eGO5FtUsxlL2OtxiTWfgRYl-zxy98Jk4aYtwSQk2NS8voH3azutwS3u8m6cT')"}}>
              </div>
            </div>
            <div className="flex flex-col">
              <h1 className="text-2xl font-bold tracking-tight">Johnathan Doe</h1>
              <p className="text-[#658386] text-sm font-medium">ID: #88291 • Age 32</p>
            </div>
          </div>
        </div>
      </main>
      <div className="fixed bottom-20 left-1/2 -translate-x-1/2 w-full max-w-md px-4 z-40">
        <div className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-md p-3 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 flex flex-col gap-2">
            <button className="w-full bg-emerald-verify text-white font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 active:scale-[0.98] transition-all">
                <span className="material-symbols-outlined text-xl">check_circle</span>
                Verify & Approve Donor
            </button>
            <div className="grid grid-cols-2 gap-2">
                <button className="bg-royal-info/10 dark:bg-royal-info/20 text-royal-info font-bold py-3 rounded-xl flex items-center justify-center gap-2 active:scale-[0.98] transition-all text-sm">
                    <span className="material-symbols-outlined text-lg">info</span>
                    Request Info
                </button>
                <button className="bg-reject-red/10 dark:bg-reject-red/20 text-reject-red font-bold py-3 rounded-xl flex items-center justify-center gap-2 active:scale-[0.98] transition-all text-sm">
                    <span className="material-symbols-outlined text-lg">cancel</span>
                    Reject
                </button>
            </div>
        </div>
      </div>
       <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md h-20 bg-white dark:bg-background-dark border-t border-[#dce4e5] dark:border-gray-800 flex items-center justify-around">
        <div className="flex flex-col items-center gap-1 text-primary">
            <span className="material-symbols-outlined">assignment_late</span>
            <span className="text-[10px] font-bold">PENDING</span>
        </div>
        <div className="flex flex-col items-center gap-1 text-[#658386]">
            <span className="material-symbols-outlined">history</span>
            <span className="text-[10px] font-bold">HISTORY</span>
        </div>
      </nav>
      <style>{`
        :root {
          --primary: #177982;
          --background-light: #fafafa;
          --background-dark: #17191c;
          --emerald-verify: #2ECC71;
          --royal-info: #3498DB;
          --reject-red: #E74C3C;
        }
      `}</style>
    </div>
  );
};

export default DonorVerificationView;
