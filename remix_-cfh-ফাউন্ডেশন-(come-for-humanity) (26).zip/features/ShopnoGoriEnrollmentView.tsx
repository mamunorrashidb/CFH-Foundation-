
import React, { useState } from 'react';
import { View, Course } from '../types';
import { enrollStudent } from '../services/apiService';

interface ShopnoGoriEnrollmentViewProps {
  setActiveView: (view: View, props?: any) => void;
  course: Course;
}

type EnrollmentStep = 'form' | 'payment' | 'confirming';

const ShopnoGoriEnrollmentView: React.FC<ShopnoGoriEnrollmentViewProps> = ({ setActiveView, course }) => {
    const [step, setStep] = useState<EnrollmentStep>('form');
    const [formData, setFormData] = useState({ fullName: '', phone: '', email: '' });
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!formData.fullName || !formData.phone) {
            setError('অনুগ্রহ করে সকল আবশ্যকীয় তথ্য পূরণ করুন।');
            return;
        }
        setStep('payment');
    };

    const handlePayment = async () => {
        setStep('confirming');
        setIsLoading(true);
        try {
            const response = await enrollStudent({ ...formData, courseId: course.id });
            if (response.status === 'success') {
                setActiveView('enrollment-confirmation', {
                    studentName: formData.fullName,
                    courseName: course.bengaliTitle,
                    fee: course.fee
                });
            } else {
                setError(response.message || 'ভর্তি প্রক্রিয়া সম্পন্ন করা যায়নি।');
                setStep('payment'); // Go back to payment step on error
            }
        } catch (err) {
            setError((err as Error).message);
            setStep('payment');
        } finally {
            setIsLoading(false);
        }
    };

  return (
    <div className="bg-background-light dark:bg-background-dark text-[#111714] dark:text-white min-h-screen pb-24">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-4 border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <button onClick={() => step === 'form' ? setActiveView('ecommerce') : setStep('form')} className="flex items-center gap-3">
            <span className="material-symbols-outlined text-[#111714] dark:text-white cursor-pointer">arrow_back_ios_new</span>
          </button>
          <h1 className="text-lg font-bold tracking-tight font-bengali">কোর্স এনরোলমেন্ট</h1>
          <div className="w-10"></div>
        </div>
      </header>

      <main className="max-w-md mx-auto p-4">
        {step === 'form' && (
            <div className="animate-fade-in">
                 <h2 className="text-2xl font-bold font-bengali mb-2">আপনার তথ্য দিন</h2>
                 <p className="text-sm text-gray-500 mb-6 font-bengali">এই তথ্য আপনার সার্টিফিকেটে ব্যবহার করা হবে।</p>
                 <form onSubmit={handleFormSubmit} className="space-y-4">
                    <div className="space-y-1">
                        <label className="text-sm font-semibold mb-1.5 block font-bengali">আপনার পুরো নাম</label>
                        <input className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-4 font-bengali" name="fullName" value={formData.fullName} onChange={handleInputChange} placeholder="নাম লিখুন" type="text" required/>
                    </div>
                    <div className="space-y-1">
                        <label className="text-sm font-semibold mb-1.5 block font-bengali">মোবাইল নম্বর</label>
                        <input className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-4" name="phone" value={formData.phone} onChange={handleInputChange} placeholder="01XXX-XXXXXX" type="tel" required/>
                    </div>
                     <div className="space-y-1">
                        <label className="text-sm font-semibold mb-1.5 block font-bengali">ইমেইল (ঐচ্ছিক)</label>
                        <input className="w-full h-12 rounded-lg border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:border-primary focus:ring-2 focus:ring-primary/10 text-base px-4" name="email" value={formData.email} onChange={handleInputChange} placeholder="আপনার ইমেইল দিন" type="email" />
                    </div>
                    {error && <p className="text-red-500 text-sm font-bengali">{error}</p>}
                    <button type="submit" className="w-full h-14 bg-primary text-white rounded-xl font-bold text-lg shadow-lg shadow-primary/30 active:scale-95 transition-transform font-bengali mt-4">
                        পেমেন্ট ধাপে যান
                    </button>
                 </form>
            </div>
        )}

        {(step === 'payment' || step === 'confirming') && (
            <div className="animate-fade-in">
                <h2 className="text-2xl font-bold font-bengali mb-2">পেমেন্ট সম্পন্ন করুন</h2>
                <p className="text-sm text-gray-500 mb-6 font-bengali">নিরাপদ পেমেন্ট গেটওয়ের মাধ্যমে পেমেন্ট করুন।</p>
                <div className="bg-white dark:bg-card-dark rounded-xl p-5 border border-gray-100 dark:border-gray-800 shadow-sm space-y-3">
                    <div className="flex justify-between text-sm"><span className="text-gray-600 dark:text-gray-400 font-bengali">কোর্সের নাম</span><span className="font-medium font-bengali">{course.bengaliTitle}</span></div>
                    <div className="border-t border-gray-100 dark:border-gray-700 pt-3 mt-3 flex justify-between items-center font-bold">
                        <span className="font-bengali">সর্বমোট</span>
                        <span className="text-primary text-xl font-bengali">৳{course.fee}</span>
                    </div>
                </div>
                <div className="mt-6 space-y-3">
                    <button onClick={handlePayment} disabled={isLoading} className="w-full h-14 bg-[#e2136e] text-white rounded-xl font-bold text-lg flex items-center justify-center gap-3 active:scale-95 transition-transform disabled:opacity-70">
                        {isLoading ? <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div> : 'বিকাশে পেমেন্ট করুন'}
                    </button>
                    <button onClick={handlePayment} disabled={isLoading} className="w-full h-14 bg-[#F58220] text-white rounded-xl font-bold text-lg flex items-center justify-center gap-3 active:scale-95 transition-transform disabled:opacity-70">
                         {isLoading ? <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div> : 'নগদে পেমেন্ট করুন'}
                    </button>
                </div>
                 {error && <p className="text-red-500 text-sm font-bengali text-center mt-4">{error}</p>}
            </div>
        )}
      </main>
    </div>
  );
};

export default ShopnoGoriEnrollmentView;
