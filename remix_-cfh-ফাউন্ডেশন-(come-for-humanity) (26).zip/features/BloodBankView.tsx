import React, { useState, useEffect } from 'react';
import { View, Donor } from '../types';
import { fetchDonors } from '../services/apiService';
import { getCurrentLocation } from '../utils/location';

interface BloodBankViewProps {
  setActiveView: (view: View) => void;
}

const DonorCard: React.FC<{ donor: Donor }> = ({ donor }) => {
    const distanceText = donor.distance !== undefined 
        ? `${donor.distance.toFixed(1)} কিমি দূরে` 
        : 'অবস্থান अज्ञात';

    return (
        <div className="bg-white dark:bg-card-dark rounded-xl p-4 border border-gray-100 dark:border-gray-800 shadow-sm animate-fade-in">
            <div className="flex items-center gap-4">
                <div className="size-16 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-primary font-bold text-2xl">{donor.group}</span>
                </div>
                <div>
                    <h3 className="font-bold text-gray-800 dark:text-white font-bengali">{donor.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 font-bengali">{donor.location}</p>
                    <p className="text-xs text-primary font-bold font-bengali">{distanceText}</p>
                </div>
            </div>
            <a href={`tel:${donor.phone}`} className="mt-4 w-full bg-primary text-white font-bold py-3 px-5 rounded-lg flex items-center justify-center gap-2 active:scale-95 transition-transform">
                <span className="material-symbols-outlined">call</span>
                <span className="font-bengali">কল করুন</span>
            </a>
        </div>
    );
};

const BloodBankView: React.FC<BloodBankViewProps> = ({ setActiveView }) => {
    const [donors, setDonors] = useState<Donor[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [locationError, setLocationError] = useState<string | null>(null);
    const [userLocation, setUserLocation] = useState<{ lat: number, lon: number } | null>(null);

    useEffect(() => {
        const loadInitialData = async () => {
            setIsLoading(true);
            setLocationError(null);
            try {
                const { latitude, longitude } = await getCurrentLocation();
                const location = { lat: latitude, lon: longitude };
                setUserLocation(location);
                const response = await fetchDonors(location);
                if (response.status === 'success') {
                    setDonors(response.data);
                } else {
                    setLocationError(response.message);
                }
            } catch (error) {
                setLocationError((error as Error).message);
                // Fetch donors without location data if geolocation fails
                try {
                    const response = await fetchDonors(null);
                    if (response.status === 'success') {
                        setDonors(response.data);
                    } else {
                        setLocationError(response.message);
                    }
                } catch (e) {
                    setLocationError((e as Error).message);
                }
            } finally {
                setIsLoading(false);
            }
        };
        loadInitialData();
    }, []);

    const LoadingSkeleton = () => (
        <div className="p-4 grid grid-cols-1 gap-4">
            {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-white dark:bg-card-dark rounded-xl p-4 border border-gray-100 dark:border-gray-800 shadow-sm">
                    <div className="flex items-center gap-4">
                        <div className="size-16 rounded-full bg-gray-200 dark:bg-gray-700 animate-pulse"></div>
                        <div className="flex-1 space-y-2">
                            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 animate-pulse"></div>
                            <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2 animate-pulse"></div>
                            <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/4 animate-pulse"></div>
                        </div>
                    </div>
                    <div className="mt-4 w-full h-12 bg-gray-200 dark:bg-gray-700 rounded-lg animate-pulse"></div>
                </div>
            ))}
        </div>
    );

    return (
        <div className="bg-background-light dark:bg-background-dark min-h-screen">
            <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-800">
                <button onClick={() => setActiveView('dashboard')} className="size-10 flex items-center justify-center -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>
                <h1 className="text-lg font-bold font-bengali">নিকটতম রক্তদাতা</h1>
                <div className="w-10"></div>
            </header>
            
            {locationError && (
                 <div className="p-4">
                    <div className="bg-yellow-100 dark:bg-yellow-900/30 border-l-4 border-yellow-500 text-yellow-700 dark:text-yellow-300 p-4 rounded-r-lg" role="alert">
                        <p className="font-bold font-bengali">অবস্থান অ্যাক্সেস সমস্যা</p>
                        <p className="text-sm font-bengali">{locationError} নিকটতম ডোনার খুঁজতে, অনুগ্রহ করে লোকেশন অ্যাক্সেস দিন।</p>
                    </div>
                </div>
            )}
            
            {isLoading ? (
                <LoadingSkeleton />
            ) : (
                <main className="p-4 grid grid-cols-1 gap-4 pb-24">
                    {donors.length > 0 ? donors.map(donor => (
                        <DonorCard key={donor.id} donor={donor} />
                    )) : (
                        <p className="text-center text-gray-500 py-10 font-bengali">আপনার আশেপাশে কোনো ডোনার পাওয়া যায়নি।</p>
                    )}
                </main>
            )}
        </div>
    );
};

export default BloodBankView;
