import React from 'react';
import { View } from '../types';

interface SupportCenterViewProps {
  setActiveView: (view: View) => void;
}

const SupportCenterView: React.FC<SupportCenterViewProps> = ({ setActiveView }) => {
  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-[430px] mx-auto bg-background-light dark:bg-background-dark shadow-2xl overflow-x-hidden">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center p-4 pb-3 justify-between">
          <button onClick={() => setActiveView('dashboard')} className="flex size-10 items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer">
            <span className="material-symbols-outlined text-[#111317] dark:text-white">arrow_back_ios_new</span>
          </button>
          <h2 className="text-primary dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center pr-10">FAQ & Knowledge Base</h2>
        </div>
      </header>
      <main className="flex-1">
        <div className="px-4 py-6">
          <div className="relative flex flex-col w-full group">
            <div className="flex w-full h-14 items-stretch rounded-xl bg-gray-50 dark:bg-gray-800/50 border border-gray-100 dark:border-gray-700 shadow-sm">
              <div className="flex items-center justify-center pl-4 text-gray-400"><span className="material-symbols-outlined text-[22px]">search</span></div>
              <input className="form-input flex w-full border-none bg-transparent focus:ring-0 text-[#111317] dark:text-white placeholder:text-gray-400 text-base font-normal px-3" placeholder="How can we help you?"/>
            </div>
          </div>
        </div>
        <div className="mt-auto px-4 pb-12">
          <div className="rounded-2xl bg-gray-50 dark:bg-gray-900/50 p-6 border border-dashed border-gray-300 dark:border-gray-700">
            <h4 className="text-center text-lg font-bold text-primary dark:text-white mb-4">Still need help?</h4>
            <div className="flex flex-col gap-3">
               <button onClick={() => setActiveView('raw-nest-support-ticket')} className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-primary text-white font-semibold transition-transform active:scale-95 shadow-lg shadow-primary/20">
                <span className="material-symbols-outlined text-[20px]">support_agent</span>RawNest IT Support
              </button>
              <button onClick={() => setActiveView('feedback-portal')} className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl border-2 border-primary/20 text-primary font-semibold transition-colors hover:bg-primary/5 active:scale-95">
                <span className="material-symbols-outlined text-[20px]">chat_bubble</span>Feedback & Suggestions
              </button>
              <button onClick={() => setActiveView('emergency-help')} className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl border-2 border-red-500/20 text-red-500 font-semibold transition-colors hover:bg-red-500/5 active:scale-95">
                <span className="material-symbols-outlined text-[20px]">emergency</span>Emergency Help Center
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default SupportCenterView;