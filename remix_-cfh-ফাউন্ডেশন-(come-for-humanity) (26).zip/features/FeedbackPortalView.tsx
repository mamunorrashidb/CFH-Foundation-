
import React from 'react';
import { View } from '../types';

interface FeedbackPortalViewProps {
  setActiveView: (view: View) => void;
}

const FeedbackPortalView: React.FC<FeedbackPortalViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 max-w-md mx-auto min-h-screen flex flex-col relative pb-24">
      <header className="sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-4 flex items-center justify-between border-b border-[#eef0f4] dark:border-slate-800">
        <button onClick={() => setActiveView('support-center')} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
          <span className="material-symbols-outlined text-primary">arrow_back_ios_new</span>
        </button>
        <h1 className="text-primary dark:text-blue-400 font-bold text-lg tracking-tight">Feedback Portal</h1>
        <div className="w-10"></div>
      </header>
      <main className="flex-1 overflow-y-auto px-4 pt-6">
        <section className="mb-8">
          <h2 className="text-primary dark:text-blue-300 text-3xl font-extrabold leading-tight tracking-tight mb-2">Help us improve</h2>
          <p className="text-slate-500 dark:text-slate-400 text-base leading-relaxed">Your voice shapes our mission. Share your ideas, report bugs, or suggest new features.</p>
        </section>
        <section className="space-y-6">
          <div>
            <textarea className="w-full min-h-[160px] p-4 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-base" placeholder="Describe your suggestion..."></textarea>
          </div>
          <div className="flex flex-col gap-4">
            <button className="flex items-center justify-center gap-2 w-full py-3 px-4 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl text-slate-500">
              <span className="material-symbols-outlined text-[20px]">add_a_photo</span><span className="text-sm font-semibold">Upload Screenshot (Optional)</span>
            </button>
            <button className="w-full bg-[#177D44] hover:bg-[#177D44]/90 text-white font-bold py-4 rounded-xl shadow-lg flex items-center justify-center gap-2">
              <span>Submit Feedback</span><span className="material-symbols-outlined text-[20px]">send</span>
            </button>
          </div>
        </section>
      </main>
    </div>
  );
};

export default FeedbackPortalView;
