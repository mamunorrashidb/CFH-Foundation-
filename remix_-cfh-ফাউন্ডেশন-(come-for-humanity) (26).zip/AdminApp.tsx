import React from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import AdminPanelView from './features/AdminPanelView';
import LoadingFallback from './components/LoadingFallback';

const AdminApp: React.FC = () => {
    const { user, loading, isAdmin } = useAuth();
    const [error, setError] = React.useState<string | null>(null);

    if (loading) return <div className="min-h-screen flex items-center justify-center bg-background-dark text-white">লোড হচ্ছে...</div>;

    if (!user) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-background-dark text-white">
                <h1 className="text-2xl font-bold mb-4 font-bengali">অ্যাডমিন প্যানেল লগইন</h1>
                {error && <div className="mb-4 text-red-500 font-medium">{error}</div>}
                <button 
                    onClick={async () => {
                        try {
                            await signInWithGoogle();
                        } catch (err: any) {
                            setError(err.message);
                        }
                    }}
                    className="flex items-center gap-3 bg-white text-gray-800 px-8 py-4 rounded-xl shadow-lg font-bold"
                >
                    <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-6 h-6" />
                    অ্যাডমিন হিসেবে লগইন করুন
                </button>
            </div>
        );
    }

    if (!isAdmin) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-background-dark text-white">
                <span className="material-symbols-outlined text-6xl text-red-500 mb-4">cancel</span>
                <h1 className="text-2xl font-bold mb-2 font-bengali">অ্যাক্সেস রিফিউজড!</h1>
                <p className="text-gray-400 font-bengali">আপনি এই এলাকার জন্য অনুমোদিত নন।</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-background-light dark:bg-background-dark">
            <AdminPanelView user={user} setActiveView={() => {}} />
        </div>
    );
};

export default AdminApp;
