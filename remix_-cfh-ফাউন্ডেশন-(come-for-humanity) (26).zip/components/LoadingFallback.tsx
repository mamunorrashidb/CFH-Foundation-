import React from 'react';

const LoadingFallback: React.FC = () => (
  <div className="w-full h-screen flex items-center justify-center bg-background-light dark:bg-background-dark">
    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
  </div>
);

export default LoadingFallback;
