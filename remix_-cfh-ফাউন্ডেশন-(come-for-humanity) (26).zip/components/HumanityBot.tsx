
import React, { useState, useRef, useEffect } from 'react';
import { askHumanityBot } from '../services/geminiService';
import { ChatMessage } from '../types';

const HumanityBot: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen) {
            chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }
    }, [messages, isOpen]);
    
    const handleSend = async () => {
        if (input.trim() === '') return;

        const userMessage: ChatMessage = { id: Date.now().toString(), text: input, sender: 'user' };
        const loadingMessage: ChatMessage = { id: (Date.now() + 1).toString(), text: '...', sender: 'bot', isLoading: true };
        
        setMessages(prev => [...prev, userMessage, loadingMessage]);
        setInput('');

        try {
            const botResponseText = await askHumanityBot(input);
            const botMessage: ChatMessage = { id: (Date.now() + 2).toString(), text: botResponseText, sender: 'bot' };
            setMessages(prev => [...prev.slice(0, -1), botMessage]);
        } catch (error) {
            const errorMessage: ChatMessage = { id: (Date.now() + 2).toString(), text: "Sorry, I'm having trouble connecting. Please try again later.", sender: 'bot' };
            setMessages(prev => [...prev.slice(0, -1), errorMessage]);
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleSend();
        }
    };

    return (
        <>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="fixed bottom-6 right-6 z-[100] w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center shadow-2xl shadow-primary/40 transform active:scale-90 transition-all"
                aria-label="Open Humanity Bot"
            >
                <span className="material-symbols-outlined text-3xl">psychology</span>
            </button>

            {isOpen && (
                <div className="fixed inset-0 z-[99] bg-black/30 backdrop-blur-sm animate-fade-in" onClick={() => setIsOpen(false)}></div>
            )}
            
            <div className={`fixed bottom-0 right-0 z-[100] w-full h-full max-w-md max-h-[75%] bg-white dark:bg-background-dark shadow-2xl rounded-t-2xl flex flex-col transition-transform duration-300 ease-in-out ${isOpen ? 'translate-y-0' : 'translate-y-full'}`}>
                <header className="flex items-center justify-between p-4 border-b border-gray-100 dark:border-gray-800">
                    <div className="flex items-center gap-3">
                        <div className="bg-primary/10 p-2 rounded-lg"><span className="material-symbols-outlined text-primary">psychology</span></div>
                        <div>
                            <h2 className="font-bold text-lg">Humanity Bot</h2>
                            <p className="text-xs text-gray-500">CFH AI Assistant</p>
                        </div>
                    </div>
                    <button onClick={() => setIsOpen(false)} className="p-2 text-gray-400 hover:text-gray-800 dark:hover:text-white"><span className="material-symbols-outlined">close</span></button>
                </header>
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {messages.map((msg) => (
                        <div key={msg.id} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
                            {msg.sender === 'bot' && <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0"><span className="material-symbols-outlined text-primary text-lg">psychology</span></div>}
                            <div className={`max-w-[80%] p-3 rounded-2xl ${msg.sender === 'user' ? 'bg-primary text-white rounded-br-lg' : 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-100 rounded-bl-lg'}`}>
                                {msg.isLoading ? (
                                    <div className="flex gap-1.5 items-center">
                                        <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                        <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                        <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce"></span>
                                    </div>
                                ) : (
                                    <p className="text-sm" dangerouslySetInnerHTML={{ __html: msg.text.replace(/\n/g, '<br />') }} />
                                )}
                            </div>
                        </div>
                    ))}
                    <div ref={chatEndRef} />
                </div>
                <div className="p-4 border-t border-gray-100 dark:border-gray-800 bg-white dark:bg-background-dark">
                    <div className="flex items-center gap-2">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyPress={handleKeyPress}
                            placeholder="Ask me anything..."
                            className="flex-1 px-4 py-3 border border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                        <button onClick={handleSend} className="w-12 h-12 bg-primary text-white rounded-xl flex items-center justify-center"><span className="material-symbols-outlined">send</span></button>
                    </div>
                </div>
            </div>
        </>
    );
};

export default HumanityBot;
