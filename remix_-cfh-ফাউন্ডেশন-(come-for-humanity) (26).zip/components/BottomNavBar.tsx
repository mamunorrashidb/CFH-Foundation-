import React from 'react';
import { View } from '../types';

interface BottomNavBarProps {
  activeView: View;
  setActiveView: (view: View, props?: any) => void;
}

const NavItem: React.FC<{
  view: View;
  label: string;
  icon: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ view, label, icon, isActive, onClick }) => {
  const activeClass = isActive ? 'text-primary' : 'text-gray-400';
  const iconFillClass = isActive ? 'fill-1' : '';

  return (
    <button onClick={onClick} className={`flex flex-col items-center gap-1 w-1/5 pt-1 transition-colors ${activeClass}`}>
      <span className={`material-symbols-outlined ${iconFillClass}`}>{icon}</span>
      <span className="text-[10px] font-bold">{label}</span>
    </button>
  );
};

const BottomNavBar: React.FC<BottomNavBarProps> = ({ activeView, setActiveView }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/80 dark:bg-background-dark/80 backdrop-blur-xl border-t border-gray-100 dark:border-gray-800 pb-8 pt-3 px-4 flex justify-around items-start z-50">
        <NavItem
            view="dashboard"
            label="হোম"
            icon="home"
            isActive={activeView === 'dashboard'}
            onClick={() => setActiveView('dashboard')}
        />
        <NavItem
            view="impact-tracker"
            label="কার্যক্রম"
            icon="volunteer_activism"
            isActive={activeView === 'impact-tracker'}
            onClick={() => setActiveView('impact-tracker')}
        />
        
        <div className="w-1/5 flex justify-center">
            <button onClick={() => setActiveView('donation')} className="relative -top-7 bg-primary text-white size-16 rounded-full shadow-lg shadow-primary/30 flex items-center justify-center border-4 border-background-light dark:border-gray-900 active:scale-95 transition-transform">
                <span className="material-symbols-outlined text-3xl">favorite</span>
            </button>
        </div>
        
        <NavItem
            view="directory"
            label="অন্যান্য"
            icon="explore"
            isActive={activeView === 'directory'}
            onClick={() => setActiveView('directory')}
        />
        <NavItem
            view="profile"
            label="প্রোফাইল"
            icon="person"
            isActive={activeView === 'profile'}
            onClick={() => setActiveView('profile')}
        />
    </nav>
  );
};

export default BottomNavBar;
