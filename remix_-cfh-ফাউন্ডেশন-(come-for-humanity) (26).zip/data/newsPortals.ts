export interface NewsPortal {
    name: string;
    logo: string;
    rssUrl: string;
}

export const newsPortals: NewsPortal[] = [
    {
        name: 'মেহেরপুর নিউজ',
        logo: 'https://www.meherpurnews.com/wp-content/uploads/2018/12/logo.png',
        rssUrl: 'https://www.meherpurnews.com/feed/',
    },
    {
        name: 'মেহেরপুর প্রতিদিন',
        logo: 'https://meherpurpratidin.com/wp-content/uploads/2022/11/logo.png',
        rssUrl: 'https://meherpurpratidin.com/feed/',
    },
    {
        name: 'Dainik Deshantor',
        logo: 'https://dainikdeshantor.com/wp-content/uploads/2024/07/logo.png',
        rssUrl: 'https://dainikdeshantor.com/feed/',
    },
    {
        name: 'বিবর্তন বাংলা',
        logo: 'https://bibortonbangla.com/wp-content/uploads/2024/07/New-Project-2.png',
        rssUrl: 'https://bibortonbangla.com/feed/',
    },
];
