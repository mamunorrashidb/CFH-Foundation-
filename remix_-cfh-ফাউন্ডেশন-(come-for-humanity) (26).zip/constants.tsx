
import React from 'react';
import { Category } from './types';

export const ICONS = {
    blood: <span className="material-symbols-outlined">bloodtype</span>,
    oxygen: <span className="material-symbols-outlined">masks</span>,
    telemedicine: <span className="material-symbols-outlined">duo</span>,
    store: <span className="material-symbols-outlined">storefront</span>,
    education: <span className="material-symbols-outlined">school</span>,
    impact: <span className="material-symbols-outlined">trending_up</span>,
    hallOfFame: <span className="material-symbols-outlined">military_tech</span>,
    idCard: <span className="material-symbols-outlined">badge</span>,
    verification: <span className="material-symbols-outlined">verified_user</span>,
    sdg: <span className="material-symbols-outlined">public</span>,
    stories: <span className="material-symbols-outlined">movie</span>,
    support: <span className="material-symbols-outlined">support_agent</span>,
    developer: <span className="material-symbols-outlined">terminal</span>,
    homeCare: <span className="material-symbols-outlined">home_health</span>,
    gallery: <span className="material-symbols-outlined">perm_media</span>,
    directory: <span className="material-symbols-outlined">contact_page</span>,
    location: <span className="material-symbols-outlined">location_city</span>,
    protection: <span className="material-symbols-outlined">shield_person</span>,
    probashi: <span className="material-symbols-outlined">flight_takeoff</span>,
    committee: <span className="material-symbols-outlined">groups</span>,
};


export const CATEGORIES: Category[] = [
    {
        id: 'blood-bank',
        title: 'BBS Blood Bank',
        description: 'ডোনার খুঁজুন',
        icon: ICONS.blood,
    },
    {
        id: 'oxygen-service',
        title: 'Oxygen Service',
        description: 'জরুরী অক্সিজেন',
        icon: ICONS.oxygen,
    },
    {
        id: 'telemedicine',
        title: 'Telemedicine',
        description: 'ডাক্তারের পরামর্শ',
        icon: ICONS.telemedicine,
    },
    {
        id: 'ecommerce',
        title: 'Social Business',
        description: 'হস্তশিল্প ও খাদ্য',
        icon: ICONS.store,
    },
    {
        id: 'gamification-hub',
        title: 'RawNest IT Institute',
        description: 'প্রযুক্তি ও দক্ষতা উন্নয়ন',
        icon: ICONS.education,
    },
     {
        id: 'hall-of-fame',
        title: 'Hall of Fame',
        description: 'আমাদের উত্তরাধিকার',
        icon: ICONS.hallOfFame,
    },
    {
        id: 'impact-tracker',
        title: 'Impact Tracker',
        description: 'আমাদের কার্যক্রম',
        icon: ICONS.impact,
    },
    {
        id: 'digital-id-card',
        title: 'Digital ID Card',
        description: 'অফিসিয়াল আইডি',
        icon: ICONS.idCard,
    },
    {
        id: 'verification',
        title: 'Verification',
        description: 'আইডি যাচাই করুন',
        icon: ICONS.verification,
    },
    {
        id: 'sdg-projects',
        title: 'SDG Projects',
        description: 'আমাদের লক্ষ্য',
        icon: ICONS.sdg,
    },
    {
        id: 'meherpur-directory',
        title: 'Meherpur Directory',
        description: 'জেলার জরুরি যোগাযোগ',
        icon: ICONS.location,
    },
     {
        id: 'committee-directory',
        title: 'Committee Directory',
        description: 'নেতৃত্ব দেখুন',
        icon: ICONS.committee,
    },
    {
        id: 'protection-cell',
        title: 'Protection Cell',
        description: 'নিরাপত্তা ও অভিযোগ',
        icon: ICONS.protection,
    },
    {
        id: 'probashi-hub',
        title: 'Probashi Hub',
        description: 'প্রবাসী সেবা',
        icon: ICONS.probashi,
    },
    {
        id: 'donor-stories',
        title: 'Donor Stories',
        description: 'অনুপ্রেরণার গল্প',
        icon: ICONS.stories,
    },
    {
        id: 'support-center',
        title: 'Support Center',
        description: 'সহায়তা কেন্দ্র',
        icon: ICONS.support,
    },
    {
        id: 'home-care',
        title: 'Home Care',
        description: 'বাড়িতে স্বাস্থ্যসেবা',
        icon: ICONS.homeCare,
    },
    {
        id: 'multimedia-gallery',
        title: 'Multimedia',
        description: 'গ্যালারি দেখুন',
        icon: ICONS.gallery,
    },
     {
        id: 'developer-portal',
        title: 'Developer Portal',
        description: 'এপিআই ও রিসোর্স',
        icon: ICONS.developer,
    },
];

export const MOCK_NEWS_ITEMS = [
    { id: 1, title: 'মেহেরপুরে সিএফএইচ বিনামূল্যে অক্সিজেন সেবা চালু করেছে', imageUrl: 'https://picsum.photos/800/400?random=1', excerpt: 'সাম্প্রতিক স্বাস্থ্য সংকটের প্রতিক্রিয়ায়, সিএফএইচ বিনামূল্যে জরুরী ব্যবহারের জন্য ৫০টি অক্সিজেন সিলিন্ডার সরবরাহ করেছে...' },
    { id: 2, title: 'স্বপ্নগড়ির হস্তশিল্প ১০০+ স্থানীয় কারিগরকে सशक्त করেছে', imageUrl: 'https://picsum.photos/800/400?random=2', excerpt: 'আমাদের সামাজিক ব্যবসা উদ্যোগ জেলার নারী উদ্যোক্তাদের জন্য টেকসই আয়ের ব্যবস্থা করছে...' },
    { id: 3, title: 'বার্ষিক যুব উৎসবে রেকর্ড সংখ্যক উপস্থিতি', imageUrl: 'https://picsum.photos/800/400?random=3', excerpt: 'শিক্ষা, সংস্কৃতি এবং ইতিবাচক পরিবর্তন প্রচারের এই উৎসবে ৫,০০০ এরও বেশি যুবক অংশ নিয়েছে...' },
];
