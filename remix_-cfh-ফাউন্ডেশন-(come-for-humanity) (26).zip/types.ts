import React from 'react';

export type View = 'dashboard' | 'blood-bank' | 'oxygen-service' | 'telemedicine' | 'ecommerce' | 'hall-of-fame' | 'impact-tracker' | 'digital-id-card' | 'verification' | 'sdg-projects' | 'profile' | 'donor-stories' | 'blood-requests' | 'support-center' | 'booking-confirmation' | 'home-care' | 'developer-portal' | 'gamification-hub' | 'multimedia-gallery' | 'directory' | 'library-reader' | 'digital-prescription' | 'course-detail' | 'senior-council' | 'committee-application' | 'data-privacy' | 'donation' | 'donation-history' | 'doctor-registration' | 'district-detail' | 'donor-certificate' | 'donor-profile' | 'donor-verification' | 'earnings-payout' | 'emergency-help' | 'feedback-portal' | 'farmer-portal' | 'global-impact-report' | 'events-calendar' | 'news-feed' | 'protection-cell' | 'probashi-hub' | 'provider-onboarding' | 'leaderboard' | 'humanity-quiz' | 'mini-games-hub' | 'transparency-report' | 'medical-history-vault' | 'live-stream' | 'identity-wallet' | 'micro-partner-dashboard' | 'impact-reward' | 'badge-collection' | 'archive-view' | 'newsletter-signup' | 'notification-settings' | 'organization-profile' | 'patient-intake' | 'family-security-request' | 'project-funding-tracker' | 'project-milestone' | 'investment-project-detail' | 'raw-nest-client-dashboard' | 'raw-nest-digital-portfolio' | 'graduate-success-stories' | 'raw-nest-it-certificate' | 'raw-nest-internship-form' | 'raw-nest-support-ticket' | 'raw-nest-system-status' | 'news-and-reminders' | 'notification-center' | 'provider-profile' | 'shopno-gori-store' | 'shopno-gori-enrollment' | 'shopno-gori-product-detail' | 'shopno-gori-reader' | 'social-forestry' | 'social-media-impact-kit' | 'spiritual-journal' | 'appointment-history' | 'video-call' | 'spiritual-session-player' | 'volunteer-registration' | 'volunteer-training' | 'volunteer-shift-scheduler' | 'rapid-deployment' | 'committee-directory' | 'meherpur-directory' | 'order-confirmation' | 'enrollment-confirmation' | 'shopno-gori-certificate' | 'admin-panel' | 'donor-registration' | 'donor-registration-confirmation' | 'live-news' | 'cart';

export interface Category {
  id: View;
  title: string;
  description: string;
  icon: React.ReactNode;
}

export interface NewsArticle {
  id: string;
  title: string;
  link: string;
  image?: string;
  source: string;
  logo: string;
  timestamp: string;
  pubDate: string;
}

export interface Product {
    id: number;
    name: string;
    price: string;
    image: string;
}

export interface CartItem extends Product {
    quantity: number;
}

export interface Course {
    id: number;
    title: string;
    bengaliTitle: string;
    fee: string;
    image: string;
    description: string;
    learnings: string[];
}

export interface Enrollment {
    id: number;
    courseId: number;
    studentName: string;
    studentPhone: string;
    studentEmail: string;
    status: 'pending' | 'paid' | 'completed';
}


export interface ChatMessage {
    id: string;
    text: string;
    sender: 'user' | 'bot';
    isLoading?: boolean;
}

export interface Donor {
    id: string;
    name: string;
    group: string;
    location: string;
    phone: string;
    lat: number;
    lon: number;
    distance?: number; // Optional, as it will be calculated
}

export interface SdgProject {
    id: number;
    title: string;
    description: string;
    status: 'Planning' | 'Ongoing' | 'Completed' | 'On-Hold';
    target_goal: number | null;
    current_progress: number;
    goal_unit: string | null;
}

export interface MockDonor {
    name: string;
    group: string;
    location: { lat: number; lon: number };
    phone: string;
    lastDonationDate: string;
}