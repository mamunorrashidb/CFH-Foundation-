import React, { useState, useEffect } from 'react';
import { View, CartItem, Product } from './types';
import OnboardingView from './features/OnboardingView';
import ViewManager from './components/ViewManager';
import BottomNavBar from './components/BottomNavBar';
import LoadingFallback from './components/LoadingFallback';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { signInWithGoogle, isFirebaseConfigValid } from './lib/firebase';

const HumanityBot = React.lazy(() => import('./components/HumanityBot'));

const AuthGateway: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, loading, setUser } = useAuth() as any;
    const [error, setError] = React.useState<string | null>(null);
    const [demoMode, setDemoMode] = React.useState(false);
    
    if (loading) return <LoadingFallback />;
    
    if (!user && !demoMode) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-background-light dark:bg-background-dark">
                <img src="https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&q=80&w=400" 
                     alt="CFH Logo" 
                     className="w-32 h-32 rounded-full mb-8 shadow-xl" />
                <h1 className="text-3xl font-extrabold text-primary mb-2 text-center uppercase tracking-wider">
                  CFH ফাউন্ডেশন
                </h1>
                <p className="text-gray-500 dark:text-gray-400 mb-8 text-center max-w-sm">
                  Come For Humanity - আপনাদের সেবায় আমরা সর্বদা প্রস্তুত।
                </p>
                
                {error && (
                    <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-xl text-sm font-medium border border-red-100 dark:border-red-900/30 text-center max-w-sm">
                        {error}
                    </div>
                )}

                <div className="flex flex-col gap-4 w-full max-w-xs">
                    <button 
                        onClick={async () => {
                            try {
                                setError(null);
                                await signInWithGoogle();
                            } catch (err: any) {
                                setError(err.message || "লগইন করতে সমস্যা হয়েছে।");
                            }
                        }}
                        disabled={!isFirebaseConfigValid}
                        className={`flex items-center justify-center gap-3 bg-white dark:bg-gray-800 text-gray-700 dark:text-white px-8 py-4 rounded-xl shadow-lg hover:shadow-2xl transition-all border border-gray-100 dark:border-gray-700 font-medium ${!isFirebaseConfigValid ? 'opacity-50 grayscale' : ''}`}
                    >
                        <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-6 h-6" />
                        গুগল দিয়ে লগইন করুন
                    </button>
                    
                    {!isFirebaseConfigValid && (
                        <div className="mt-4 p-4 bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-900/20 rounded-xl text-center">
                            <p className="text-amber-800 dark:text-amber-400 text-xs font-medium mb-3">
                                Firebase কনফিগার করা নেই। সেটিংস থেকে API Key সেট করুন।
                            </p>
                            <button 
                                onClick={() => {
                                    setDemoMode(true);
                                    setUser({
                                        displayName: 'Demo User',
                                        email: 'demo@example.com',
                                        role: 'admin',
                                        uid: 'demo-123'
                                    });
                                }}
                                className="text-primary font-bold text-sm underline underline-offset-4"
                            >
                                ডেমো মুড এ প্রবেশ করুন (টেস্টিং এর জন্য)
                            </button>
                        </div>
                    )}
                </div>
            </div>
        );
    }
    
    return <>{children}</>;
};

const MainApp: React.FC = () => {
  const [onboardingComplete, setOnboardingComplete] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [viewProps, setViewProps] = useState<any>({}); // State for passing props
  const [cart, setCart] = useState<CartItem[]>([]);
  const { user, isAdmin } = useAuth();

  useEffect(() => {
    const isComplete = localStorage.getItem('cfhOnboardingComplete') === 'true';
    setOnboardingComplete(isComplete);
    setIsLoading(false);
  }, []);

  const handleOnboardingComplete = () => {
    localStorage.setItem('cfhOnboardingComplete', 'true');
    setOnboardingComplete(true);
    setActiveView('dashboard');
  };

  const navigate = (view: View, props: any = {}) => {
    setViewProps(props);
    setActiveView(view);
  };
  
  const addToCart = (product: Product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prevCart, { ...product, quantity: 1 }];
    });
  };

  const updateCartQuantity = (productId: number, quantity: number) => {
    setCart(prevCart => {
      if (quantity <= 0) {
        return prevCart.filter(item => item.id !== productId);
      }
      return prevCart.map(item =>
        item.id === productId ? { ...item, quantity } : item
      );
    });
  };
  
  const clearCart = () => {
      setCart([]);
  };

  const sharedProps = { 
    setActiveView: navigate, 
    cart, 
    addToCart,
    updateCartQuantity,
    clearCart,
    user,
    isAdmin
  };

  if (isLoading) {
    return <LoadingFallback />;
  }

  if (!onboardingComplete) {
    return <OnboardingView onComplete={handleOnboardingComplete} />;
  }
  
  const viewsWithBottomNav = ['dashboard', 'impact-tracker', 'directory', 'profile'];
  const showBottomNav = viewsWithBottomNav.includes(activeView);

  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark font-sans text-gray-800 dark:text-white">
      <React.Suspense fallback={<LoadingFallback />}>
        <main>
            <ViewManager 
                activeView={activeView} 
                viewProps={viewProps} 
                sharedProps={sharedProps}
            />
        </main>
        {showBottomNav && <BottomNavBar activeView={activeView} setActiveView={navigate} />}
        {onboardingComplete && <HumanityBot />}
      </React.Suspense>
    </div>
  );
};

const App: React.FC = () => (
    <AuthProvider>
        <AuthGateway>
            <MainApp />
        </AuthGateway>
    </AuthProvider>
);

export default App;
