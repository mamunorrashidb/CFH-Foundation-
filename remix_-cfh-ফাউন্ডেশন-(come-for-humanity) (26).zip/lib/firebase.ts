import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc } from 'firebase/firestore';
import firebaseConfigData from '../firebase-applet-config.json';

// Use the provided config from the JSON file
const firebaseConfig = {
  apiKey: firebaseConfigData.apiKey,
  authDomain: firebaseConfigData.authDomain,
  projectId: firebaseConfigData.projectId,
  storageBucket: firebaseConfigData.storageBucket,
  messagingSenderId: firebaseConfigData.messagingSenderId,
  appId: firebaseConfigData.appId,
  measurementId: firebaseConfigData.measurementId
};

// Check if config is likely default/placeholder
export const isFirebaseConfigValid = 
    firebaseConfig.apiKey && 
    !firebaseConfig.apiKey.includes("DummyKey");

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const db = getFirestore(app);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// System Settings Helper
export const getSystemSettings = async () => {
    try {
        const docRef = doc(db, 'settings', 'app_config');
        const docSnap = await getDoc(docRef);
        return docSnap.exists() ? docSnap.data() : null;
    } catch (error) {
        console.error("Error fetching settings:", error);
        return null;
    }
};

export const signInWithGoogle = async () => {
    if (!isFirebaseConfigValid) {
        throw new Error("Firebase API Key is missing or invalid. Please configure it in .env or the settings menu.");
    }
    try {
        const result = await signInWithPopup(auth, googleProvider);
        const user = result.user;
        
        // Sync user profile to Firestore
        const userRef = doc(db, 'users', user.uid);
        const userSnap = await getDoc(userRef);
        
        if (!userSnap.exists()) {
            await setDoc(userRef, {
                uid: user.uid,
                email: user.email,
                displayName: user.displayName,
                photoURL: user.photoURL,
                role: 'user', 
                points: 0,
                createdAt: new Date().toISOString(),
                isVerified: false
            });
        }
        return user;
    } catch (error: any) {
        console.error("Error signing in with Google:", error);
        throw error;
    }
};

export const logout = () => signOut(auth);
